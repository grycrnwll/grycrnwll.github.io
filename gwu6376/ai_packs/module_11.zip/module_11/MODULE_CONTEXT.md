# Module 11 Context — Structural VARs

**Econ 6376 — Applied Time Series Econometrics, George Washington University (Applied Economics MA).**

**Module 11 release · 2026-11-12.** This file is self-contained. Paste or upload it for course-aligned help. Its factual source is the Core tier of `reference/module_11_notes.qmd`.

<!-- BEGIN COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

## Course-wide conventions

These apply to every module of Econ 6376, not just this one.

### The master equation

Every model in this course is the following equation with some terms switched off:

$$y_t = \alpha + \delta t + \sum_{j=1}^{p} \phi_j y_{t-j} + \sum_{l=1}^{q} \theta_l \epsilon_{t-l} + \epsilon_t$$

The course analogy is a **mixing board**: each term is a slider, and each module
turns on new ones. A student should always be able to say where the model in
front of them sits on that board. If they can't, the framing has failed — help
them locate it.

### The cardinal notation rule: DGP vs. estimation

A data-generating process and an estimating equation look different, and the
course is strict about this.

- **DGP (the truth, unobservable):** unhatted parameters $\alpha, \delta, \phi_j, \theta_l, \beta$ and $\epsilon_t$, the **innovation**.
- **Estimating equation (your model, observable):** hatted parameters $\hat\alpha, \hat\phi_j, \hat\theta_l, \hat\beta$ and $e_t$, the **residual**, where $e_t = y_t - \hat y_t$.

Never write $\epsilon_t$ when you mean $e_t$. Never drop a hat from an estimate.
A well-specified model leaves residuals that behave like the innovations that
model assumes — that is the entire basis of diagnostic testing later in the course.

### Other standing conventions

- **Lag polynomials:** AR takes minus signs, $\Phi(L) = 1 - \phi_1 L - \cdots - \phi_p L^p$. MA takes plus signs, $\Theta(L) = 1 + \theta_1 L + \cdots + \theta_q L^q$.
- **Stationarity framing:** all roots of $\Phi(L) = 0$ lie strictly **outside** the unit circle. Enders and the older course slides use the equivalent characteristic-root-**inside** framing (related by $r = 1/L$). Both are correct; flag the difference whenever a student is cross-referencing a textbook.
- **Symbols:** $\phi$ = AR coefficients, $\theta$ = MA, $\beta$ = covariates, $\alpha$ = intercept, $\delta$ = trend. $\gamma_k$ = autocovariance at lag $k$, $\rho_k$ = autocorrelation, $\gamma_0 = \operatorname{Var}(y_t)$. $L$ = lag operator, $\Delta = (1-L)$. $t = 1,\ldots,T$.
- **"Stationary"** means weakly (covariance) stationary unless stated otherwise.
- **Language:** the course is taught in R. Students may submit graded work in another language if they can reproduce the workflow, but help and debugging are R-first. Plots use `ggplot2`.
- **Credentials:** FRED keys come from `Sys.getenv("FRED_KEY")`, never hardcoded, never committed.

### Working rules

- Concept before math, always. Intuition first, then notation.
- Simulation is the center of gravity, and a simulation that only confirms the textbook is half an exercise. Breaking an assumption is where understanding happens.
- The four-step rhythm for any major topic: **Concept → Math → Simulate (break something) → Real Data.**
- The student-facing learning protocol: **Predict → Commit → Ask AI → Test in R → Reconcile.**
- **Core is the assessable surface.** Course notes are tiered (Core / Deeper Dive / Technical Note / Looking Ahead). Problem sets and exams draw **only** on Core. Optional tiers are genuinely optional — never imply otherwise.

<!-- END COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

---

## What Module 10 established

Module 8 supplied one outcome equation with current and lagged predictors.
Module 9 separated predictive precedence from structural causation. Module 10
showed that wandering levels can share a stationary relationship and used a
lagged deviation in a scalar changes equation. Giving each outcome its own
equation now lets us describe a connected system. The stationary numerical
example here is not the cointegrated walkers' level process.

## What Module 11 is about

**What does a fitted VAR coefficient actually measure?** The pond picture
separates the disturbance's source, the connections transmitting it, and the
movement observed elsewhere. Our task is to write those connections as
equations, solve them, recognize the solution in software output, and ask what
additional assumptions let us work backward to a structural explanation.

The lab follows the deck: connected equations → full scalar substitutions →
matrix recording → fitted output → identification → economic timing. The slow
algebra has a purpose: track a zero direct structural cross-lag as it becomes a
nonzero reduced coefficient. Matrices record work already understood; they do
not replace it with a prerequisite linear-algebra course.

**Mixing board:** own-variable memory and cross-variable lags are on. Each
outcome receives an equation, and reciprocal current connections are allowed.
Intercepts remain on; explicit MA terms and a deterministic trend are off.
VAR(1) means one lag of the outcome vector, not one outcome or one coefficient.

**This module's approved application of the course rhythm:** one argument runs
from concept through algebra, a fixed regression illustration and interpretation
break, to an economic timing application. Deterministic calculations are the
lab's spine. The supplied single simulated sample checks what the coefficient
table estimates; there is no required Monte Carlo or external-data exercise.

### Core learning objectives

1. Distinguish lagged feedback from reciprocal contemporaneous dependence.
2. Translate two connected equations into a structural VAR(1).
3. Derive both reduced equations, including intercepts, all lags, and shocks.
4. Read dimensions, row-by-column products, the identity, and an inverse.
5. Distinguish structural parameters, reduced parameters, and estimates.
6. Recover a recursive two-variable structure under an explicit restriction.
7. Extend the argument through three and four equations to the whole-system
   additional restriction count, stating its assumptions and limits.
8. State the system questions that IRFs and FEVD will answer later.

## 1. The connected structural equations

The current pair is jointly determined:

$$\begin{aligned}
y_t&=\alpha_y+b_{yx}x_t+\phi_{yy}y_{t-1}+\phi_{yx}x_{t-1}+\eta_{y,t},\\
x_t&=\alpha_x+b_{xy}y_t+\phi_{xy}y_{t-1}+\phi_{xx}x_{t-1}+\eta_{x,t}.
\end{aligned}$$

First subscript = receiving equation; second = entering variable. The $b$'s
refer to current connections and the $\phi$'s to lagged connections. Both
current arrows form a directed cycle, so this is a simultaneous structural
diagram, not a DAG. Lagged feedback crosses dates and does not create that
current cycle. The earlier ARDL already permitted current $x$ in $y$; the new
step is giving $x$ an equation and allowing reciprocal current dependence.

Structural disturbances $\eta_{y,t},\eta_{x,t}$ have mean zero, positive
constant variances $\omega_y,\omega_x$, are independent across dates and of
the past, and are uncorrelated with each other at the same date. These are
model assumptions, not consequences of calling the equations structural. The
simulation uses independent standard-normal draws; the algebra needs no
Gaussian assumption. The numerical model is illustrative, not calibrated to
an economy.

## 2. Solve forward before trying to work backward

Substitute the complete $x_t$ equation into the $y_t$ equation. Distribute
$b_{yx}$, including over the intercept and shock. Move the returning current
term $b_{yx}b_{xy}y_t$ to the left and collect like-dated terms. Repeat the
complete operation for $x_t$. Both yield $D=1-b_{yx}b_{xy}\ne0$:

$$\begin{aligned}
y_t={}&\frac{\alpha_y+b_{yx}\alpha_x}{D}
+\frac{\phi_{yy}+b_{yx}\phi_{xy}}{D}y_{t-1}
+\frac{\phi_{yx}+b_{yx}\phi_{xx}}{D}x_{t-1}
+\frac{\eta_{y,t}+b_{yx}\eta_{x,t}}{D},\\
x_t={}&\frac{\alpha_x+b_{xy}\alpha_y}{D}
+\frac{\phi_{xy}+b_{xy}\phi_{yy}}{D}y_{t-1}
+\frac{\phi_{xx}+b_{xy}\phi_{yx}}{D}x_{t-1}
+\frac{\eta_{x,t}+b_{xy}\eta_{y,t}}{D}.
\end{aligned}$$

The **reduced form** has only lags and innovations on the right. Name its
intercepts $a_{y0},a_{x0}$, lag coefficients $a_{yy},a_{yx},a_{xy},a_{xx}$,
and innovations $\epsilon_{y,t},\epsilon_{x,t}$. Current connections have
been absorbed into every transformed group, not discarded.

The fixed example has $\alpha_y=.2,\alpha_x=.1,b_{yx}=.5,b_{xy}=.25$ and
$(\phi_{yy},\phi_{yx},\phi_{xy},\phi_{xx})=(.3,0,.1,.4)$, with unit shock
variances. Then $D=7/8$ and
$a_{yx}=[0+.5(.4)]/.875=8/35$. Yesterday's $x$ enters today's $x$, which
enters today's $y$. The reciprocal current connection also enters the common
denominator. A zero direct lag arrow can coexist with a nonzero reduced lag.

## 3. Matrices record the same operations

Use the fixed row/column order $(y,x)$:

$$\mathbf Y_t=\begin{pmatrix}y_t\\x_t\end{pmatrix},\quad
\boldsymbol\Gamma_0=\begin{pmatrix}\alpha_y\\\alpha_x\end{pmatrix},\quad
\mathbf B=\begin{pmatrix}1&-b_{yx}\\-b_{xy}&1\end{pmatrix},\quad
\mathbf\Gamma_1=\begin{pmatrix}\phi_{yy}&\phi_{yx}\\\phi_{xy}&\phi_{xx}\end{pmatrix}.$$

Vectors are ordered columns. Each row of $\mathbf B\mathbf Y_t$ reproduces
one scalar left side after moving its current cross-variable term left.
Multiply matching row/column entries and add. Each resulting equation is a
$2\times1$ vector:

$$\mathbf B\mathbf Y_t=\boldsymbol\Gamma_0+
\mathbf\Gamma_1\mathbf Y_{t-1}+\boldsymbol\eta_t.$$

The identity $\mathbf I$ leaves a vector unchanged. The inverse undoes the
current matrix: $\mathbf B^{-1}\mathbf B=\mathbf I$. Here

$$\mathbf B^{-1}=\frac1D\begin{pmatrix}1&b_{yx}\\b_{xy}&1\end{pmatrix}.$$

Premultiply **every** term by this inverse, preserving multiplication order:

$$\mathbf Y_t=\mathbf A_0+\mathbf A_1\mathbf Y_{t-1}+\boldsymbol\epsilon_t,
\quad \mathbf A_0=\mathbf B^{-1}\boldsymbol\Gamma_0,\quad
\mathbf A_1=\mathbf B^{-1}\mathbf\Gamma_1,\quad
\boldsymbol\epsilon_t=\mathbf B^{-1}\boldsymbol\eta_t.$$

To find $a_{yx}$, use row 1 of $\mathbf B^{-1}$ and column 2 of
$\mathbf\Gamma_1$: $(\phi_{yx}+b_{yx}\phi_{xx})/D$. The receiving equation
is the row and the source lag is the column. In R, `byrow = TRUE` fills rows;
`%*%` multiplies matrices; `*` multiplies entries. `solve(B, Gamma1)` solves
$\mathbf B\mathbf A_1=\mathbf\Gamma_1$ directly.

**Invertibility is not stability.** $D\ne0$ gives a unique current solution
for supplied lags and shocks. Stability of this VAR(1) requires all eigenvalues
of $\mathbf A_1$ to have modulus below one, equivalent to lag-polynomial roots
outside the unit circle. The fixed example passes that brief check. Individual
entries below one do not suffice. We do not develop companion matrices here.

## 4. What the software estimates

The lag regressions estimate $\hat{\mathbf A}_0,\hat{\mathbf A}_1$ and leave
residuals $\mathbf e_t$. Reduced innovations have conditional mean zero given
the included history under our assumptions, so equation-by-equation OLS has
the appropriate regressor orthogonality. Contemporaneous correlation **across
equations** is different from correlation with past regressors.

With diagonal $\boldsymbol\Omega=\operatorname{diag}(\omega_y,\omega_x)$,

$$\boldsymbol\Sigma=\mathbf B^{-1}\boldsymbol\Omega(\mathbf B^{-1})'
=\begin{pmatrix}80/49&48/49\\48/49&68/49\end{pmatrix}$$

in the fixed example. The prime transposes rows and columns. Both innovations
contain both structural shocks, explaining their covariance even though the
structural shocks were uncorrelated. $\boldsymbol\Sigma$ is an **innovation**
covariance, not the covariance of raw observed series.

The supplied illustration uses seed 637611, 2,000 retained observations,
250 burn-in transitions, and initialization at the system mean. Preserve the
draws: sampling discrepancies are evidence to interpret, not a reason to
search for a seed. A test of $a_{yx}=0$ tests
$\phi_{yx}+b_{yx}\phi_{xx}=0$ when $D\ne0$. It is a predictive restriction;
it is generally different from testing $\phi_{yx}=0$.

**Interpretation break:** regress current $y$ on current $x$ and both lags.
Current $x$ contains $b_{xy}\eta_y/D$, so
$\operatorname{Cov}(x_t,\eta_{y,t}\mid\mathcal F_{t-1})=b_{xy}\omega_y/D$.
Structural OLS orthogonality fails. Its population current slope is
$\Sigma_{yx}/\Sigma_{xx}=12/17$, not the generating $.5$. Reversing the
regression gives $\Sigma_{yx}/\Sigma_{yy}=.6$, not $.25$. More observations
do not remove this dependence. Do not combine these two separate slopes into
one identified simultaneous system.

## 5. Identify under a stated restriction

Now treat only $\mathbf A_0,\mathbf A_1,\boldsymbol\Sigma$ as known.
The generating zero $\phi_{yx}=0$ is not supplied to the analyst as an extra
restriction. Three covariance entries face four current/shock unknowns:
$b_{yx},b_{xy},\omega_y,\omega_x$. Own-current coefficients are already
normalized to one. Unrestricted structural lags and intercepts can adapt to
an admissible $\mathbf B$ through $\boldsymbol\Gamma_0=\mathbf B\mathbf A_0$
and $\mathbf\Gamma_1=\mathbf B\mathbf A_1$.

Impose $b_{yx}=0$ (**y first**). Then
$\epsilon_y=\eta_y$, $\epsilon_x=b_{xy}\eta_y+\eta_x$, and

$$\omega_y=\Sigma_{yy},\quad b_{xy}=\Sigma_{yx}/\Sigma_{yy},\quad
\omega_x=\Sigma_{xx}-\Sigma_{yx}^2/\Sigma_{yy}.$$

Positive-definite $\boldsymbol\Sigma$ makes these variances positive. In the
fixed example this gives $b_{xy}=.6,\omega_y=80/49,\omega_x=.8$.
Alternatively impose $b_{xy}=0$ (**x first**) and recover
$b_{yx}=12/17,\omega_y=16/17,\omega_x=68/49$. Both reproduce the same
reduced intercepts, lag coefficients and covariance. Neither zero is true
for the original generator. A successful decomposition does not establish
the restriction's economic truth.

Cholesky implements a recursive ordering: `P <- t(chol(Sigma))` gives the
lower factor satisfying $\boldsymbol\Sigma=\mathbf P\mathbf P'$. R returns
the upper factor, hence the transpose. Here
$\mathbf P=\mathbf B_{y\text{ first}}^{-1}\boldsymbol\Omega_{y\text{ first}}^{1/2}$
uses the **recovered recursive** objects, not the original simultaneous ones.

## 6. Three equations, four equations, and the general count

For a separate **quarterly illustration**, use order $(u,\pi,i)$:
unemployment, inflation, federal funds rate. Here $u$ is an outcome, not a
disturbance. Each equation has an unrestricted intercept and one lag of all
three variables, collected as $q_{j,t-1}$. Current connections are

$$\begin{aligned}
u_t&=q_{u,t-1}+b_{u\pi}\pi_t+b_{ui}i_t+\eta_{u,t},\\
\pi_t&=q_{\pi,t-1}+b_{\pi u}u_t+b_{\pi i}i_t+\eta_{\pi,t},\\
i_t&=q_{i,t-1}+b_{iu}u_t+b_{i\pi}\pi_t+\eta_{i,t}.
\end{aligned}$$

With unit-diagonal $\mathbf B_3$ and diagonal positive
$\boldsymbol\Omega_3$, six current coefficients plus three shock variances
face six distinct reduced innovation covariance entries: three more
restrictions are needed by the count. Choose
$b_{u\pi}=b_{ui}=b_{\pi i}=0$. Unemployment cannot respond to current
inflation or policy within the quarter; inflation cannot respond to current
policy. Policy may respond to both. All lags remain.

The first two equations recover
$\omega_u=\Sigma_{uu}$, $b_{\pi u}=\Sigma_{u\pi}/\Sigma_{uu}$, and
$\omega_\pi=\Sigma_{\pi\pi}-\Sigma_{u\pi}^2/\Sigma_{uu}$. Recover both
policy coefficients **together**:

$$\begin{pmatrix}\Sigma_{uu}&\Sigma_{u\pi}\\\Sigma_{u\pi}&\Sigma_{\pi\pi}\end{pmatrix}
\begin{pmatrix}b_{iu}\\b_{i\pi}\end{pmatrix}
=\begin{pmatrix}\Sigma_{ui}\\\Sigma_{\pi i}\end{pmatrix},\qquad
\omega_i=\Sigma_{ii}-b_{iu}\Sigma_{ui}-b_{i\pi}\Sigma_{\pi i}.$$

One covariance ratio alone mixes the direct and through-inflation routes.
Positive-definite $\boldsymbol\Sigma_3$ gives a unique recovery under this
ordering and positive remaining variances. This does not select the timing
story or establish a fitted Phillips curve or policy rule.

Add $g_t=100\Delta\log(\mathrm{real\ GDP}_t)$ first, giving quarterly order
$(g,u,\pi,i)$. Four equations have 12 current cross-coefficients and four
shock variances, against ten covariance entries. The six recursive zeros are
the earlier three plus $b_{gu}=b_{g\pi}=b_{gi}=0$. The new GDP-growth equation
cannot respond to the other current outcomes; later equations may respond
to current GDP growth. All four lags remain available in every equation.
Rates and growth do not by themselves establish stationarity.

In general, maintain unit diagonal $\mathbf B$, diagonal positive
$\boldsymbol\Omega$, and unrestricted structural intercepts and lags:

$$\underbrace{m(m-1)+m}_{m^2\text{ current/shock unknowns}}
-\underbrace{\frac{m(m+1)}2}_{\text{distinct innovation covariance entries}}
=\frac{m(m-1)}2.$$

This is an **additional whole-system order requirement**, beyond the already
imposed normalization and shock assumptions. It is not a count per equation
and not sufficient for an arbitrary restriction set. A consistent recursive
ordering places $(m-1)+(m-2)+\cdots+1$ zeros above the diagonal and permits
successive recovery when the reduced covariance is positive definite.

## 7. Defend the interpretation

Return explicitly to the **monthly** pair $y=$ inflation, $x=$ policy rate.
Inflation first assumes no current policy response in measured inflation
within the month, while policy can respond to current inflation. Policy first
asserts the reverse exclusion. Publication dates, policymakers' information,
aggregation and frequency bear on these claims. The covariance fit and
lagged Granger predictability do not decide between the orderings. This is a
timing application, not an estimated monetary-policy effect.

### Vocabulary and recurring misconceptions

| Term | Meaning here |
|---|---|
| Structural coefficient | A direct connection in the proposed generating equation |
| Reduced coefficient | A transformed conditional predictive coefficient |
| Structural shock $\eta$ | Disturbance in a specified structural equation |
| Reduced innovation $\epsilon$ | Unpredictable part given the included past |
| Residual $e$ | Observed outcome minus fitted value; estimates carry hats |
| Identification | Recovery given stated information and restrictions |
| Recursive ordering | Current exclusions allowing successive determination |
| Positive-definite covariance | Every nonzero linear combination has positive variance |

Watch for: treating current arrows as lagged ones; calling a current cycle a
DAG; dropping intercept or shock terms during substitution; reversing matrix
order; confusing $\mathbf A_0$ with $\mathbf B$; assuming $D\ne0$ proves
stability; reading $\hat a$ as $\phi$; treating covariance fit as proof of
timing; and calling any correctly counted set of zeros identifying. Ask what
object a claim concerns before correcting it.

## Handoffs — Core questions and optional later development

Knowing the purposes of IRFs and FEVD is Module 11 Core. Module 12 develops IRFs: each outcome's response path after a specified
identified disturbance. Module 13 develops FEVD: the horizon-specific shares
of forecast-error variance attributed to identified disturbances. FEVD is not
regression $R^2$ or a share of every observed movement. Both depend on
identification. Module 13 also returns to the cointegrated walkers through
VECMs. Full IRF, FEVD, VECM, companion-matrix and lag-selection workflows are
not additional requirements in this pack.

**Preview license:** if a student asks for IRFs, FEVD, VECMs, or later
machinery, build it on request, label it a preview, and connect it back to Core
— never deflect the question merely because it comes later.
