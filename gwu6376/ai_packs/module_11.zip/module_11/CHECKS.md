# The shared referee — Module 11

Run `Rscript R/checks.R` from this pack's root. The checks use base R only,
print six PASS/FAIL lines, and exit nonzero if any fail. During a Quarto render,
a failure prints without aborting the remaining lab; read the verdict. The lab
sources the checks into a new environment so its own objects remain intact.

These are checks on specific algebra and implementation claims, not an answer
key or a test of the economic truth of a restriction. They reconstruct the
shipped baseline independently; passing does not certify every student edit.

| Check | Assertion | A failure usually suggests |
|---|---|---|
| 1. Scalar and matrix map | Both scalar coefficient formulas agree with the matrix solve and exact fractions. Supplied past/shock inputs satisfy both original equations. | A sign, row/column order, forgotten intercept/shock, or elementwise multiplication error. |
| 2. Mixing and stability | Scalar covariance formulas equal the transformed covariance; the baseline is positive definite and dynamically stable. The same invertible current matrix also permits an unstable lag specification. | Incorrect transpose, confused shock versus innovation covariance, or conflated invertibility and stability. |
| 3. Fixed sample and OLS | The canonical seed/draw order supplies 2,000 correctly dated rows. Recovered shocks satisfy the original structural equations. Reduced OLS agrees with a matrix projection, and naive current slopes equal the appropriate residual-covariance ratios. | Changed draw order/burn alignment, current-versus-lag indexing, or mismatched regression samples. No closeness-to-truth threshold is imposed on estimates. |
| 4. Recursive alternatives | Both explicit restrictions produce positive shock variances and reconstruct the same reduced intercept, lag matrix, and covariance, although each zero is false for the generator. | Reversed restriction, wrong denominator, failure to transform structural lags/intercepts, or treating the two naive slopes as one simultaneous structure. |
| 5. Three-equation recovery | A labelled arithmetic fixture admits the joint solve for the last equation and positive remaining variances. Reconstruction succeeds; the direct coefficient differs from a single covariance ratio. | Solving policy coefficients separately instead of jointly, or subtracting the wrong explained-variance term. |
| 6. Count and Cholesky | The whole-system gaps for two through five equations equal the upper-triangle recursive zero counts. The lower Cholesky factor equals the impact factor from the recovered y-first structure. | Double-counted covariances, per-equation instead of whole-system counting, R's upper-factor convention, or use of generating rather than recovered recursive matrices. |

The third check verifies projection identities, not finite-sample unbiasedness
or statistical inference calibration. The fifth uses a covariance matrix chosen
for arithmetic only, with no macroeconomic estimate or new DGP. The sixth
verifies the count and one workable construction: it does not establish that
any restriction set with that many zeros identifies a general model.

The equations and seeded illustration are grounded in Core §§11.3–11.6 of
`reference/module_11_notes.qmd`. The checks do not establish stationarity,
exogeneity, economic timing, or causal identification in an external dataset.
