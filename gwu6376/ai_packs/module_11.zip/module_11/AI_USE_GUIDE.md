# Using AI Well in This Course

**Econ 6376 — Module 11**

This is written for you, not for the assistant. It's about getting real value out
of an AI tutor instead of the appearance of value.

---

## The short version

AI is extraordinarily good at the things that used to waste your time in a course
like this — debugging R, explaining notation, generating variations of a
simulation, answering the question you were embarrassed to ask in class. Use it
for all of that, freely.

It is much less good at the thing this course actually grades: *judgment about
ambiguous evidence*. Whether an economic timing restriction is defensible,
or whether a fitted coefficient supports a structural interpretation, is not a fact
to be retrieved. It's a call you make and
defend.

Use AI to build the judgment. Don't use it to skip the judgment.

---

## Productive uses

- **Debugging.** "This chunk errors, here's the message." Get the fix, move on. Don't romanticize struggling with a missing comma.
- **Explaining notation.** "Why are a structural shock $\eta_t$, reduced innovation $\epsilon_t$, and fitted residual $e_t$ different?" Exactly the kind of thing a textbook assumes you'll absorb by osmosis.
- **Generating variations.** "Set one current connection to zero and recompute the reduced coefficients." Cheap, fast, and the fastest route to intuition about how much one realization can and can't tell you.
- **Being challenged.** "I think a nonzero VAR cross-lag proves a direct structural lag effect. Push back on me." Asking to be argued with is the single highest-value prompt in this course.
- **Rubber-ducking.** Explain why uncorrelated structural shocks can yield correlated innovations, and let the AI find the hole. You'll often find it yourself mid-sentence.
- **Chasing tangents.** "What if policy came first in the recursive ordering?" Turn it into a matrix calculation and find out. Your tutor is instructed to help you do this rather than steer you back to the syllabus.
- **Translating textbooks.** Paste a confusing passage from Enders or Hyndman and ask it to reconcile the notation with the course's. See `TEXTBOOK_MAP.md`.

## Unproductive uses

- **Asking for the interpretation before you've formed one.** "Does a successful Cholesky decomposition prove the economic ordering?" gets you a fluent paragraph you'll forget. Name your pick and your reason first, then ask it to critique yours.
- **Accepting numbers you didn't check.** LLMs produce confident, plausible, wrong arithmetic — matrix products, covariance ratios, "the direct effect is...". Run it.
- **Letting it pick whichever ordering gives the desired structural story.** That hides exploratory selection — whoever does the choosing.
- **Letting it write your log.** See below.
- **Using it as a search engine for the answer to a graded question.** Permitted, but see the section on assessed work — it doesn't work as well as it feels like it should.
- **Never disagreeing with it.** If you've gone ten sessions without once finding the AI wrong, you aren't checking. It is wrong regularly on this material.

---

## Verification habits

The pack is built so you never have to take anyone's word for anything — mine, or
your tutor's.

**Test claims in R.** Numerical implications of Module 11 can be checked.
"A zero structural cross-lag forces a zero reduced cross-lag" — compute
both. "The two recursive orderings cannot fit the same covariance" —
reconstruct the reduced moments under each restriction. R can verify these numerical claims
under the shipped specification. Observational data alone
cannot certify causal identification by passing a computational check.

**Use `R/checks.R` as a referee.** It holds six assertions about the shipped
algebra, fixed simulation, and recovery, in readable R. Run `Rscript R/checks.R` any time.
If something you were told contradicts a passing check within its stated scope,
the check wins. Passing checks do not certify arbitrary changes or causal claims.

**Watch for these specific failure modes.** In my experience they're the common
ones on this material:

- Reading a reduced coefficient as the corresponding primitive structural coefficient.
- Confusing current dependence with lagged feedback.
- Calling a reciprocal current diagram a DAG.
- Confusing invertibility of B with dynamic stability.
- Treating cross-equation innovation correlation as history dependence.
- Combining both naive current-variable OLS slopes into one identified system.
- Treating a correct covariance reconstruction as proof of economic timing.
- Treating the restriction count as sufficient for any arrangement of zeros.

**A good habit:** when the AI tells you something surprising, ask "how would I
check that in R?" before asking anything else. If it can't propose a check, be
suspicious of the claim.

---

## Graded work

**AI assistance is permitted on take-home graded work in this course** —
problem sets and the take-home midterm — **with disclosure.** The final is an
in-person, closed-book, paper-and-pencil exam, so no devices or AI may be used
during it. You may use this pack to prepare for the final.

Disclosure is a brief, free-form statement of how you used it. No form, no
template, no penalty. It just has to be honest and specific enough to be
meaningful. Two sentences is plenty:

> *I used Claude to debug the lag alignment in Question 1
> and to explain a `embed()` error message in Question 2. The reading of the
> results in Question 3 is my own, though I asked Claude to argue for the
> opposite conclusion before I settled on mine.*

That's a complete disclosure. Notice it says what was done *where* — "I used AI"
alone doesn't tell me anything.

Your `LEARNING_LOG.md` is **not** the disclosure vehicle. The log is private and
I never see it. Disclosure goes with the submitted work.

### Why pasting through answers won't carry you

I want to be straightforward about this rather than issue a warning.

The assessments in this course are built to be AI-resilient, and they draw
**only** on the Core tier of the module notes. They ask you to interpret
ambiguous output, reconcile two results that disagree, explain why a method
failed, and defend a judgment call. Those questions don't have retrievable
answers — the evidence is genuinely ambiguous, which is the point, and what gets
graded is the quality of your reasoning about the ambiguity.

An answer you didn't build, you can't defend. That shows up immediately in the
follow-up parts of a question, and it shows up badly on a take-home where you had
plenty of time.

So the policy isn't a trap. Using AI heavily and understanding the material are
completely compatible — that's the intended outcome, and it's how you'll work
professionally. Using AI heavily *instead of* understanding the material is a
strategy that fails at the assessment, and more importantly fails in the job
where nobody tells you which model to fit.

---

## About the contract

`AI_TUTOR_CONTRACT.md` asks your tutor to do things like request a prediction
before running a simulation, and to ask for your own words before writing the
last two fields of your learning log.

The prediction ask pauses for one turn — it will hand you two or three options
and wait once. Answer it, or say "just run it" and it runs immediately and drops
the question. It will not ask you twice, and you can tell it to skip predictions
entirely for the whole session. It's your session.

I'd just say plainly: the contract is there for your benefit, not as a rule
you're being held to. The prediction step exists because being surprised is how
things stick, and skipping it feels efficient in the moment and costs you in
November. Overriding it is a choice you're making about your own learning, and
you're an adult — I only want you making the choice knowingly rather than by
accident.

That's the last I'll say about it.

---

## Intellectual ownership

The point of this course is that you become someone who can take an unfamiliar
series, work out what it is, and defend a modeling decision to a skeptical room.

That capability is built by making predictions, being wrong, and figuring out
why. It is not transferable from a model, and it is not something you can borrow
under deadline. An AI can accelerate every step of building it — and it can also
let you produce work that looks like the finished product without any of the
building having happened.

Both paths are available to you here, and honestly, the second one is easier.
The difference shows up when you're the one in the room who has to say what the
data means.
