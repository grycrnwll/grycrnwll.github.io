# Inputs and provenance — Module 11

**No external data are required or bundled.** The application is an economic
timing discussion. It is not a fitted empirical monetary-policy exercise.

The lab writes the fixed inputs directly from the canonical course notes,
Core §§11.3–11.6. In variable order `(y, x)`:

- Structural intercepts: `Gamma0 = c(0.2, 0.1)`.
- Current matrix: `B = matrix(c(1, -0.5, -0.25, 1), 2, byrow = TRUE)`.
- Structural lag matrix: `Gamma1 = matrix(c(0.3, 0, 0.1, 0.4), 2, byrow = TRUE)`.
- Structural covariance: `Omega = diag(2)`.

These inputs define an illustrative stable VAR(1), not a calibrated economy.
Deterministic algebra and covariance calculations need no random draws.

The single regression illustration preserves the canonical `set.seed(637611)`,
`n = 2000`, `burn = 250`, and `matrix(rnorm(2 * (n + burn)), ncol = 2)` draw
order. It initializes at the system mean and retains correctly paired current
and previous values. It uses R's default RNG settings, as the notes do; run in
a fresh R session. Do not reseed to make estimates closer to their targets.
No simulated file is saved: running the lab regenerates the same example.

The three-variable covariance fixture `matrix(c(4,2,1,2,3,2,1,2,5), 3,
byrow = TRUE)` is newly authored arithmetic verification of the notes' symbolic
recovery formulas. It is explicitly not macroeconomic data, a new substantive
DGP, or an empirical estimate. The three/four-variable economic examples
remain symbolic quarterly illustrations; the two-variable application is
explicitly monthly. Neither has an observed sample, vintage, or missing-data
pattern to report.

There is no data refresh step. Changes to the canonical model require deliberate
regeneration and rechecking, not an online refresh. External-data explorations
should use separately documented files and disclose definitions, dates,
frequency, transformations, gaps, and vintage. Never commit a key or other
credential; any future FRED access uses `Sys.getenv("FRED_KEY")`.
