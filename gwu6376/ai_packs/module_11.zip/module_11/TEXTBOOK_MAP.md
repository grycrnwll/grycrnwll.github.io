# Textbook map — Module 11

Pointers and original notation translations only. No textbook text or PDFs are
bundled. These locations are grounded in the instructor-authored “Textbook
Connections and Notation” section of `reference/module_11_notes.qmd`. Optional
reading does not enlarge the assessable Core boundary. **(verify)** marks an
edition-specific location the course notes do not document; confirm before
citing rather than guessing.

| Concept | Enders, *Applied Econometric Time Series*, 4th ed. | Hamilton, *Time Series Analysis* | Course anchor |
|---|---|---|---|
| Structural/reduced mapping and mixed innovations | Ch. 5 §§5–6, pp. 285–286 within the assigned pp. 285–294 span | §11.6, especially pp. 326–330 | §§11.2–11.5; work through the scalar equations first |
| Reduced-form estimation and current-regressor endogeneity | Ch. 5 §§5–6, pp. 290–291 | §11.6, especially pp. 326–330 | §11.5; separate predictive targets and structural effects |
| Identification and a recursive exclusion | Ch. 5 §§5–6, pp. 292–294 | §11.6, especially pp. 326–330 | §11.6; actually recover coefficients and variances |
| Larger-system restriction count | Ch. 5 for background; exact larger-system location **(verify)** | Exact count location **(verify)** | §11.6 and the supplementary sources below |
| IRFs and variance decomposition, later-module preview only | Exact section/page pointer **(verify)** | Neighboring sections of Ch. 11; precise section/page **(verify)** | §11.7 states the questions; full development comes later |

**Hyndman and Athanasopoulos, *Forecasting: Principles and Practice*:** a
precise structural-VAR identification location is not grounded in the course
notes **(verify)**. Use the grounded companion readings above, or translate an
actual passage supplied by the student. Do not invent a section or edition.

For the larger-system extension, Dieppe, Legrand, and van Roye (2016),
[*The BEAR Toolbox*, ECB Working Paper 1934](https://www.ecb.europa.eu/pub/pdf/scpwps/ecbwp1934.el.pdf),
§§4.4–4.5, pp. 77–79, supports the covariance count and recursive factorization.
Its impact-matrix notation is not our contemporaneous coefficient matrix.

Rubio-Ramírez, Waggoner, and Zha,
[*Structural Vector Autoregressions: Theory of Identification and Algorithms
for Inference*, Atlanta Fed Working Paper 2008-18](https://danielwaggoner.net/images/data/wp0818.pdf),
supports the distinction between a count and actual identification for a
general restriction pattern. The canonical notes do not document an exact page
for this pointer **(verify)**. Both papers are optional background.

## Translate notation before borrowing a formula

| Feature in another treatment | Course translation |
|---|---|
| Enders' scalar current cross-variable terms carry minus signs | This module puts plus signs on $b_{yx}x_t$ and $b_{xy}y_t$. Moving them left puts minus signs off the diagonal of $\mathbf B$. Translate the whole equation and inverse together. |
| Enders' contemporaneous matrix has plus off-diagonal coefficients | Our inverse has $b_{yx}/D$ and $b_{xy}/D$ off the diagonal. Neither convention imposes positive economic effects. |
| A contemporaneous matrix called $A_0$ | Reserve $\mathbf A_0$ for the course's reduced intercept. The current coefficient matrix is $\mathbf B$. |
| Structural/reduced shocks use different letters | Map by role: structural $\boldsymbol\eta_t$, reduced innovation $\boldsymbol\epsilon_t$, fitted residual $\mathbf e_t$. Put hats on estimates. Hamilton's precise symbols must be read from the supplied passage; do not infer roles from letters. |
| An impact matrix is called $B$ in another source | Our $\mathbf B$ multiplies current outcomes on the left. An impact matrix maps shocks into reduced innovations. Under the recovered recursive structure, $\mathbf P=\mathbf B^{-1}\boldsymbol\Omega^{1/2}$. |
| Characteristic roots/eigenvalues inside the unit circle | Equivalent lag-polynomial roots lie outside. For the present VAR(1), check eigenvalue moduli of $\mathbf A_1$; invertibility of $\mathbf B$ is separate. |
| Unemployment written $u$ | In the quarterly illustration, $u_t$ is an outcome. It is not a disturbance; disturbances retain $\eta$. |

The links locate outside readings; none is needed to execute the offline lab.
