# Module 11 referee: Rscript R/checks.R from the pack root. Base R only.
# The lab sources this into new.env(); its working objects stay untouched.
Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1")
results <- logical(0)
check <- function(label, passed, detail = "") {
  passed <- isTRUE(passed)
  results[[length(results) + 1L]] <<- passed
  cat(sprintf("%-4s %s%s\n", if (passed) "PASS" else "FAIL", label,
              if (nzchar(detail)) paste0("  [", detail, "]") else ""))
  invisible(passed)
}
run <- function(label, expr) {
  tryCatch(expr, error = function(e)
    check(paste(label, "could not run"), FALSE, conditionMessage(e)))
}

B <- matrix(c(1, -0.5, -0.25, 1), 2, byrow = TRUE)
Gamma0 <- c(0.2, 0.1)
Gamma1 <- matrix(c(0.3, 0, 0.1, 0.4), 2, byrow = TRUE)
Omega <- diag(2)
B_inverse <- solve(B)
A0 <- solve(B, Gamma0)
A1 <- solve(B, Gamma1)
Sigma <- B_inverse %*% Omega %*% t(B_inverse)
cat("Module 11 checks\n----------------\n")

run("Check 1", {
  D <- 1 - 0.5 * 0.25
  scalar_intercepts <- c((0.2 + 0.5 * 0.1) / D, (0.1 + 0.25 * 0.2) / D)
  scalar_lags <- rbind(c((0.3 + 0.5 * 0.1) / D, (0 + 0.5 * 0.4) / D),
                       c((0.1 + 0.25 * 0.3) / D, (0.4 + 0.25 * 0) / D))
  expected_lags <- matrix(c(2/5, 8/35, 1/5, 16/35), 2, byrow = TRUE)
  discrepancy <- max(abs(c(A0 - scalar_intercepts, A1 - scalar_lags,
                            A1 - expected_lags, A0 - c(2/7, 6/35),
                            B_inverse %*% B - diag(2))))
  # Each column supplies another fixed past/shock input to both scalar equations.
  previous <- matrix(c(1, -1, 0, 2, -3, 0.5), 2)
  shocks <- matrix(c(0.2, -0.3, 1, 0, -1, 2), 2)
  current <- A0 + A1 %*% previous + B_inverse %*% shocks
  equation_error <- max(abs(B %*% current - Gamma0 - Gamma1 %*% previous - shocks))
  check("1. Scalar substitution and matrix map agree for every coefficient", 
        discrepancy < 1e-12 && equation_error < 1e-12 &&
          Gamma1[1, 2] == 0 && abs(A1[1, 2] - 8/35) < 1e-12,
        sprintf("largest discrepancy=%.1e; direct lag=0; reduced lag=%.6f",
                max(discrepancy, equation_error), A1[1, 2]))
})

run("Check 2", {
  D <- 7/8
  scalar_covariance <- matrix(c((1 + 0.5^2) / D^2, (0.25 + 0.5) / D^2,
                                (0.25 + 0.5) / D^2, (0.25^2 + 1) / D^2), 2)
  eigenvalues <- eigen(A1)$values
  # Same invertible B, a deliberately unstable lag map: the conditions differ.
  Gamma1_unstable <- B %*% (1.1 * diag(2))
  eigen_unstable <- eigen(solve(B, Gamma1_unstable))$values
  ok <- max(abs(Sigma - scalar_covariance)) < 1e-12 &&
    max(abs(Sigma - matrix(c(80, 48, 48, 68), 2) / 49)) < 1e-12 &&
    Sigma[1, 2] > 0 && all(eigen(Sigma, symmetric = TRUE)$values > 0) &&
    all(Mod(eigenvalues) < 1) && all(Mod(eigen_unstable) > 1) && det(B) != 0
  check("2. Shock mixing, positive covariance and distinct stability condition", ok,
        sprintf("covariance=%.6f; baseline eigenvalues=%.6f/%.6f",
                Sigma[1, 2], eigenvalues[1], eigenvalues[2]))
})

run("Check 3", {
  set.seed(637611)
  n <- 2000; burn <- 250
  eta <- matrix(rnorm(2 * (n + burn)), ncol = 2)
  Y <- matrix(0, nrow = n + burn + 1, ncol = 2)
  Y[1, ] <- solve(diag(2) - A1, A0)
  for (tt in seq_len(nrow(eta))) {
    Y[tt + 1, ] <- A0 + A1 %*% Y[tt, ] + B_inverse %*% eta[tt, ]
  }
  keep <- (burn + 1):(burn + n)
  dat <- data.frame(y = Y[keep + 1, 1], x = Y[keep + 1, 2],
                    y_lag = Y[keep, 1], x_lag = Y[keep, 2])
  # Check the original structural equations, not only the implemented recurrence.
  eta_y_back <- dat$y - 0.2 - 0.5 * dat$x - 0.3 * dat$y_lag
  eta_x_back <- dat$x - 0.1 - 0.25 * dat$y - 0.1 * dat$y_lag - 0.4 * dat$x_lag
  equation_error <- max(abs(cbind(eta_y_back, eta_x_back) - eta[keep, ]))
  fit_y <- lm(y ~ y_lag + x_lag, dat)
  fit_x <- lm(x ~ y_lag + x_lag, dat)
  naive_y <- lm(y ~ x + y_lag + x_lag, dat)
  naive_x <- lm(x ~ y + y_lag + x_lag, dat)
  X <- model.matrix(fit_y)
  coefficient_error <- max(abs(qr.solve(X, dat$y) - coef(fit_y)))
  E <- cbind(residuals(fit_y), residuals(fit_x))
  Sigma_hat <- crossprod(E) / nrow(E)
  # Residualizing on the same past yields exactly the two naive OLS slopes.
  fwl <- c(Sigma_hat[1, 2] / Sigma_hat[2, 2], Sigma_hat[2, 1] / Sigma_hat[1, 1])
  naive <- c(coef(naive_y)["x"], coef(naive_x)["y"])
  ok <- nrow(dat) == 2000L && nrow(eta) == 2250L && equation_error < 1e-11 &&
    coefficient_error < 1e-11 && max(abs(fwl - naive)) < 1e-11 &&
    max(abs(crossprod(X, E))) < 1e-9
  check("3. Fixed draw, dated structural equations and OLS projection targets", ok,
        sprintf("rows=%d; equation error=%.1e; estimated reduced x-lag=%.6f",
                nrow(dat), equation_error, coef(fit_y)["x_lag"]))
})

run("Check 4", {
  By <- matrix(c(1, 0, -Sigma[2, 1] / Sigma[1, 1], 1), 2, byrow = TRUE)
  Oy <- diag(c(Sigma[1, 1], Sigma[2, 2] - Sigma[2, 1]^2 / Sigma[1, 1]))
  Bx <- matrix(c(1, -Sigma[1, 2] / Sigma[2, 2], 0, 1), 2, byrow = TRUE)
  Ox <- diag(c(Sigma[1, 1] - Sigma[1, 2]^2 / Sigma[2, 2], Sigma[2, 2]))
  errors <- numeric(2)
  for (j in 1:2) {
    Br <- list(By, Bx)[[j]]; Or <- list(Oy, Ox)[[j]]
    errors[j] <- max(abs(c(solve(Br, Br %*% A0) - A0,
                           solve(Br, Br %*% A1) - A1,
                           solve(Br) %*% Or %*% t(solve(Br)) - Sigma)))
  }
  ok <- max(errors) < 1e-12 && all(diag(Oy) > 0) && all(diag(Ox) > 0) &&
    abs(-By[2, 1] - 3/5) < 1e-12 && abs(-Bx[1, 2] - 12/17) < 1e-12 &&
    max(abs(diag(Oy) - c(80/49, 4/5))) < 1e-12 &&
    max(abs(diag(Ox) - c(16/17, 68/49))) < 1e-12 &&
    By[1, 2] == 0 && B[1, 2] != 0 && Bx[2, 1] == 0 && B[2, 1] != 0
  check("4. Both false recursive exclusions reproduce all reduced moments", ok,
        sprintf("largest reconstruction error=%.1e", max(errors)))
})

run("Check 5", {
  # An arithmetic fixture only, not data or a calibrated macroeconomic DGP.
  S3 <- matrix(c(4, 2, 1, 2, 3, 2, 1, 2, 5), 3, byrow = TRUE)
  b21 <- S3[1, 2] / S3[1, 1]
  b3 <- solve(S3[1:2, 1:2], S3[1:2, 3])
  variances <- c(S3[1, 1], S3[2, 2] - S3[1, 2]^2 / S3[1, 1],
                 S3[3, 3] - sum(b3 * S3[1:2, 3]))
  B3 <- diag(3)
  B3[2, 1] <- -b21; B3[3, 1:2] <- -b3
  discrepancy <- max(abs(solve(B3) %*% diag(variances) %*% t(solve(B3)) - S3))
  ok <- all(eigen(S3, symmetric = TRUE)$values > 0) && all(variances > 0) &&
    discrepancy < 1e-12 && max(abs(B3 %*% S3 %*% t(B3) - diag(variances))) < 1e-12 &&
    max(abs(b3 - c(-1/8, 3/4))) < 1e-12 && abs(b3[1] - S3[1, 3] / S3[1, 1]) > 0.1
  check("5. Three-equation joint recovery and positive remaining variances", ok,
        sprintf("last-row coefficients=%.3f/%.3f; reconstruction error=%.1e",
                b3[1], b3[2], discrepancy))
})

run("Check 6", {
  m <- 2:5
  gaps <- m * (m - 1) + m - m * (m + 1) / 2
  upper_counts <- vapply(m, function(d) sum(upper.tri(matrix(0, d, d))), integer(1))
  By <- matrix(c(1, 0, -Sigma[2, 1] / Sigma[1, 1], 1), 2, byrow = TRUE)
  Oy <- diag(c(Sigma[1, 1], Sigma[2, 2] - Sigma[2, 1]^2 / Sigma[1, 1]))
  P <- t(chol(Sigma))
  P_recovered <- solve(By) %*% diag(sqrt(diag(Oy)))
  error <- max(abs(c(P %*% t(P) - Sigma, P - P_recovered)))
  ok <- all(gaps == c(1, 3, 6, 10)) && all(upper_counts == gaps) &&
    gaps[3] - gaps[2] == 3 && error < 1e-12 && all(P[upper.tri(P)] == 0)
  check("6. Whole-system counts, recursive zeros and Cholesky orientation", ok,
        sprintf("counts=%s; lower-factor error=%.1e", paste(gaps, collapse = "/"), error))
})

n_pass <- sum(results); n_all <- length(results)
cat(sprintf("----------------\n%d/%d checks passed.\n", n_pass, n_all))
if (n_pass < n_all && !isTRUE(getOption("knitr.in.progress"))) quit(status = 1, save = "no")
