# Module 10 referee: run Rscript R/checks.R from the pack root. Base R only.
# The lab sources this script into new.env(); its inline objects stay untouched.
Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1")
results <- logical(0)
check <- function(label, passed, detail = "") {
  passed <- isTRUE(passed)
  results[[length(results) + 1L]] <<- passed
  cat(sprintf("%-4s %s%s\n", if (passed) "PASS" else "FAIL", label,
              if (nzchar(detail)) paste0("  [", detail, "]") else ""))
  invisible(passed)
}
run <- function(label, expr) {
  tryCatch(expr, error = function(e)
    check(paste(label, "could not run"), FALSE, conditionMessage(e)))
}

# Load inputs inside each guard: one missing file must not suppress later checks.
cat("Module 10 checks\n----------------\n")

run("Check 1", {
  d <- read.csv("data/module_10_consumption_income.csv")
  calendar <- 4L * d$year + d$quarter
  ok <- identical(names(d), c("year", "quarter", "realcons", "realdpi")) &&
    nrow(d) == 203L && !anyNA(d) && all(is.finite(as.matrix(d))) &&
    all(d$quarter %in% 1:4) && all(d$year == as.integer(d$year)) &&
    all(d$realcons > 0) && all(d$realdpi > 0) &&
    all(calendar == seq.int(4L * 1959L + 1L, 4L * 2009L + 3L)) &&
    max(abs(c(d$realcons[c(1, 203)], d$realdpi[c(1, 203)]) -
              c(1707.4, 9256.0, 1886.9, 10040.6))) < 1e-8
  check("1. Archive schema, positive levels and complete quarterly calendar", ok,
        sprintf("%d rows; %dQ%d to %dQ%d", nrow(d), d$year[1], d$quarter[1],
                tail(d$year, 1), tail(d$quarter, 1)))
})

run("Check 2", {
  source("R/cointegration_utils.R", local = TRUE)
  shocks_small <- matrix(sin(seq_len(36)), ncol = 3)
  d <- walkers(shocks_small, adjust_h = 0.1, adjust_m = 0.2, burn = 2)
  replay <- walkers(shocks_small, adjust_h = 0.1, adjust_m = 0.2, burn = 2)
  full <- walkers(shocks_small, adjust_h = 0.1, adjust_m = 0.2, burn = 0)
  h <- m <- k <- numeric(nrow(shocks_small) + 1L)
  for (t in seq_len(nrow(shocks_small))) {
    previous_gap <- m[t] - h[t]
    h[t + 1L] <- h[t] + 0.1 * previous_gap + shocks_small[t, 1]
    m[t + 1L] <- m[t] - 0.2 * previous_gap + shocks_small[t, 2]
    k[t + 1L] <- k[t] + shocks_small[t, 3]
  }
  expected <- cbind(h[-1], m[-1], k[-1])
  gap <- max(abs(as.matrix(full[c("Harry", "Mouse", "Karen")]) - expected))
  ok <- identical(d, replay) && nrow(d) == 10L && nrow(full) == 12L &&
    identical(d$t, seq_len(10)) && gap < 1e-12 &&
    max(abs(as.matrix(d[-1]) - as.matrix(full[3:12, -1]))) < 1e-12 &&
    max(abs(d$gap - (d$Mouse - d$Harry))) < 1e-12
  check("2. Supplied-shock replay, simulator recursion and burn indexing", ok,
        sprintf("max recursion discrepancy=%.1e", gap))
})

run("Check 3", {
  source("R/cointegration_utils.R", local = TRUE)
  set.seed(637610)
  shocks <- matrix(rnorm(3 * 1240), ncol = 3)
  settings <- c(0.1, 0.005, 0)
  cases <- lapply(settings, function(a) walkers(shocks, a, a, burn = 1000))
  innovation_gap <- shocks[1002:1240, 2] - shocks[1002:1240, 1]
  common_steps <- rowMeans(shocks[1002:1240, 1:2])
  recursion_error <- trend_error <- numeric(length(cases))
  for (i in seq_along(cases)) {
    d <- cases[[i]]
    recursion_error[i] <- max(abs(d$gap[-1] -
      (1 - 2 * settings[i]) * head(d$gap, -1) - innovation_gap))
    trend_error[i] <- max(abs(diff((d$Harry + d$Mouse) / 2) - common_steps))
  }
  gap_coefficients <- 1 - 2 * settings
  ok <- all(vapply(cases, nrow, integer(1)) == 240L) &&
    max(recursion_error, trend_error) < 1e-10 &&
    all(abs(gap_coefficients[1:2]) < 1) && gap_coefficients[3] == 1 &&
    identical(cases[[1]]$Karen, cases[[2]]$Karen) &&
    identical(cases[[2]]$Karen, cases[[3]]$Karen)
  check("3. Same shocks: stable, slow and disconnected gap constructions", ok,
        sprintf("gap coefficients=%.2f/%.2f/%.2f; max identity discrepancy=%.1e",
                gap_coefficients[1], gap_coefficients[2], gap_coefficients[3],
                max(recursion_error, trend_error)))
})

run("Check 4", {
  source("R/cointegration_utils.R", local = TRUE)
  set.seed(637610)
  d <- walkers(matrix(rnorm(3 * 1240), ncol = 3), 0.1, 0.1, burn = 1000)
  n <- nrow(d)
  e <- residuals(lm(Mouse ~ Harry, data = d))
  lag_set <- c(0L, 1L, 4L, 8L)
  difference <- numeric(length(lag_set)); row_ok <- logical(length(lag_set))
  for (i in seq_along(lag_set)) {
    p <- lag_set[i]
    fit <- eg_test(d$Mouse, d$Harry, p_adf = p)
    tt <- seq.int(p + 2L, n)
    response <- e[tt] - e[tt - 1L]
    X <- matrix(e[tt - 1L], ncol = 1L)
    if (p > 0L) for (j in seq_len(p))
      X <- cbind(X, e[tt - j] - e[tt - j - 1L])
    b <- as.numeric(qr.solve(X, response))
    residual <- as.numeric(response - X %*% b)
    se <- sqrt(sum(residual^2) / (nrow(X) - ncol(X)) * solve(crossprod(X))[1, 1])
    difference[i] <- fit$statistic - b[1] / se
    row_ok[i] <- fit$n_adf == n - 1L - p && nobs(fit$adf) == length(tt) &&
      attr(terms(fit$adf), "intercept") == 0L
  }
  sizes <- c(203L, 240L)
  expected_cv <- -3.33613 - 6.1101 / (sizes - 1L) - 6.823 / (sizes - 1L)^2
  actual_cv <- vapply(sizes, eg_cv5, numeric(1))
  ok <- all(row_ok) && max(abs(difference)) < 1e-10 &&
    max(abs(actual_cv - expected_cv)) < 1e-12 &&
    abs(eg_test(d$Mouse, d$Harry, 1)$statistic + 4.767323) < 1e-5
  check("4. EG statistic, lag rows and bivariate intercept/no-trend calibration", ok,
        sprintf("max independent statistic discrepancy=%.1e; CV(n=240)=%.6f",
                max(abs(difference)), actual_cv[2]))
})

run("Check 5", {
  source("R/cointegration_utils.R", local = TRUE)
  set.seed(637610)
  d <- walkers(matrix(rnorm(3 * 1240), ncol = 3), 0.1, 0.1, burn = 1000)
  eg <- eg_test(d$Mouse, d$Harry, p_adf = 1)
  n <- nrow(d)
  ecm <- data.frame(dm = diff(d$Mouse), dh = diff(d$Harry),
                    e_lag = eg$residuals[-n])
  fit <- lm(dm ~ e_lag + dh, data = ecm)
  fitted_gap <- head(d$Mouse, -1) - coef(eg$levels)[1] -
    coef(eg$levels)[2] * head(d$Harry, -1)
  # An identity check is not evidence that an arbitrary ARDL is cointegrated.
  alpha <- 0.3; phi <- 0.7; beta0 <- 0.2; beta1 <- 0.4
  lambda <- phi - 1; c_long <- alpha / (1 - phi)
  kappa <- (beta0 + beta1) / (1 - phi)
  y_previous <- head(d$Mouse, -1); x_previous <- head(d$Harry, -1)
  ardl_change <- alpha + (phi - 1) * y_previous +
    (beta0 + beta1) * x_previous + beta0 * ecm$dh
  ecm_change <- lambda * (y_previous - c_long - kappa * x_previous) + beta0 * ecm$dh
  ok <- nrow(ecm) == 239L && nobs(fit) == 239L &&
    max(abs(ecm$e_lag - fitted_gap)) < 1e-10 &&
    max(abs(ardl_change - ecm_change)) < 1e-10 &&
    abs(coef(fit)["e_lag"] + 0.15083077) < 1e-7
  check("5. ARDL-to-ECM identity, previous-gap alignment and shipped adjustment", ok,
        sprintf("ECM rows=%d; estimated adjustment=%.8f", nobs(fit), coef(fit)["e_lag"]))
})

run("Check 6", {
  source("R/cointegration_utils.R", local = TRUE)
  d <- read.csv("data/module_10_consumption_income.csv")
  lc <- log(d$realcons); ly <- log(d$realdpi)
  lag_set <- c(0L, 2L, 4L, 8L)
  fits <- lapply(lag_set, function(p) eg_test(lc, ly, p_adf = p))
  baseline <- fits[[3]]
  decisions <- vapply(fits, `[[`, logical(1), "reject5")
  rows <- vapply(fits, `[[`, integer(1), "n_adf")
  zero_acf <- as.numeric(acf(residuals(fits[[1]]$adf), lag.max = 2, plot = FALSE)$acf)[2:3]
  four_acf <- as.numeric(acf(residuals(baseline$adf), lag.max = 2, plot = FALSE)$acf)[2:3]
  zero_band <- 1.96 / sqrt(nobs(fits[[1]]$adf))
  reverse <- eg_test(ly, lc, p_adf = 4)
  ok <- identical(decisions, c(TRUE, FALSE, FALSE, FALSE)) &&
    all(rows == 203L - 1L - lag_set) &&
    abs(baseline$statistic + 2.58900894) < 1e-7 && !reverse$reject5 &&
    max(abs(zero_acf - c(-0.280, 0.202))) < 0.0005 &&
    max(abs(four_acf - c(-0.007, -0.004))) < 0.0005 &&
    all(abs(zero_acf) > zero_band) && all(abs(four_acf) < zero_band)
  check("6. Archive baseline, declared lag sensitivity and remaining-dependence warning", ok,
        sprintf("baseline tau=%.6f; zero-lag residual ACF=%.3f/%.3f; four-lag=%.3f/%.3f",
                baseline$statistic, zero_acf[1], zero_acf[2], four_acf[1], four_acf[2]))
})

n_pass <- sum(results); n_all <- length(results)
cat(sprintf("----------------\n%d/%d checks passed.\n", n_pass, n_all))
if (n_pass < n_all && !isTRUE(getOption("knitr.in.progress"))) quit(status = 1, save = "no")
