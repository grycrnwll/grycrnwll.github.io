# Module 10 Context — Cointegration and Error Correction

**Econ 6376 — Applied Time Series Econometrics, George Washington University (Applied Economics MA).**

This file is self-contained. Paste or upload it on its own into any AI
assistant for course-aligned help with Module 10. The factual source is the
Core tier of `reference/module_10_notes.qmd`.

<!-- BEGIN COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

## Course-wide conventions

These apply to every module of Econ 6376, not just this one.

### The master equation

Every model in this course is the following equation with some terms switched off:

$$y_t = \alpha + \delta t + \sum_{j=1}^{p} \phi_j y_{t-j} + \sum_{l=1}^{q} \theta_l \epsilon_{t-l} + \epsilon_t$$

The course analogy is a **mixing board**: each term is a slider, and each module
turns on new ones. A student should always be able to say where the model in
front of them sits on that board. If they can't, the framing has failed — help
them locate it.

### The cardinal notation rule: DGP vs. estimation

A data-generating process and an estimating equation look different, and the
course is strict about this.

- **DGP (the truth, unobservable):** unhatted parameters $\alpha, \delta, \phi_j, \theta_l, \beta$ and $\epsilon_t$, the **innovation**.
- **Estimating equation (your model, observable):** hatted parameters $\hat\alpha, \hat\phi_j, \hat\theta_l, \hat\beta$ and $e_t$, the **residual**, where $e_t = y_t - \hat y_t$.

Never write $\epsilon_t$ when you mean $e_t$. Never drop a hat from an estimate.
A well-specified model leaves residuals that behave like the innovations that
model assumes — that is the entire basis of diagnostic testing later in the course.

### Other standing conventions

- **Lag polynomials:** AR takes minus signs, $\Phi(L) = 1 - \phi_1 L - \cdots - \phi_p L^p$. MA takes plus signs, $\Theta(L) = 1 + \theta_1 L + \cdots + \theta_q L^q$.
- **Stationarity framing:** all roots of $\Phi(L) = 0$ lie strictly **outside** the unit circle. Enders and the older course slides use the equivalent characteristic-root-**inside** framing (related by $r = 1/L$). Both are correct; flag the difference whenever a student is cross-referencing a textbook.
- **Symbols:** $\phi$ = AR coefficients, $\theta$ = MA, $\beta$ = covariates, $\alpha$ = intercept, $\delta$ = trend. $\gamma_k$ = autocovariance at lag $k$, $\rho_k$ = autocorrelation, $\gamma_0 = \operatorname{Var}(y_t)$. $L$ = lag operator, $\Delta = (1-L)$. $t = 1,\ldots,T$.
- **"Stationary"** means weakly (covariance) stationary unless stated otherwise.
- **Language:** the course is taught in R. Students may submit graded work in another language if they can reproduce the workflow, but help and debugging are R-first. Plots use `ggplot2`.
- **Credentials:** FRED keys come from `Sys.getenv("FRED_KEY")`, never hardcoded, never committed.

### Working rules

- Concept before math, always. Intuition first, then notation.
- Simulation is the center of gravity, and a simulation that only confirms the textbook is half an exercise. Breaking an assumption is where understanding happens.
- The four-step rhythm for any major topic: **Concept → Math → Simulate (break something) → Real Data.**
- The student-facing learning protocol: **Predict → Commit → Ask AI → Test in R → Reconcile.**
- **Core is the assessable surface.** Course notes are tiered (Core / Deeper Dive / Technical Note / Looking Ahead). Problem sets and exams draw **only** on Core. Optional tiers are genuinely optional — never imply otherwise.

<!-- END COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

---

## What Module 9 established

Module 8 added observed predictors and their lags to the dynamic equation.
Its conditional interpretation depends on suitable regressor–disturbance
assumptions. Module 9 asked whether one history adds predictive information
given the other included histories. That stationary baseline leaves a new
question: what if the economically interesting levels are I(1)? Neither a
high levels correlation nor mechanically differencing everything settles
whether the levels contain a meaningful relationship.

## What Module 10 is about

**How can two series keep wandering while a relationship between them stays
stationary?** Start with Harry, his puppy Mouse, and Karen leaving the bar.
Follow their locations, changes, and separation before naming cointegration.
Then estimate the relationship, test it, use yesterday's deviation in a
dynamic equation, and confront less decisive economic evidence.

Read Murray's (1994) *A Drunk and Her Dog* alongside the lab, especially
pp. 37–38. Harry/Mouse/Karen are the instructor's adaptation of its mechanism;
the R simulation is a new course illustration, not Murray's figure reproduced.
The reading map supplies the bibliographic pointer; no PDF is bundled here.

**Mixing board:** keep the ARDL intercept, outcome memory, and observed
predictor terms. Explicit MA terms and a separate deterministic trend are
off in the baseline relation. The new feature is a stationary combination
of I(1) levels, which may enter a changes equation as a lagged deviation.
The intercept in an individual-series unit-root test and its trend option
serve that test's hypothesis; they need not match the levels relation.

### Core learning objectives

1. Identify the stationary object in the I(1)/I(0) definition of cointegration.
2. Distinguish it from correlation, deterministic trends, hard bounds,
   normalization, and causal or structural claims.
3. Explain how economists use long-run relationships and why evidence for
   some relationship need not validate a theory's particular weights.
4. Conduct and interpret an Engle–Granger residual test with its matching
   critical values, including nonrejection and specification sensitivity.
5. Read a scalar ECM as short-run dynamics plus a response to yesterday's
   deviation; connect it to the ARDL algebra without treating algebra as proof.
6. Report data definitions, integration evidence, specification, diagnostics,
   uncertainty, and the model the evidence warrants.

## 1. Last call: build the wandering before naming the relationship

Let $H_t$, $M_t$, and $K_t$ be Harry's, Mouse's, and Karen's locations:

$$\begin{aligned}
\Delta H_t&=a(M_{t-1}-H_{t-1})+\epsilon_t^H,\\
\Delta M_t&=-b(M_{t-1}-H_{t-1})+\epsilon_t^M,\\
\Delta K_t&=\epsilon_t^K.
\end{aligned}$$

The three innovations are independent standard-normal draws across characters
and time in this constructed world. When Mouse is ahead, the signed gap is
positive: Harry's correction moves him forward and Mouse's moves him back.
New shocks still affect their observed steps. After introducing correction,
Harry and Mouse are generally no longer literal random walks with independent
increments, even though their levels remain I(1).

The canonical run keeps 240 observations after 1,000 initialization steps,
using seed 637610 and $a=b=0.1$. Reuse the supplied shocks when changing the
rules. The initialization reduces a stable gap's starting transient; it
cannot make a disconnected random-walk gap stationary. `walkers()` implements
this unit-slope story; it does not offer a general slope parameter.

Compare locations, changes, and $M_t-H_t$ with $K_t-H_t$. A model of changes
alone has no explicit measure of accumulated separation. Differencing is a
valid transformation; the issue is which predictors the model retains.

Murray's dog has **no physical leash**. A stationary gap can be large,
persistent, and occasionally widen. It need not be zero or obey a fixed
distance limit. Both parties need not adjust: one can do the correcting.
Their relationship and the allocation of adjustment are separate questions.

## 2. Name the stationary object, including its weights

The baseline definition is

$$x_t\sim I(1),\qquad y_t\sim I(1),\qquad
z_t=y_t-c-\kappa x_t\sim I(0).$$

The **cointegrating deviation** $z_t$ is a population object. Here equilibrium
means a reference relationship; it does not establish market clearing or a
structural economic theory. The intercept $c$ permits a nonzero mean
relationship; $\kappa$ is its normalized long-run slope.

The **cointegrating vector** is $(1,-\kappa)$. A nonzero multiple represents
the same relationship. Writing a coefficient of one on $y$ is a
**normalization**, not a claim about causal direction. If
$y_t=2+3x_t+z_t$, the stationary object is $y_t-2-3x_t$; the raw difference
$y_t-x_t$ retains the I(1) component. Murray's teeter-totter analogy allows
a weighted sum: negative $\kappa$ permits opposite-direction movement.

Keep these objects separate:

| Object | Meaning |
|---|---|
| $z_t=y_t-c-\kappa x_t$ | Population deviation, I(0) under cointegration; can be serially dependent |
| $e_t=y_t-\hat c-\hat\kappa x_t$ | Residual from the estimated levels relation |
| $\epsilon_t$ | Innovation in a specified DGP, not a fitted residual |
| $e_t^{ADF}$ or $e_t^{ECM}$ | Remaining residual of the fitted test or dynamic regression |

Two I(1) series need not be cointegrated. Two already stationary series do
not supply the I(1)-to-I(0) reduction studied here. Canceling deterministic
trends is a different source of nonstationarity from canceling stochastic
trends. A high correlation, similar plots, or an ordinary significant levels
slope does not establish a stationary combination. Nor does cointegration
by itself identify a common driver, behavioral mechanism, or intervention
effect.

## 3. Would we detect the relationship?

Engle–Granger makes the estimated deviation the testing object. First inspect
variable definitions, dates, gaps, plots, and possible breaks; assess whether
an I(1) description is reasonable with tests on levels and changes. Unit-root
nonrejection is not proof. The simple bivariate procedure is not justified
mechanically if an input is I(0) or I(2).

Estimate $y_t=\hat c+\hat\kappa x_t+e_t$ using an intercept and no time trend
in the baseline levels relation. For the story use Mouse on Harry, then
Karen on Harry. OLS with an intercept mechanically centers residuals; this
does not make them stationary. Save $e_t$, then specify

$$\Delta e_t=\gamma e_{t-1}
+\sum_{j=1}^{p_e}\psi_j\Delta e_{t-j}+\epsilon_t^{ADF}.$$

This is the test-regression specification; estimated coefficients carry hats
and its fitted residual is distinct from $e_t$. Test **no cointegration**
against a stationary combination using
$\tau_{EG}=\hat\gamma/\widehat{\operatorname{se}}(\hat\gamma)$.
Sufficiently negative values favor reversion under the maintained I(1) setup.
The $p_e$ lagged differences accommodate short-run dependence. Too few can
leave dependence; too many spend observations and degrees of freedom.

The residual regression adds no intercept or trend because the first-stage
intercept has been projected out. **Its reference distribution still reflects
estimation of that first-stage relationship.** Ordinary regression t-values
and ordinary ADF critical values are inappropriate. `urca::ur.df()` can
verify the statistic; its default critical values do not become Engle–Granger
values when its input happens to be a fitted residual.

The pack's `eg_test()` is deliberately narrow: **two variables, an intercept
without trend in the levels relation, and a 5% decision**. It assumes
already aligned, complete, equally spaced observations. Its MacKinnon (2010)
response-surface approximation is

$$\operatorname{CV}_{0.05}(n_c)
=-3.33613-\frac{6.1101}{n_c}-\frac{6.823}{n_c^2},\qquad n_c=n-1.$$

Here $n$ counts levels observations; the test regression uses $n-1-p_e$
rows. Neither that row count nor residual degrees of freedom replaces $n_c$.
This implementation convention does not promise exact finite-sample 5% size.
Different deterministic specifications or numbers of variables require
matching methods and reference values.

### Change the rules, not the shocks

Compare $a=b=0.1$ (connected), $a=b=0.005$ (slow), and $a=b=0$ (disconnected),
holding shocks and the one-lag test specification fixed. The connected and
slow worlds are cointegrated by construction; the disconnected world is not.
Slow correction produces nonrejection in this sample. That is a power
problem, not a change in the population property. A disconnected-world
rejection would be a false positive. A shorter window changes available
evidence, not the DGP. Do not search seeds for a convenient result.

Rejection supports cointegration under the maintained specification.
Nonrejection supplies insufficient evidence; it does not prove the absence
of an economic relationship. Diagnose the **test regression's remaining
residuals**, distinct from the potentially autocorrelated levels deviation.
Report declared sensitivity rather than selecting only a rejecting result.

## 4. Now what? Yesterday's gap can help explain today's step

An **error-correction model (ECM)** retains a lagged deviation alongside
short-run changes. Start with the familiar ARDL(1,1):

$$y_t=\alpha+\phi_1y_{t-1}+\beta_0x_t+\beta_1x_{t-1}+\epsilon_t.$$

Subtract $y_{t-1}$ and substitute $x_t=x_{t-1}+\Delta x_t$. For
$\phi_1\ne1$, define

$$\lambda=\phi_1-1,\qquad c=\frac{\alpha}{1-\phi_1},\qquad
\kappa=\frac{\beta_0+\beta_1}{1-\phi_1}.$$

Then the same equation becomes

$$\Delta y_t=\lambda(y_{t-1}-c-\kappa x_{t-1})
+\beta_0\Delta x_t+\epsilon_t.$$

Reserve $\alpha$ for the ordinary equation intercept, $\kappa$ for long-run
weights, and $\lambda$ for scalar adjustment. With this gap normalization,
negative $\lambda$ contributes downward movement when $y$ was high relative
to the relationship. Reverse the gap's sign and its coefficient reverses,
leaving the contribution unchanged. A negative coefficient alone does not
establish cointegration or stability of the whole dynamic system.

In the known connected DGP, Mouse's adjustment is $-b=-0.1$: a previous
gap of $+2$ contributes $-0.2$ to Mouse's change. This is not a guaranteed
percentage reduction in the observed gap. Harry also moves, and new shocks
and other regressors affect the outcome. The fitted ECM uses
$e_{t-1}=M_{t-1}-\hat c-\hat\kappa H_{t-1}$; both the relation and dynamics
are estimated, so finite-sample coefficients need not equal generating values.

Current $\Delta x_t$ changes the information set from Module 9's past-only
comparison. Suitable contemporaneous-dependence and exogeneity assumptions
still matter; the simulation's independent current innovations do not carry
over automatically to economic data. One equation may adjust weakly or not
at all while the other variable corrects. Neither normalization nor a
predictive response automatically identifies causality.

**The rearrangement is algebra.** A stationary deviation and an appropriate
dynamic specification supply the cointegration interpretation. A model of
changes alone can omit a useful lagged deviation, but an ECM does not promise
universal forecasting gains.

## 5. Economics gets a vote

Economic theory suggests relationships to investigate: consumption and
income, yields of different maturities, purchasing-power parity, and money
demand. Engle–Granger's historical consumption and yield examples support
cointegration; Hamilton's U.S.–Italy PPP example finds little evidence.
These are results for particular definitions, samples, and procedures.
Finding some $\kappa$ is weaker than validating a theory's required weights,
such as a stationary unit-weight yield spread. Ordinary OLS slope tests do
not establish those restrictions.

The lab's offline data contain **203 quarters, 1959Q1–2009Q3**, from a
**December 2009 archive**: aggregate total real personal consumption
expenditures and real disposable income, billions of chained 2005 dollars,
seasonally adjusted annual rates. This is neither today's vintage nor a
replication of Engle–Granger's per-capita nondurables sample. Logs describe
proportional association; they do not remove stochastic trends or turn the
slope into a dollar marginal propensity to consume or a causal elasticity.

Individual log-level ADF tests use intercept and trend; tests on changes use
an intercept. Each uses four lagged differences as a teaching specification.
Levels do not reject and changes do, supporting an I(1) working description
without proving it. Ordinary individual-series critical values apply here.

The intercept-only levels relation with four lagged residual differences
**does not reject no cointegration at 5%**, despite its high $R^2$.
The declared zero-, two-, four-, and eight-lag comparisons vary: only zero
lags rejects narrowly. Its test residuals retain more dependence, weakening
diagnostic support for that rejection. Descriptive ACF bands do not prove
that the four-lag residuals are white noise. Reverse normalization checks
finite-sample sensitivity, not causal direction.

This sample has not earned a validated economic ECM. A changes-based model
is a candidate while the long-run relation remains unresolved. Nonrejection
does not prove that consumption and income are unrelated or that adjustment
is zero. Breaks, economic definitions, other deterministic specifications,
or additional variables require documented further investigation.

## 6. Report the evidence and its limits

Keep **existence**, **estimation**, and **interpretation** separate. A useful
report states the data definitions, units, transformations, dates, frequency,
and vintage; the I(1) assessment; normalization, deterministic terms, lags,
and reference values; the statistic, decision, diagnostics, and declared
sensitivity; and the resulting model choice and limitations. Short samples,
slow adjustment, breaks, and omitted variables can matter. A precise-looking
fit is not a complete argument.

Recurring traps: looking only at the raw difference; treating stationarity
as white noise or a hard bound; using ordinary ADF calibration on estimated
residuals; treating nonrejection as proof; choosing only the favorable lag
or sample; equating $\kappa$ with $\lambda$; reading algebra or a negative
adjustment estimate as evidence; confusing prediction with intervention.

## Handoffs — optional previews, outside Module 10 Core

Module 11 builds VAR systems in which each variable has an equation.
Module 13 returns to error correction in VECMs. With several variables,
cointegrating rank counts independent stationary relationships; Johansen's
system approach asks about that rank. Matrix estimation, trace/max-eigenvalue
testing, and `ca.jo()` are later machinery, not additional assessable
requirements here.

**Preview license:** if a student asks for VARs, VECMs, Johansen tests,
or later machinery, build it on request, label it a preview, and connect
it back to Core — never deflect the question merely because it comes later.
