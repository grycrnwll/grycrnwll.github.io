# Textbook map — Module 10

Pointers and notation translations only; no textbook passages are reproduced.
Locations below are grounded in the instructor-authored "Connection to the
Textbooks and Sources" section and Core discussion of
`reference/module_10_notes.qmd`. They locate optional reading; they do not
enlarge the assessable Core boundary. **(verify)** means that the course notes
do not document a precise edition-specific location: confirm it before citing.

## Start with Murray's story

Michael P. Murray (1994), [*A Drunk and Her Dog: An Illustration of
Cointegration and Error Correction*](https://doi.org/10.1080/00031305.1994.10476017),
*The American Statistician*, 48(1), 37–39. Read **pp. 37–38** for mutual
correction, the absence of a physical leash, weighted relationships, and the
information omitted by a model containing only changes. The teeter-totter
variation makes a weighted sum memorable. Harry, Karen, and Mouse are the
instructor's adaptation; the course simulation develops the mechanism in
course notation. Obtain the reading through the course or a library; this
pack contains no copy of the PDF.

## Concept pointers

| Concept | Enders, *Applied Econometric Time Series*, 4th ed. | Hamilton, *Time Series Analysis* (1994) | Additional source |
|---|---|---|---|
| Definition and economic motivation | Ch. 6 §1; the §§1–6 reading spans pp. 344–373 | §§19.1–19.2, pp. 571–601 | Murray (1994), pp. 37–38 |
| Common trends and the stationary combination | Ch. 6 §2 | §19.1 within pp. 571–601 | The notes' common-trend derivation is optional Deeper Dive |
| Scalar error correction and the role of lagged disequilibrium | Ch. 6 §3 | §§19.1–19.2, pp. 571–601 | Murray (1994), pp. 37–38 |
| Engle–Granger residual testing | Ch. 6 §4 | §19.2 within pp. 571–601 | MacKinnon (2010), Table 2, $N=2$, $\tau_c$, 5% |
| Simulation and distinguishing population truth from test evidence | Ch. 6 §5 | §§19.1–19.2 for the underlying framework | Course notes §10.6; the supplied R simulation is a course illustration |
| Consumption, yields, money, and sample-specific evidence | Ch. 6 §1 for economic motivation | §§19.1–19.2 for historical applications | Engle–Granger (1987), pp. 271–274 |
| Purchasing-power parity | Ch. 6 §6, pp. 370–373 | U.S.–Italy example, pp. 598–600 | Define the exchange-rate quote before interpreting signs |
| Long-run coefficient inference — optional Technical Note | Ch. 6 for background; more precise subsection **(verify)** | §19.3 | A convergence result does not automatically justify ordinary OLS t-inference |
| System methods — optional later-module preview | Ch. 6 §§7–9 | Precise system-methods section **(verify)** | VAR mechanics come first in Module 11; VECMs return in Module 13 |

**Hyndman / Hyndman and Athanasopoulos:** no precise cointegration/ECM
location is grounded in the course notes **(verify)**. Do not invent an
edition or section. Use the grounded sources above for this module, or map
an actual passage the student supplies by its assumptions and notation.

Engle, R. F., and C. W. J. Granger (1987), [*Co-integration and Error
Correction: Representation, Estimation, and Testing*](https://doi.org/10.2307/1913236),
*Econometrica*, 55(2), 251–276. The pp. 271–274 applications use their own
historical definitions and samples. In particular, their consumption example
is not the aggregate total-consumption archive shipped with this pack.

MacKinnon, J. G. (2010), [*Critical Values for Cointegration Tests*](https://www.econ.queensu.ca/sites/econ.queensu.ca/files/wpaper/qed_wp_1227.pdf),
Queen's Economics Department Working Paper 1227. The helper uses Table 2's
bivariate constant-case 5% coefficients, with $n_c=n_{\text{levels}}-1$ under
the convention documented in the notes. This calibration does not extend
automatically to other deterministic terms or numbers of integrated series.
The links locate external readings; the lab itself needs no network.

## Translate before using a formula

| Textbook feature | Course translation |
|---|---|
| A normalized relationship written with other letters | Write $z_t=y_t-c-\kappa x_t$. Map the intercept, weight, and deviation by role, not by a familiar letter alone. |
| Cointegrating vector scaled or normalized differently | Our vector is $(1,-\kappa)$ under unit coefficient on $y$. Nonzero multiples describe the same relation. Normalization does not identify causal direction. |
| Adjustment called $\alpha$ in some treatments | Preserve $\alpha$ for the ordinary equation intercept. Scalar adjustment is $\lambda$; the long-run slope is $\kappa$. |
| A gap with the opposite sign | Reverse the adjustment coefficient's sign too. The fitted correction contribution must stay unchanged. |
| Innovation, equilibrium error, and fitted residual sharing a symbol | Course $z_t$ is the population deviation, $e_t$ the fitted levels residual, and $\epsilon_t$ an innovation. Label test/ECM residuals separately. Estimates carry hats. |
| Residual ADF presented in familiar univariate form | Keep the statistic, then select the reference distribution matching estimated weights, deterministic terms, and dimension. Ordinary univariate ADF critical values do not calibrate our fitted-residual test. |
| Enders's $a_j$ for AR coefficients | Course $\phi_j$ for outcome memory and $\beta_\ell$ for observed predictor terms. The story's $a,b$ are specifically Harry's and Mouse's adjustment responses. |
| Characteristic roots inside one | Equivalent to course lag-polynomial roots outside one; state which polynomial supplies the roots. |
| MA polynomial signs that differ | Course $\Theta(L)=1+\theta_1L+\cdots$. The baseline ECM has no explicit MA block. |
| An elasticity or equilibrium claim attached to a levels coefficient | First state the units and transformation. A log long-run slope is an elasticity-like association; structural or causal interpretation needs additional assumptions. |

For Hamilton or Enders symbols not explicitly translated in the course notes,
ask for the actual equation and identify each term's role. Do not guess a
notation correspondence from an edition you have not inspected. Read the
surrounding assumptions before importing any claim into the course's model.
