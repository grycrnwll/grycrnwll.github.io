# The six checks — Module 10

Run `Rscript R/checks.R` from the pack root. Each check prints PASS or FAIL,
followed by a verdict. A failure returns a nonzero command-line exit status.
During a lab render, failures print without terminating the document. Input
loading and calculations are guarded within each check: a missing helper or
CSV becomes a FAIL line, and later checks still run. The standalone script
uses base R only.

The checks verify the shipped examples and identities. They do not establish
cointegration in arbitrary data, calibrate every test's finite-sample size,
certify exogeneity, identify a causal effect, or validate every student edit.
The lab sources the script into `new.env()`, so checks do not replace its
inline functions or overwrite its simulation objects. Compare your edited
version with the stamped helper when investigating a discrepancy.

| Check | What it asserts | What a failure usually means |
|---|---|---|
| 1. Archive and calendar | The four-column schema, 203 complete positive observations, uninterrupted quarterly calendar from 1959Q1 to 2009Q3, and recorded endpoint values. | The cache, column names, ordering, dates, or units changed. This is the December 2009 archive, not current-vintage FRED data. |
| 2. Simulator contract | Supplied shocks replay exactly; an independent loop matches all three recursions; `burn = 0` and `burn = 2` retain the intended observations; the reported gap equals Mouse minus Harry. | A recurrence, sign, shock column, or retained index changed. The helper never draws shocks or sets a seed. |
| 3. Known worlds | The connected, slow, and disconnected cases reuse the same shocks and retain 240 observations. Their gap coefficients are 0.80, 0.99, and 1.00; the common-location increments and Karen path match the generating construction. | Adjustment settings, shock alignment, burn-in, or the gap definition changed. These are algebraic checks on the DGP, not rejection-rate claims or visual stationarity tests. |
| 4. Engle–Granger calculation | Independently indexed least squares reproduces the residual-ADF t-ratio at 0, 1, 4, and 8 lags. The regression has no intercept and uses `n - 1 - p` rows. Critical values use the bivariate intercept/no-trend 5% response surface with sample argument `n - 1`. | Residual differences or lagged levels are misaligned; an extra deterministic term appeared; the reference family or sample-size argument changed. Ordinary regression or ordinary ADF critical values are not Engle–Granger calibration. |
| 5. Error correction | The ARDL-to-ECM algebra agrees numerically; the fitted levels residual is lagged against the corresponding changes; the shipped simulation has 239 ECM rows and reproduces its adjustment estimate. | A sign, intercept, long-run coefficient, or lag shifted. An algebraic identity alone does not establish cointegration; an estimated adjustment is not a guaranteed fraction of the observed gap closed. |
| 6. Economic workflow | The archived four-lag baseline does not reject; the declared 0/2/4/8 sensitivity yields only a zero-lag rejection; reverse normalization also does not reject at four lags. The zero-lag test residuals retain the stated lag-1/lag-2 dependence warning. | The data vintage, transformations, normalization, lag choices, or diagnostic residual object changed. A deliberate change needs its own documented experiment, rather than forcing this check to pass. |

Check 3's gap recursion is an optional explanation of the construction, as in
the notes' Deeper Dive. Passing it does not add an assessable derivation.
The short fixed path does not prove a population integration property; the
specified generating equations supply that property independently of the
sample test decision.

In check 6, the diagnostic residuals are the **test regression's remaining
residuals**, not the fitted levels deviation. A stationary cointegrating
deviation may be serially correlated. The approximate ACF bands are descriptive,
not a joint whiteness test. Small first two autocorrelations do not certify
white noise at all lags. The application remains inconclusive about a stable
economic relationship; a passing check does not validate an economic ECM.

## Helper behavior to keep in mind

`walkers()` accepts a finite three-column shock matrix for Harry, Mouse, and
Karen and uses the unit-slope relationship `Mouse - Harry`. It cannot represent
an arbitrary long-run slope by changing `adjust_h` or `adjust_m`: those are
adjustment responses, not cointegrating weights. It requires nonnegative
responses with their sum below two and deliberately permits both responses
to be zero. Burn-in reduces a stable gap's initialization transient; it does
not make a random walk stationary. It retains `nrow(shocks) - burn` observations.
The lab supplies the seed and shocks.

`eg_test()` assumes its two numeric inputs are already complete, equally
spaced, and aligned. It cannot detect a missing calendar date from bare
numeric vectors. It fits an intercept-only levels relation and a residual
ADF without a new intercept or trend. `eg_cv5()` supports only two integrated
variables, an intercept without trend, and a 5% decision, with at least 30
levels observations. Its `n_levels - 1` sample argument is distinct from
the residual-ADF row count and residual degrees of freedom. The approximation
does not guarantee exact finite-sample size. The helper returns no ordinary
regression p-value as a cointegration p-value.

The stamped helper body is identical to the canonical course helper. These
scope limits are documented here; no local helper fixes or new numerical
dependencies were introduced in the pack.
