# Module 10 consumption and income archive

`module_10_consumption_income.csv` contains 203 complete quarterly observations from 1959Q1 through 2009Q3. Columns:

| Column | Definition |
|---|---|
| year | Calendar year |
| quarter | Quarter, 1–4 |
| realcons | Real personal consumption expenditures, billions chained 2005 US dollars, seasonally adjusted annual rate |
| realdpi | Real disposable income, billions chained 2005 US dollars, seasonally adjusted annual rate |

Source: public-domain `statsmodels.datasets.macrodata`, installed version 0.14.6. Dataset compiled by Skipper Seabold from FRED, accessed December 15, 2009. Definitions and provenance: https://www.statsmodels.org/stable/datasets/generated/macrodata.html . Exported locally November 3, 2026; that is the export date, not a new data vintage. No imputation, filtering, aggregation, or sample trimming. Year and quarter were cast to integers. The notes take natural logs of the two level series in R.

This is total aggregate consumption, not per-capita nondurable consumption. It is a new teaching illustration, not a replication of Engle–Granger (1987). The full fixed archive sample was used before examining the test result; the four-lag residual ADF baseline and 0/2/4/8 sensitivity are pedagogical specifications, not selected to obtain rejection.

## Use and refresh

The lab reads this local file in R and takes natural logs. The archive has no
missing quarters or values; no imputation or transformations were applied in
the CSV. The natural-log transformation happens in the lab.

For an exact re-export, obtain the public-domain macrodata archive from
`statsmodels` version 0.14.6 and retain only `year`, `quarter`, `realcons`, and
`realdpi`, casting year/quarter to integers. An instructor can compare the
export with the canonical course CSV before replacing this copy. Retrieving
current FRED data is a different vintage and may change definitions, units,
and results; record all such changes and rerun the analysis rather than
calling it the same example. No refresh is needed to use the pack.

The shipped file requires no Python, network connection, or FRED key. Never
commit a key or credential in a refreshed dataset, script, or learning log.
