# What the Checks Check

`R/checks.R` holds seven assertions about things Module 2 claims are true. Run
it from the pack root at any time:

```
Rscript R/checks.R
```

Each check prints one `PASS` or `FAIL` line with the numbers it computed. Any
failure makes the script exit with a nonzero status, so it works in a script or
a CI job as well as by hand. The last chunk of the lab runs it too — inside a
Quarto render it prints its results without killing the render.

**This is not an answer key.** The checks verify that the *code and data* behave
the way the module says they do. They cannot tell you whether your stationarity
verdict on a series is any good, and they don't try. They exist so that when you
and an AI tutor disagree about a fact, there's a referee neither of you controls.

The file is deliberately written in plain base R plus `urca`. If a check
confuses you, read it — it's about ten lines each. It takes a little while to
run (two of the checks are Monte Carlos), so give it up to a minute.

---

## Check 1 — the DF null distribution is where MacKinnon says it is

**Asserts:** simulate 2000 random walks, run the drift-specification DF
regression on each, and take the empirical 5% quantile of the resulting
$t$-statistics; it lands within 0.15 of `mackinnon_cv(200)`. It typically comes
out near $-2.88$ against a critical value of $-2.876$.

**Why:** this is the module's central claim — under the unit-root null the DF
statistic follows its own left-shifted distribution, and MacKinnon's response
surface is a smoothed, high-precision version of exactly this Monte Carlo. If
the two disagree, either the simulation or the critical-value function is broken.

**A failure usually means:** `R/mackinnon_cv.R` was edited (a sign flip or a
mistyped coefficient moves the CV immediately), or the simulated regression
stopped being the drift-spec DF regression — for example, the `cumsum()` was
dropped (so the null is no longer true by construction) or the regression gained
a trend term (whose null distribution is different, around $-3.43$ at 5%).

## Check 2 — ADF tells stationary from unit root when the data are clear

**Asserts:** `ur.df()` with the drift specification rejects the unit root on a
long ($T = 1000$) stationary AR(1) with $\phi = 0.7$ (statistic near $-10.7$),
and fails to reject on a $T = 300$ random walk (statistic near $-2.0$).

**Why:** before trusting the test on hard cases, verify it on easy ones. These
two series are far from the boundary; a test that can't call them is not going
to be informative about UNRATE.

**A failure usually means:** the simulator or the seed changed. Note the
direction of the decision rule: ADF rejects when the statistic is *below* (more
negative than) the critical value. If you edited the check and it now compares
with the wrong sign, both halves will misbehave. A random-walk statistic that
*rejects* at $T = 300$ can also just be an unlucky draw under a changed seed —
about one draw in twenty does that by construction; restore the seed.

## Check 3 — KPSS mirrors ADF: reverse null, reverse rejection

**Asserts:** on the same two series, `ur.kpss(type = "mu")` stays *below* its
5% critical value (0.463) for the stationary AR(1) (statistic near 0.17) and
blows past it for the random walk (near 3.6).

**Why:** KPSS's null is stationarity and a **large** statistic rejects — the
opposite comparison direction from ADF. Getting this direction wrong is the
single most common KPSS error, so the pack pins it with executable evidence.

**A failure usually means:** the comparison direction got flipped in an edit, or
the series changed. One honest subtlety: KPSS over-rejects persistent but
stationary series in modest samples — that's why this check uses $T = 1000$. If
you shorten the stationary series substantially, the check can fail *while KPSS
behaves exactly as documented*; that failure is a lesson, not a bug.

## Check 4 — the ADF test has low power near the boundary

**Asserts:** against a truly stationary AR(1) with $\phi = 0.95$ at $T = 100$,
the ADF rejection rate over 300 replications stays below 0.25. It typically
lands near 0.10.

**Why:** "with $\phi = 0.95$ and 100 observations, the test misses about 90% of
the time" is the most important practical fact in the module — it's why a
failure to reject proves nothing and why the course demands four sources of
evidence. The check makes the claim executable.

**A failure usually means:** the alternative moved away from the boundary
(lower $\phi$, bigger $T$ — power rises fast in both directions; that's the
point of the lab's power study), or the rejection rule's direction flipped. A
rate *near 0.05* would mean the test is behaving like a pure coin-flip against
this alternative — smaller than expected but still a PASS; a rate above 0.25
means the experiment is no longer the borderline case it claims to be.

## Check 5 — the rule of thumb has real math under it

**Asserts:** for a long ($T = 20{,}000$) stationary AR(1) with $\phi = 0.9$,
the sample ratio $\sigma_{\Delta y}/\sigma_y$ lands within 0.03 of
$\sqrt{2(1-\phi)} = \sqrt{0.2} \approx 0.447$.

**Why:** the rule of thumb is not folklore — for a stationary AR(1),
$\operatorname{Var}(\Delta y_t)/\operatorname{Var}(y_t) = 2(1-\phi)$ exactly.
This check ties the module's quickest diagnostic to the algebra behind it.

**A failure usually means:** the simulator's recursion changed, or `phi` in the
check no longer matches the theoretical target. Even at $T = 20{,}000$ the
sample ratio for a persistent series carries visible sampling error (the seed
used here gives 0.466 against 0.447), which is why the tolerance is 0.03 and
not 0.005 — if you swapped the seed and the check fails by a hair, run it a few
more times before suspecting the code.

## Check 6 — over-differencing pins the MA root to the unit circle

**Asserts:** difference a trend-stationary series with white-noise deviations
($y_t = 5 + 0.05t + \epsilon_t$, $T = 300$) and fit an MA(1) by
`stats::arima()`; the estimate $\hat\theta$ comes out below $-0.9$. It
typically sits at $-1.0000$ — hard against the boundary.

**Why:** the over-differencing algebra says $\Delta y_t = \delta + \epsilon_t -
\epsilon_{t-1}$, an MA(1) with $\theta = -1$ exactly — a unit root in the MA
polynomial. The estimator slamming into the invertibility boundary is that
algebra showing up in software, and it's the fingerprint Module 5's diagnostics
will teach you to spot in the wild.

**A failure usually means:** the DGP stopped being trend-plus-white-noise. If
you gave the deviations AR dynamics, a *pure MA(1)* fit is now misspecified and
$\hat\theta$ can land anywhere (the lab shows $-0.31$ for AR(1) deviations) —
the right model there is ARMA(1,1), whose $\hat\theta$ pins to $-1$ again.
`arima()` may also print warnings near the boundary; the check suppresses them
deliberately, because operating at the boundary is the entire point.

## Check 7 — the data and the sealed series are the ones we documented

**Asserts:** `data/UNRATE.csv` has its two columns, more than 900 rows, and
**exactly one** missing value at `2025-10-01`; `data/GDPC1.csv` has its two
columns, exactly 318 rows, and no missing values; and each of the four mystery
series still opens with its documented first three values (to six decimal
places).

**Why:** the labs and the commit-then-reveal exercise assume everyone — every
student, every tutor, every machine — sees identical data. The UNRATE gap is
real data history (a federal data-release interruption; see `data/README.md`),
and the mystery series are deterministic by construction (`mystery_series()`
seeds internally, which is documented in its header as the one exception to the
course's no-internal-seeds rule).

**A failure usually means:** someone "cleaned" a data file (dropped the NA row,
interpolated the gap, re-downloaded with different column headers), or
`R/mystery_series.R` was edited below its SPOILERS banner. Restore the file
rather than patching the check. If the mystery pins fail on an unmodified file,
check your R version — the values are stable across the R 4.x releases this
course supports, and a mismatch there is worth reporting rather than papering
over.

---

## If a check fails and you can't work out why

Read the check. It's a few lines of base R and it prints the numbers it
computed alongside the target, so the gap between "what we expected" and "what
we got" is right there in the output.

If you're working with an AI tutor, show it the failing line *and* the relevant
source file. "Check 5 fails with ratio 0.51" plus `R/ar1_simulator.R` is a
solvable problem; "my checks fail" is not.
