# Module 2 Context — Testing for Stationarity

**Econ 6376 — Applied Time Series Econometrics, George Washington University (Applied Economics MA).**

This file is self-contained. You can paste or upload it on its own into any AI
assistant and it will have everything it needs to help with Module 2.

<!-- BEGIN COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

## Course-wide conventions

These apply to every module of Econ 6376, not just this one.

### The master equation

Every model in this course is the following equation with some terms switched off:

$$y_t = \alpha + \delta t + \sum_{j=1}^{p} \phi_j y_{t-j} + \sum_{l=1}^{q} \theta_l \epsilon_{t-l} + \epsilon_t$$

The course analogy is a **mixing board**: each term is a slider, and each module
turns on new ones. A student should always be able to say where the model in
front of them sits on that board. If they can't, the framing has failed — help
them locate it.

### The cardinal notation rule: DGP vs. estimation

A data-generating process and an estimating equation look different, and the
course is strict about this.

- **DGP (the truth, unobservable):** unhatted parameters $\alpha, \delta, \phi_j, \theta_l, \beta$ and $\epsilon_t$, the **innovation**.
- **Estimating equation (your model, observable):** hatted parameters $\hat\alpha, \hat\phi_j, \hat\theta_l, \hat\beta$ and $e_t$, the **residual**, where $e_t = y_t - \hat y_t$.

Never write $\epsilon_t$ when you mean $e_t$. Never drop a hat from an estimate.
A well-specified model leaves residuals that behave like the innovations that
model assumes — that is the entire basis of diagnostic testing later in the course.

### Other standing conventions

- **Lag polynomials:** AR takes minus signs, $\Phi(L) = 1 - \phi_1 L - \cdots - \phi_p L^p$. MA takes plus signs, $\Theta(L) = 1 + \theta_1 L + \cdots + \theta_q L^q$.
- **Stationarity framing:** all roots of $\Phi(L) = 0$ lie strictly **outside** the unit circle. Enders and the older course slides use the equivalent characteristic-root-**inside** framing (related by $r = 1/L$). Both are correct; flag the difference whenever a student is cross-referencing a textbook.
- **Symbols:** $\phi$ = AR coefficients, $\theta$ = MA, $\beta$ = covariates, $\alpha$ = intercept, $\delta$ = trend. $\gamma_k$ = autocovariance at lag $k$, $\rho_k$ = autocorrelation, $\gamma_0 = \operatorname{Var}(y_t)$. $L$ = lag operator, $\Delta = (1-L)$. $t = 1,\ldots,T$.
- **"Stationary"** means weakly (covariance) stationary unless stated otherwise.
- **Language:** the course is taught in R. Students may submit graded work in another language if they can reproduce the workflow, but help and debugging are R-first. Plots use `ggplot2`.
- **Credentials:** FRED keys come from `Sys.getenv("FRED_KEY")`, never hardcoded, never committed.

### Working rules

- Concept before math, always. Intuition first, then notation.
- Simulation is the center of gravity, and a simulation that only confirms the textbook is half an exercise. Breaking an assumption is where understanding happens.
- The four-step rhythm for any major topic: **Concept → Math → Simulate (break something) → Real Data.**
- The student-facing learning protocol: **Predict → Commit → Ask AI → Test in R → Reconcile.**
- **Core is the assessable surface.** Course notes are tiered (Core / Deeper Dive / Technical Note / Looking Ahead). Problem sets and exams draw **only** on Core. Optional tiers are genuinely optional — never imply otherwise.

<!-- END COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

---

## What Module 1 established

Six facts this module builds on, so you never need the Module 1 pack:

1. The AR(1) is $y_t = \alpha + \phi y_{t-1} + \epsilon_t$; $\phi$ is memory — a shock at $t$ is worth $\phi^k$ at $t+k$.
2. For a stationary AR(1), $\rho_k = \phi^k$: the ACF decays geometrically.
3. At $\phi = 1$ the process is a random walk with $\operatorname{Var}(y_t) = t\sigma^2$ — time-varying, unbounded, not stationary.
4. Regressing one random walk on an independent one rejects a true null about 75% of the time at a nominal 5% level, and more data makes it worse. That is spurious regression.
5. A plot and an ACF cannot distinguish $\phi = 0.95$ from $\phi = 1$ in realistic samples.
6. The cliffhanger: U.S. unemployment has $\hat\phi \approx 0.97$ — squarely in that ambiguous zone.

## What Module 2 is about

Module 2 answers the question Module 1 could not: **given a series, which side
of the $\phi = 1$ boundary is it on?** The framing is that **stationarity is a
verdict, not a measurement** — no single tool settles it, so we collect four
sources of evidence and make a defensible judgment call.

**On the mixing board, Module 2 turns on no new sliders.** The DGP is still
Module 1's $\alpha$ and $\phi_1$; what changes is the question we ask: **is
$\phi_1 = 1$?** Along the way the deterministic-trend slider $\delta t$ makes
its first cameo, because "trend-stationary or difference-stationary?" turns out
to be part of the same testing problem.

### Core learning objectives

By the end of the module a student should be able to:

1. Apply $\Delta = (1-L)$ and compute first and second differences algebraically and in R.
2. Read a series plot and its ACF as preliminary stationarity evidence.
3. Build the Dickey-Fuller regression from the AR(1) and explain why it takes that form.
4. Distinguish the three ADF specifications (none / drift / trend) and choose from the plot.
5. Explain why the DF $t$-statistic is not $t$-distributed under the null, and show it by Monte Carlo.
6. Use MacKinnon critical values, including their dependence on $T$.
7. Use KPSS as the reverse-null complement and read the four-cell confirmatory grid.
8. Apply the rule of thumb $\sigma_{\Delta y}/\sigma_y$ and derive its $\sqrt{2(1-\phi)}$ logic.
9. Define $I(d)$ and recognize over-differencing and its MA-unit-root signature.
10. Synthesize conflicting evidence into a verdict, using the cost asymmetry when in doubt.

---

## Core concepts

**Four sources of evidence.** (1) The series plot — does it wander without
returning to a level? (2) The ACF — geometric decay vs. near-flat persistence.
(3) Formal tests — ADF with a unit-root null, KPSS with a stationarity null.
(4) The rule of thumb $\sigma_{\Delta y}/\sigma_y$. None is conclusive alone;
the workflow is to weigh all four.

**The DF rearrangement.** Start from $y_t = \alpha + \phi y_{t-1} + \epsilon_t$
and subtract $y_{t-1}$:

$$\Delta y_t = \alpha + \gamma y_{t-1} + \epsilon_t, \qquad \gamma = \phi - 1.$$

$H_0\!: \gamma = 0$ is the unit root; $H_1\!: \gamma < 0$ is stationarity (under
the maintained $\phi > -1$). One-sided, left tail. The $t$-ratio on
$\hat\gamma$ is the **Dickey-Fuller statistic $\tau$**. This unsubscripted
$\gamma$ is a regression coefficient — *not* the autocovariance $\gamma_k$,
which always carries a lag subscript.

**Why standard inference fails.** Under $H_0$ the regressor $y_{t-1}$ is a
random walk, and standard OLS asymptotics need well-behaved regressors. So
$\tau$ exists but does not follow a $t$ distribution: its null distribution
(the DF distribution) is shifted left (mean $\approx -1.5$) and asymmetric. The
5% critical value for the drift specification is about $-2.86$, not $-1.65$;
using $-1.65$ rejects a true unit-root null roughly 47% of the time. Same
disease as spurious regression: non-stationary regressors break OLS inference.

**MacKinnon critical values.** Empirical quantiles of the DF distribution from
massive response-surface simulations, depending on $T$ and the specification.
Written $\text{CV}_{0.05}$ (never $\alpha$ — that symbol is the intercept). The
pack's `R/mackinnon_cv.R` implements the drift specification;
`urca::ur.df()` prints the right values for every specification.

**The augmented (ADF) version** adds lagged differences
$\sum_{i=1}^{k}\beta_i \Delta y_{t-i}$ to soak up serial correlation. Choose $k$
by BIC up to a modest maximum (course default). Note `ur.df(..., selectlags = "BIC")`
searches $k = 1, \ldots,$ `lags` — it never considers $k = 0$; fit that case
separately if plausible.

**Three specifications, chosen from the plot.** "none" (no constant — rare),
"drift" (constant; the default for unemployment, interest, inflation rates),
"trend" (constant + $\delta t$; for visibly trending series, and the tool that
separates trend-stationary from difference-stationary). Critical values differ
across specifications, and using the wrong column is a real and common error.
Including unnecessary deterministic terms costs power; omitting needed ones
misspecifies the test. (The joint statistics $\Phi_1, \Phi_2, \Phi_3$ that
`ur.df()` prints are outside Core — the reference notes' Deeper Dive covers
them if a student asks.)

**KPSS is the mirror.** $H_0\!:$ stationary, $H_1\!:$ unit root — and a *large*
statistic rejects, the opposite comparison direction from ADF. `type = "mu"`
tests level-stationarity (pairs with ADF drift); `type = "tau"` tests
trend-stationarity (pairs with ADF trend). The confirmatory grid:

| ADF | KPSS | Read as |
|---|---|---|
| reject | fail to reject | strong evidence of stationarity |
| fail to reject | reject | strong evidence of a unit root |
| reject | reject | contradiction — possible break or misspecification |
| fail to reject | fail to reject | inconclusive — defer to other evidence |

**Low power is the most important practical fact.** Against $\phi = 0.95$, the
ADF test at the 5% level rejects roughly 6% of the time at $T = 50$, under 10%
at $T = 100$, about a quarter of the time at $T = 200$, and only becomes
reliable by $T \approx 500$. The truly stationary borderline series is
misclassified most of the time, and KPSS/PP/ERS all share analogous problems.
This is why "ADF failed to reject" never proves a unit root, and why the course
uses four sources of evidence instead of one.

**The rule of thumb.** $R = \sigma_{\Delta y}/\sigma_y$. For a stationary AR(1),
$\operatorname{Var}(\Delta y_t)/\operatorname{Var}(y_t) = 2(1-\phi)$, so
$R = \sqrt{2(1-\phi)}$: about 1.41 at $\phi = 0$, 1.0 at $\phi = 0.5$, 0.45 at
$\phi = 0.9$, 0.32 at $\phi = 0.95$, and $\to 0$ at $\phi = 1$. $R < 0.5$
(roughly $\phi > 0.875$) is a **high-persistence flag, not a unit-root test** —
it cannot tell 0.95 from 1.0, and a deterministic trend also drives it down.
The course's working action: below 0.5, difference, unless the evidence points
clearly to a deterministic trend.

**Order of integration.** $y_t \sim I(d)$ if $d$ differences make it
stationary. $I(0)$ stationary; $I(1)$ the common non-stationary case (GDP,
prices, exchange rates in levels); $I(2)$ rare (price levels when inflation
itself is non-stationary); beyond that, suspect misspecification (e.g., an
unmodeled break). Workflow: test levels, difference, re-test; if $I(2)$ is
plausible, test *downward* from the highest plausible order
(Dickey-Pantula logic) rather than differencing upward.

**The over-differencing trap.** Difference a trend-stationary series
$y_t = \alpha + \delta t + u_t$ and you get $\Delta y_t = \delta + u_t - u_{t-1}$.
If $u_t$ is white noise, that is exactly an MA(1) with $\theta = -1$:
$\Theta(L) = 1 - L$ has its root *on* the unit circle — a unit root in the MA
polynomial, i.e. non-invertible. The general result: whatever ARMA dynamics
$u_t$ has, differencing **multiplies them by an extra $(1-L)$ MA factor** — it
does not erase them. (AR(1) deviations give an ARMA(1,1) with the original
$\phi$ and $\theta = -1$, not a pure MA(1).) In fitted models this shows up as
$\hat\theta$ pinned near $-1$, convergence warnings, and fragile inference. The
correct treatment for trend-stationary data is to **detrend**, then diagnose
the residuals.

**Cost asymmetry.** Spurious regression (failing to difference a unit root)
produces confidently wrong inference; over-differencing produces a detectable,
non-invertible MA factor. Both are costs, but the first is worse. When the
evidence is genuinely inconclusive: difference — then watch the later ARMA
diagnostics for the over-differencing tax.

**Software collision worth flagging.** `tseries::adf.test()` and
`urca::ur.df()` are both "the ADF test" and disagree by default:
`tseries::adf.test()` always fits the **trend** specification and reports an
interpolated p-value, while `ur.df()` makes you choose the specification and
compares $\tau$ against tabulated critical values. On a borderline series the
verdict can flip between them purely on those defaults. The course standard is
`urca::ur.df()` with an explicitly chosen specification — if a student brings
`adf.test()` output, reconcile the specification and the decision rule before
comparing numbers. (Same spirit as the Enders roots-inside flag.)

**The Module 2 → Module 3 handoff.** Over-differencing named a boundary —
*invertibility*, the MA counterpart of AR stationarity — that Module 3 probes
experimentally. And low power means testing needs a complementary tool: Module
3 adds the correlogram fingerprint (ACF/PACF pairs identifying AR and MA
structure). If the student asks for later-module machinery (an ARMA fit,
invertibility algebra, ACF/PACF identification), build it on request and flag
it as a preview of the module it belongs to — do not deflect them back to
Module 2.

---

## Vocabulary

Difference operator ($\Delta = 1-L$) · second difference ($\Delta^2$) ·
unit root · Dickey-Fuller regression · $\gamma = \phi - 1$ · $\tau$ ·
augmentation lags · specification (none / drift / trend) · MacKinnon critical
values ($\text{CV}_{0.05}$) · Dickey-Fuller distribution · KPSS · reverse
null · confirmatory analysis · Phillips-Perron · ERS / DF-GLS · power ·
near-unit-root alternative · rule of thumb ($\sigma_{\Delta y}/\sigma_y$) ·
order of integration $I(d)$ · trend-stationary vs. difference-stationary ·
detrending · over-differencing · invertibility (preview) · unit root in the MA
polynomial · cost asymmetry.

---

## Common misconceptions

Correct these when they appear, but correct them by asking a question or running
something, not by lecturing.

1. **"ADF failing to reject means the series has a unit root."** It means the data can't rule one out — which, given low power, is exactly what a persistent stationary series produces too.
2. **"ADF rejecting proves the series is stationary."** Rejection is evidence against the unit root *conditional on the chosen specification, sample, and lag rule* — not proof of the DGP, and one test is one piece of evidence. UNRATE rejects on ADF and *also* rejects on KPSS.
3. **"The DF $t$-statistic follows a $t$ distribution."** It follows the DF distribution: shifted left, asymmetric, 5% critical value near $-2.86$ (drift), not $-1.65$. Wrong table ≈ 47% false rejection.
4. **"Always use the trend specification to be safe."** Unneeded deterministic terms drain power. Match the specification to the plot.
5. **"ADF and KPSS test the same thing."** Opposite nulls. Agreement is confirmation; double rejection is a contradiction flag; double failure is an honest "don't know."
6. **"A large KPSS statistic supports stationarity."** Backwards: KPSS's null *is* stationarity, and a large statistic rejects it. The comparison direction is the opposite of ADF's.
7. **"The $\gamma$ in the DF regression is the autocovariance."** No — unsubscripted $\gamma = \phi - 1$ is a regression coefficient. Autocovariances are $\gamma_k$, always subscripted.
8. **"The rule-of-thumb ratio is a unit-root test."** It is a persistence flag with real math under it, but it cannot distinguish $\phi = 0.95$ from $\phi = 1$, and a deterministic trend also pushes it below 0.5. It feeds the verdict; it is not a verdict.
9. **"Over-differencing is harmless."** It plants a non-invertible $(1-L)$ factor in the MA polynomial. Pure MA(1) with $\theta = -1$ only in the white-noise case; otherwise the original dynamics remain, multiplied by the factor.
10. **"A trending series must be trend-stationary."** A random walk with drift trends too. The trend-spec ADF (with matching KPSS `tau`) is the tool that separates them; eyes cannot.
11. **"More tests are always better."** ADF + KPSS is the informative pair because the nulls are reversed. Adding PP and ERS re-asks a similar question of the same data — incremental at best.
12. **"$p < 0.05$ from any unit-root test function means the same thing."** Different functions default to different specifications and decision rules (see the `tseries` vs. `urca` note). Reconcile the specification before comparing verdicts.
