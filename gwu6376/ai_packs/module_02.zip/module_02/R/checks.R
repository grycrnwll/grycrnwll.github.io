# =============================================================================
# checks.R — the referee for the Module 2 AI Learning Pack (Econ 6376)
#
# Seven assertions about things Module 2 claims are true. Base R plus urca.
# Run it from the pack root:   Rscript R/checks.R
# Each check prints one PASS/FAIL line. Any FAIL exits with a nonzero status.
#
# This file is deliberately readable. If your AI tutor tells you something that
# contradicts one of these checks, the check wins — or one of you has found a
# real bug, which is more interesting. Either way, read the code, don't guess.
# CHECKS.md explains what each check means and what a failure usually points to.
# =============================================================================

source("R/ar1_simulator.R")
source("R/mackinnon_cv.R")
source("R/mystery_series.R")
library(urca)

# ---- tiny test harness ------------------------------------------------------
# Results accumulate here so one failure doesn't hide the checks after it.
results <- logical(0)

check <- function(label, passed, detail = "") {
  passed <- isTRUE(passed)
  results[[length(results) + 1L]] <<- passed
  cat(sprintf("%-4s %s%s\n",
              if (passed) "PASS" else "FAIL",
              label,
              if (nzchar(detail)) paste0("  [", detail, "]") else ""))
  invisible(passed)
}

cat("Module 2 checks\n---------------\n")


# ---- 1. the DF null distribution is where MacKinnon says it is --------------
# Simulate 2000 random walks (H_0 true by construction), run the drift-spec DF
# regression on each, and take the empirical 5% quantile of the t-statistics.
# It should land close to mackinnon_cv(200) — nowhere near the normal's -1.645.
set.seed(42)
T_mc <- 200
df_stats <- replicate(2000, {
  y <- cumsum(rnorm(T_mc))
  dy <- diff(y)
  y_lag <- y[-T_mc]
  summary(lm(dy ~ y_lag))$coefficients["y_lag", "t value"]
})
q05 <- unname(quantile(df_stats, 0.05))
cv  <- mackinnon_cv(T_mc, level = 0.05)
check("DF null MC 5% quantile matches mackinnon_cv(200)",
      abs(q05 - cv) < 0.15,
      sprintf("empirical q05 = %.3f, MacKinnon CV = %.3f, tol 0.15", q05, cv))


# ---- 2. ADF tells stationary from unit root when the data are clear ---------
# A long stationary AR(1) should reject the unit-root null decisively; a
# random walk should fail to reject. Both drift-spec, both 5% level.
set.seed(101)
y_stat <- ar1_simulator(n = 1000, alpha = 0, phi = 0.7, sigma = 1, burn_in = 200)
tau_stat <- ur.df(y_stat, type = "drift", lags = 4)@teststat[1]
set.seed(202)
y_rw <- ts(cumsum(rnorm(300)))
tau_rw <- ur.df(y_rw, type = "drift", lags = 4)@teststat[1]
cv_stat <- mackinnon_cv(length(y_stat), 0.05)
cv_rw   <- mackinnon_cv(length(y_rw), 0.05)
check("ADF rejects on a long stationary AR(1), fails to reject on a random walk",
      (tau_stat < cv_stat) && (tau_rw > cv_rw),
      sprintf("stationary tau = %.2f vs %.2f; random walk tau = %.2f vs %.2f",
              tau_stat, cv_stat, tau_rw, cv_rw))


# ---- 3. KPSS mirrors ADF: reverse null, reverse rejection -------------------
# Same two series. KPSS's null is stationarity and a LARGE statistic rejects,
# so the stationary series should stay under the 5% critical value and the
# random walk should blow past it.
kpss_stat <- ur.kpss(y_stat, type = "mu")
kpss_rw   <- ur.kpss(y_rw, type = "mu")
cv_kpss   <- kpss_stat@cval[1, "5pct"]
check("KPSS fails to reject the stationary series and rejects the random walk",
      (kpss_stat@teststat < cv_kpss) && (kpss_rw@teststat > cv_kpss),
      sprintf("stationary stat = %.3f, random walk stat = %.3f, 5%% CV = %.3f",
              kpss_stat@teststat, kpss_rw@teststat, cv_kpss))


# ---- 4. the ADF test has low power near the boundary ------------------------
# phi = 0.95 is genuinely stationary, but with T = 100 the ADF test almost
# never says so. This is the module's most important practical fact, so we
# assert it: the rejection rate stays under 0.25 (it typically lands near 0.10).
set.seed(303)
rej_rate <- mean(replicate(300, {
  y <- ar1_simulator(n = 100, alpha = 0, phi = 0.95, sigma = 1, burn_in = 200)
  ur.df(y, type = "drift", lags = 4)@teststat[1] < mackinnon_cv(100, 0.05)
}))
check("ADF power at phi = 0.95, T = 100 is low (rejection rate < 0.25)",
      rej_rate < 0.25,
      sprintf("rejection rate = %.3f over 300 replications", rej_rate))


# ---- 5. the rule of thumb has real math under it ----------------------------
# For a stationary AR(1), Var(dy)/Var(y) = 2(1 - phi), so the sd ratio is
# sqrt(2(1 - phi)). At phi = 0.9 that is sqrt(0.2) ~ 0.447, and a long
# simulated series should land close to it.
set.seed(404)
y_thumb <- ar1_simulator(n = 20000, alpha = 0, phi = 0.9, sigma = 1, burn_in = 500)
ratio  <- sd(diff(y_thumb)) / sd(y_thumb)
target <- sqrt(2 * (1 - 0.9))
check("sd(dy)/sd(y) for phi = 0.9 matches sqrt(2(1 - phi))",
      abs(ratio - target) < 0.03,
      sprintf("sample ratio = %.4f, theory %.4f, tol 0.03", ratio, target))


# ---- 6. over-differencing pins the MA root to the unit circle ---------------
# Difference a trend-stationary series with white-noise deviations and the
# result is an MA(1) with theta = -1 — a unit root in the MA polynomial.
# The fitted theta-hat should sit hard against that boundary.
set.seed(505)
y_trend  <- 5 + 0.05 * (1:300) + rnorm(300)
theta_hat <- coef(suppressWarnings(arima(diff(y_trend), order = c(0, 0, 1))))["ma1"]
check("MA(1) fit to a differenced trend-stationary series pins theta near -1",
      theta_hat < -0.9,
      sprintf("theta_hat = %.4f, boundary -1, threshold -0.9", theta_hat))


# ---- 7. the data and the sealed series are the ones we documented -----------
# UNRATE keeps its columns and its one real 2025-10 release gap; GDPC1 has its
# columns, 318 rows, and no holes; and the four mystery series still open with
# their documented first three values, so every student sees identical series.
unrate_raw <- read.csv("data/UNRATE.csv", stringsAsFactors = FALSE)
na_rows <- which(is.na(unrate_raw$UNRATE))
unrate_ok <- identical(names(unrate_raw), c("observation_date", "UNRATE")) &&
  nrow(unrate_raw) > 900 &&
  length(na_rows) == 1L &&
  identical(unrate_raw$observation_date[na_rows], "2025-10-01")

gdp_raw <- read.csv("data/GDPC1.csv", stringsAsFactors = FALSE)
gdp_ok <- identical(names(gdp_raw), c("observation_date", "GDPC1")) &&
  nrow(gdp_raw) == 318L &&
  !anyNA(gdp_raw$GDPC1)

mystery_pins <- list(
  c(2.385143, 2.809511, 1.026837),
  c(0.704917, 1.211326, 1.488241),
  c(2.916920, 2.917137, 1.967755),
  c(-7.752886, -7.862601, -6.108414)
)
mystery_ok <- all(vapply(1:4, function(id) {
  isTRUE(all.equal(round(as.numeric(mystery_series(id))[1:3], 6),
                   mystery_pins[[id]], tolerance = 1e-6))
}, logical(1)))

check("UNRATE.csv, GDPC1.csv, and the four mystery series are intact",
      unrate_ok && gdp_ok && mystery_ok,
      sprintf("UNRATE %s, GDPC1 %s, mystery series %s",
              if (unrate_ok) "ok" else "CHANGED",
              if (gdp_ok) "ok" else "CHANGED",
              if (mystery_ok) "ok" else "CHANGED"))


# ---- verdict ----------------------------------------------------------------
n_pass <- sum(results)
n_all  <- length(results)
cat(sprintf("---------------\n%d/%d checks passed.\n", n_pass, n_all))

# Exit nonzero on failure when run from the command line. Inside a Quarto
# render, knitr sets knitr.in.progress, and we only print — killing the R
# session mid-render would be a very rude way to report a failing check.
if (n_pass < n_all && !isTRUE(getOption("knitr.in.progress"))) {
  quit(status = 1, save = "no")
}
