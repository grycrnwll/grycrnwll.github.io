# Stamped copy of mackinnon_cv() from helpers/testing.R in the Econ 6376 course repo — behavior unchanged; edits belong in the canonical file.

mackinnon_cv <- function(T, level = 0.05, spec = "drift") {
  # Return the MacKinnon critical value for the ADF test.
  #
  # Arguments:
  #   T     : sample size
  #   level : significance level (0.01, 0.05, or 0.10)
  #   spec  : ADF specification ("drift" only in this teaching version;
  #           use urca::ur.df() for "none" or "trend")
  #
  # Returns:
  #   A single numeric critical value.
  #
  # Reference:
  #   MacKinnon, J.G. (2010), "Critical Values for Cointegration
  #   Tests," Queen's Economics Department Working Paper No. 1227 —
  #   Table 2 is the source of these response-surface coefficients.
  #   MacKinnon (1996), "Numerical Distribution Functions for Unit
  #   Root and Cointegration Tests," Journal of Applied Econometrics,
  #   11, 601-618, develops the underlying numerical approach.

  if (spec != "drift") {
    stop("Only drift specification implemented in this teaching example.\n",
         "Use urca::ur.df() for other specifications.")
  }
  if (level == 0.01) {
    return(-3.43035 - 6.5393 / T - 16.786 / T^2 - 79.433 / T^3)
  }
  if (level == 0.05) {
    return(-2.86154 - 2.8903 / T - 4.234 / T^2 - 40.04 / T^3)
  }
  if (level == 0.10) {
    return(-2.56677 - 1.5384 / T - 2.809 / T^2)
  }
  stop("Level must be 0.01, 0.05, or 0.10")
}
