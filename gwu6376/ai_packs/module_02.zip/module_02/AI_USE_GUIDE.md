# Using AI Well in This Course

**Econ 6376 — Module 2**

This is written for you, not for the assistant. It's about getting real value out
of an AI tutor instead of the appearance of value.

---

## The short version

AI is extraordinarily good at the things that used to waste your time in a course
like this — debugging R, explaining notation, generating variations of a
simulation, answering the question you were embarrassed to ask in class. Use it
for all of that, freely.

It is much less good at the thing this course actually grades: *judgment about
ambiguous evidence*. Whether an ADF statistic of $-2.79$ against a critical
value of $-2.86$ plus a rejecting KPSS means "difference it" is not a fact to be
retrieved. It's a call you make and defend.

Use AI to build the judgment. Don't use it to skip the judgment.

---

## Productive uses

- **Debugging.** "This chunk errors, here's the message." Get the fix, move on. Don't romanticize struggling with a missing comma.
- **Explaining notation.** "Why is the $\gamma$ in the DF regression not the autocovariance $\gamma_k$?" This is exactly the kind of thing a textbook assumes you'll absorb by osmosis and you won't.
- **Generating variations.** "Re-run the power study at $\phi = 0.90$ instead of 0.95." Cheap, fast, and the fastest route to intuition about where tests break down.
- **Being challenged.** "I think ADF failing to reject proves my series has a unit root. Push back on me." Asking to be argued with is the single highest-value prompt in this course.
- **Rubber-ducking.** Explain your verdict on a mystery series to the AI and let it find the hole. You'll often find it yourself mid-sentence.
- **Chasing tangents.** "What happens to these tests if the series has one big level shift?" Turn it into a simulation and find out. Your tutor is instructed to help you do this rather than steer you back to the syllabus.
- **Translating textbooks.** Paste a confusing passage from Enders Ch. 4 and ask it to reconcile the notation with the course's. See `TEXTBOOK_MAP.md`.

## Unproductive uses

- **Asking for the interpretation before you've formed one.** "What does this ADF output mean?" gets you a fluent paragraph you'll forget. Form a view first, then ask it to critique yours. The order matters more than it sounds like it should.
- **Asking for a mystery-series reveal before you've committed a verdict.** `reveal_mystery()` costs nothing to run and the reveal is worthless without a committed guess in front of it. The whole exercise is the gap between what you called and what it was.
- **Accepting numbers you didn't verify.** LLMs produce confident, plausible, wrong arithmetic. Especially on things like "what's the 5% MacKinnon critical value at $T = 100$" — the pack has `mackinnon_cv()` precisely so nobody has to trust anyone's memory.
- **Letting it write your log.** See below.
- **Using it as a search engine for the answer to a graded question.** Permitted, but see the section on assessed work — it doesn't work as well as it feels like it should.
- **Never disagreeing with it.** If you've gone ten sessions without once finding the AI wrong, you aren't checking. It is wrong regularly on this material.

---

## Verification habits

The pack is built so you never have to take anyone's word for anything — mine, or
your tutor's.

**Test claims in R.** Almost every claim in Module 2 is checkable in a few
lines. "The DF statistic isn't $t$-distributed" — simulate 2000 random walks
and look. "ADF has low power at $\phi = 0.95$" — run the Monte Carlo. If your
tutor asserts something about this material and you can't immediately see how
to test it, ask it to write the test.

**Use `R/checks.R` as a referee.** It holds seven assertions about things this
module claims are true, in readable base R plus `urca`. Run `Rscript R/checks.R`
any time. If something you were told contradicts a passing check, the check wins.

**Watch for these specific failure modes.** In my experience they're the common
ones on this material:

- Reading KPSS in the ADF direction. KPSS's null is *stationarity* and a **large** statistic rejects it. An assistant fluent in ADF will sometimes tell you a big KPSS statistic "supports stationarity." It's exactly backwards.
- Mixing up unit-root test functions. `tseries::adf.test()` always fits the trend specification and interpolates a p-value; `urca::ur.df()` makes you pick the specification and compares $\tau$ to critical values. On a borderline series they can disagree without either being "wrong." Know which one you're reading.
- Critical-value arithmetic. Quoting $-1.65$ (the normal) where $-2.86$ (the DF distribution, drift spec) belongs, or quoting an asymptotic value where a small-sample one matters. `mackinnon_cv()` settles it.
- Overclaiming what one test proves. "ADF rejected, therefore stationary" and "ADF failed to reject, therefore unit root" are both wrong — the first ignores specification-sensitivity, the second ignores power. The verdict comes from the four sources together.
- Confusing $\epsilon_t$ and $e_t$, or dropping hats off estimates — same as Module 1, and it still matters.

**A good habit:** when the AI tells you something surprising, ask "how would I
check that in R?" before asking anything else. If it can't propose a check, be
suspicious of the claim.

---

## Graded work

**AI assistance is permitted on every graded deliverable in this course** —
problem sets, the take-home midterm, and the final — **with disclosure.**

Disclosure is a brief, free-form statement of how you used it. No form, no
template, no penalty. It just has to be honest and specific enough to be
meaningful. Two sentences is plenty:

> *I used Claude to debug my ADF Monte Carlo loop in Question 1 and to check my
> derivation of the variance ratio in Question 2. The stationarity verdict on
> the FRED series in Question 3 is my own, though I asked Claude to argue
> against my reading of the KPSS result before I settled on it.*

That's a complete disclosure. Notice it says what was done *where* — "I used AI"
alone doesn't tell me anything.

Your `LEARNING_LOG.md` is **not** the disclosure vehicle. The log is private and
I never see it. Disclosure goes with the submitted work.

### Why pasting through answers won't carry you

I want to be straightforward about this rather than issue a warning.

The assessments in this course are built to be AI-resilient, and they draw
**only** on the Core tier of the module notes. They ask you to interpret
ambiguous output, reconcile two results that disagree, explain why a method
failed, and defend a judgment call. Those questions don't have retrievable
answers — the evidence is genuinely ambiguous, which is the point, and what gets
graded is the quality of your reasoning about the ambiguity.

An answer you didn't build, you can't defend. That shows up immediately in the
follow-up parts of a question, and it shows up badly on a take-home where you had
plenty of time.

So the policy isn't a trap. Using AI heavily and understanding the material are
completely compatible — that's the intended outcome, and it's how you'll work
professionally. Using AI heavily *instead of* understanding the material is a
strategy that fails at the assessment, and more importantly fails in the job
where nobody tells you which model to fit.

---

## About the contract

`AI_TUTOR_CONTRACT.md` asks your tutor to do things like request a prediction
before running a simulation, and to ask for your own words before writing the
last two fields of your learning log.

The prediction ask pauses for one turn — it will hand you two or three options
and wait once. Answer it, or say "just run it" and it runs immediately and drops
the question. It will not ask you twice, and you can tell it to skip predictions
entirely for the whole session. It's your session.

One Module 2 specific: before revealing a mystery series, the tutor will ask
for your verdict once — stationary, trend-stationary, or unit root — and then
reveal either way. That single ask *is* the exercise. The series are sealed so
that your committed guess, not the reveal, is the thing you learn from.

I'd just say plainly: the contract is there for your benefit, not as a rule
you're being held to. The prediction step exists because being surprised is how
things stick, and skipping it feels efficient in the moment and costs you in
November. Overriding it is a choice you're making about your own learning, and
you're an adult — I only want you making the choice knowingly rather than by
accident.

That's the last I'll say about it.

---

## Intellectual ownership

The point of this course is that you become someone who can take an unfamiliar
series, work out what it is, and defend a modeling decision to a skeptical room.

That capability is built by making predictions, being wrong, and figuring out
why. It is not transferable from a model, and it is not something you can borrow
under deadline. An AI can accelerate every step of building it — and it can also
let you produce work that looks like the finished product without any of the
building having happened.

Both paths are available to you here, and honestly, the second one is easier.
The difference shows up when you're the one in the room who has to say what the
data means.
