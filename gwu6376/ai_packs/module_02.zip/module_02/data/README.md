# data/ — Cached data for the Module 2 lab

This folder holds cached FRED pulls so the lab runs **without an API key and
without an internet connection**. That is a binding constraint on all course
materials, not a convenience: everything in this pack must work offline.

The lab shows you the live `fredr` pull too (in `R/fetch_fred.R` and Exploration 6),
so you can see how the data is actually obtained — but nothing requires you to
run it.

| File | FRED series | Description | Coverage |
|---|---|---|---|
| `UNRATE.csv` | `UNRATE` | U.S. civilian unemployment rate, monthly, seasonally adjusted, percent | 1948-01 through 2026-04 |
| `GDPC1.csv` | `GDPC1` | U.S. real gross domestic product, quarterly, seasonally adjusted annual rate, billions of chained 2017 dollars | 1947-Q1 through 2026-Q2 (318 rows, no gaps, no NAs) |

Both copied from the course repository's shared `data/` folder on 2026-08-21.
`UNRATE.csv` is the same cache the Module 1 pack uses (original FRED pull cached
2026-08-12); `GDPC1.csv` was pulled from FRED on 2026-08-21.

## Column layout

Two columns each, following the FRED CSV export format:

```
observation_date,UNRATE          observation_date,GDPC1
1948-01-01,3.4                   1947-01-01,2182.681
1948-02-01,3.8                   1947-04-01,2176.892
```

`observation_date` is the first day of the period the observation refers to
(month for UNRATE, quarter for GDPC1). It is read in as text and converted with
`as.Date()` in the lab.

## The one missing value — leave it alone

**`UNRATE.csv` has a blank value at `2025-10-01`.** This is a federal
data-release gap, not a corrupted file and not a mistake. The observation
genuinely does not exist.

The lab handles it explicitly: a monthly `ts` object cannot carry a hole without
its date index silently going wrong, so the lab keeps the complete run from
1948-01 up to the month before the gap (933 observations, ending 2025-09) and
says so in a comment.

`R/checks.R` asserts that the gap is still there. If a tool or a well-meaning AI
tutor "cleans" the file by dropping the row or interpolating across it, that
check fails on purpose. **Restore the file rather than patching the check.**

Quietly filling holes in real data is a habit worth not developing, and one
missing month in a series you don't have a stake in is a cheap place to practice
noticing.

`GDPC1.csv` has no such gap — quarterly GDP had no analogue of the release
interruption — and `R/checks.R` asserts that too (318 rows, no NAs).

## Refreshing the cache

Re-run the module's `fredr` pull with a valid `FRED_KEY` in your environment,
write the result here, and update the coverage column above.

## The key rule

**Never commit an API key, or any file containing one, to this folder.** Keys
live in your environment — in `.Renviron` or via `Sys.setenv()` — and are read
with `Sys.getenv("FRED_KEY")`. They never appear in a course file. This pack is
intended to be publishable.

Get a free FRED key at <https://fred.stlouisfed.org/docs/api/api_key.html>.
