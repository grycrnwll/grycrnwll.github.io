# Textbook Map — Module 2

Where Module 2's concepts live in the three books students most often read
alongside this course, and how to translate the notation when you get there.

**This file contains pointers and translations only — no textbook text.** If you
want to know what Enders *says*, read Enders. What this file does is get you to
the right pages and stop the notation from tripping you.

**How to read the pointers.** Page ranges are the ones used elsewhere in this
course's own notes, for the editions listed below. Where this course has never
pinned a page down, the pointer is at chapter level and says so. Nothing here is
guessed at the page level — if you find a discrepancy with your copy, trust your
copy and tell me. Cells marked **(verify)** are conventions or locations this
course has not documented explicitly; check your copy before relying on one.

**Editions assumed:** Enders, *Applied Econometric Time Series*, 4th ed.
Hamilton, *Time Series Analysis* (1994). Hyndman & Athanasopoulos, *Forecasting:
Principles and Practice*, 3rd ed., free online at <https://otexts.com/fpp3/>.

---

## Part A — Concept pointers

### The difference operator and difference equations

| Book | Where |
|---|---|
| Enders | Ch. 1, pp. 1–46 (difference equations and operators); Ch. 2, pp. 47–52 (stochastic difference equations). |
| Hamilton | Ch. 2 — chapter level; the cleanest formal treatment of lag and difference operators of the three. |
| fpp3 | Treated inside the "ARIMA models" chapter (Ch. 9), in its differencing material, rather than developed on its own. |

### The Dickey-Fuller and ADF tests: form, specifications, critical values

| Book | Where |
|---|---|
| Enders | Ch. 4, pp. 206–209 — the DF/ADF test, all three specifications, and the critical-value tables. This is the main landing site for Module 2. |
| Hamilton | Ch. 17 — chapter level. The rigorous asymptotics behind the DF distribution (functional central limit arguments). Genuinely hard; read it for *why* the distribution is non-standard, not for workflow. |
| fpp3 | The "ARIMA models" chapter (Ch. 9), unit-root testing section — chapter level. Note fpp3's workflow leads with KPSS, not ADF (see Part B). |

### Choosing the deterministic terms (none / drift / trend)

| Book | Where |
|---|---|
| Enders | Ch. 4, pp. 235–238 — the general-to-specific strategy for deterministic terms. The course notes' Deeper Dive on this topic is a guided reading of the same material. |
| Hamilton | Ch. 17 — chapter level; organized around the same case distinctions. |
| fpp3 | Not developed — fpp3's automated workflow sidesteps the manual specification choice. |

### The joint tests $\Phi_1$, $\Phi_2$, $\Phi_3$ (optional tier)

| Book | Where |
|---|---|
| Enders | Ch. 4, pp. 207–209 — alongside the critical-value discussion, per the reference notes' Deeper Dive references line. Outside this course's Core; the reference notes' Deeper Dive covers the reading. |
| Primary source | Dickey, D.A. and Fuller, W.A. (1981), "Likelihood Ratio Statistics for Autoregressive Time Series with a Unit Root," *Econometrica*, 49, 1057–1072. |

### KPSS and confirmatory analysis

| Book | Where |
|---|---|
| Enders | Ch. 4, p. 214 — a brief discussion. Enders gives KPSS much less space than this course does. |
| Hamilton | Predates KPSS's absorption into textbook canon — not covered (verify). |
| fpp3 | The "ARIMA models" chapter (Ch. 9), stationarity-and-differencing section — KPSS is fpp3's *default* unit-root test, the reverse of this course's ADF-first habit. |
| Primary source | Kwiatkowski, Phillips, Schmidt, and Shin (1992), *Journal of Econometrics*, 54, 159–178. |

### Phillips-Perron and ERS

| Book | Where |
|---|---|
| Enders | Ch. 4 gives a brief pointer on p. 221; the fuller treatment lives in his *Supplementary Manual*, §4.6. |
| Hamilton | Ch. 17 — chapter level; PP-style corrections appear in the asymptotic development (verify). |
| Primary sources | Phillips, P.C.B. (1987), *Econometrica*, 55, 277–301. Elliott, Rothenberg, and Stock (1996), *Econometrica*, 64, 813–836. |

### Order of integration, trends, and trend- vs difference-stationarity

| Book | Where |
|---|---|
| Enders | Ch. 4, pp. 181–189 (order of integration and trends) and pp. 189–200 (trend-stationary versus difference-stationary). Read these *before* the testing sections — the distinction is what the trend specification exists to resolve. |
| Hamilton | Ch. 15 — chapter level (verify) — models of nonstationary time series; Ch. 17 for the testing side. |
| fpp3 | The "ARIMA models" chapter (Ch. 9), differencing section — practical, with the same "difference until stationary, but not further" advice. |

### The power problem and lag selection

| Book | Where |
|---|---|
| Enders | Ch. 4 — chapter level. Enders discusses low power against near-unit-root alternatives in the same range as the testing material; find it via the index entry for *power* (verify at page level). |
| Primary sources | Schwert, G.W. (1989), *Journal of Business and Economic Statistics*, 7, 147–159 (the $k_{\max}$ rule). Dickey, D.A. and Pantula, S.G. (1987), *Journal of Business & Economic Statistics*, 5, 455–461 (testing downward for multiple unit roots). |

### MacKinnon critical values

| Book | Where |
|---|---|
| Enders | Ch. 4, pp. 207–208 — tabulates commonly used values. |
| Primary sources | MacKinnon, J.G. (1996), *Journal of Applied Econometrics*, 11, 601–618 (the numerical distribution-function approach). MacKinnon, J.G. (2010), Queen's Economics Department Working Paper No. 1227 — Table 2 is where the response-surface coefficients in `R/mackinnon_cv.R` come from. |

### Spurious regression (the Module 1 callback)

| Book | Where |
|---|---|
| Enders | Ch. 4 — chapter level; find it via the index entry for *spurious regression*. |
| Primary sources | Granger and Newbold (1974), *Journal of Econometrics*, 2, 111–120. Phillips (1986), *Journal of Econometrics*, 33, 311–340. |

---

## Part B — Notation translation

Same mathematics, different alphabets. This is where most cross-referencing
confusion comes from.

Cells marked **(verify)** are conventions this course has not documented
explicitly — they match the common usage in those texts, but check your copy
before relying on one. Unmarked cells are conventions stated in this course's own
materials.

| Concept | This course | Enders | Hamilton |
|---|---|---|---|
| Series | $y_t$ | $y_t$ | $y_t$ |
| Intercept | $\alpha$ | $a_0$ | $c$ (verify) |
| AR coefficient, lag $j$ | $\phi_j$ | $a_j$ | $\phi_j$; in the unit-root chapters often $\rho$ for the AR(1) coefficient under test (verify) |
| DF regression coefficient | $\gamma = \phi - 1$ | $\gamma$ — same object, same symbol | works directly with $\rho$ and $T(\hat\rho - 1)$ alongside the $t$-form (verify) |
| DF test statistic | $\tau$ | $\tau$, with spec-specific variants $\tau_\mu$, $\tau_\tau$ (verify) | presented among several test statistics rather than under one symbol (verify) |
| Autocovariance at lag $k$ | $\gamma_k$ (always subscripted) | $\gamma_s$ (verify) | $\gamma_j$ (verify) |
| Trend coefficient | $\delta$ | $a_2$ (verify) | $\delta$ (verify) |
| Innovation vs. residual | $\epsilon_t$ vs. $e_t$ | not systematically distinguished (verify) | not systematically distinguished (verify) |
| Stationarity condition | roots of $\Phi(L) = 0$ **outside** the unit circle | characteristic roots **inside** the unit circle | roots **outside** the unit circle (same as this course) |
| Unit-root test workflow | ADF first, KPSS as confirmatory complement | ADF-centered | — (fpp3: KPSS first, ADF secondary) |

### The four that actually cause problems

**1. Enders writes $a_0, a_1$ where we write $\alpha, \phi_1$.** His AR(1) is
$y_t = a_0 + a_1 y_{t-1} + \epsilon_t$, so his unit-root null is $a_1 = 1$ where
ours is $\phi_1 = 1$. Purely cosmetic, but it derails people mid-derivation.

**2. Two different $\gamma$'s, and Enders uses the symbol too.** In his Ch. 4,
Enders' DF regression coefficient $\gamma$ is the same object as this course's
$\gamma = \phi - 1$ — the symbols agree. The trap is *within* the notation:
unsubscripted $\gamma$ (a regression coefficient) versus subscripted $\gamma_k$
(an autocovariance) are unrelated objects that happen to share a letter, in
this course and in Enders alike. Read the subscript, not the letter.

**3. Enders uses the characteristic-root-*inside* framing.** This course says
stationarity requires the roots of $\Phi(L) = 0$ to lie **outside** the unit
circle; Enders says the characteristic roots must lie **inside** it. Same
condition, reciprocal roots, related by $r = 1/L$. Mixing the two framings
mid-problem produces an answer that is exactly backwards. Hamilton uses our
framing.

**4. fpp3 runs the workflow in the reverse order.** Hyndman & Athanasopoulos
default to KPSS: their null is stationarity, and their automated tools
difference until KPSS stops rejecting. This course leads with ADF (null: unit
root) and uses KPSS as the confirmatory complement. Neither is wrong — but a
sentence like "the test rejected, so we difference" means opposite things in
the two frameworks until you check which test it was. The same warning applies
in software: `tseries::adf.test()` and `urca::ur.df()` default to different
specifications and decision rules (see `MODULE_CONTEXT.md`).

**One more, for when you get to Module 3:** Box, Jenkins and Reinsel write the MA
polynomial with *minus* signs, so their $\theta$ is the negative of ours. Enders
and Hamilton agree with us. Not a Module 2 issue, but worth knowing before you
pick up a fourth book.
