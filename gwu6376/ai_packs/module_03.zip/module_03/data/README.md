# data/ — Cached data for the Module 3 lab

This folder makes the Core lab independent of API keys and internet access.

| File | FRED series | Description | Cached coverage |
|---|---|---|---|
| `UNRATE.csv` | `UNRATE` | U.S. civilian unemployment rate, monthly, seasonally adjusted, percent | 1948-01 through 2026-04 |

The file is a direct copy of the course repository's shared `data/UNRATE.csv`,
stamped into this pack on 2026-09-04.

## Column layout

Two columns, following the FRED CSV export format:

```
observation_date,UNRATE
1948-01-01,3.4
1948-02-01,3.8
```

`observation_date` is the first day of the month the observation refers to. It
is read in as text and converted with `as.Date()` in the lab.

## The documented gap

The row at `2025-10-01` has a blank value. This is a real federal data-release
gap, not corruption. A monthly `ts` object cannot silently skip a date without
misaligning its calendar, so the lab keeps the contiguous run through 2025-09
(933 observations) for modeling. `R/checks.R` verifies both the gap and the
contiguous run. Restore the cache rather than deleting or interpolating the row.

## The COVID sensitivity window

The full sample is the primary evidence. The lab then performs an explicitly
labeled sensitivity analysis that excludes changes dated March 2020 through
December 2021. This is not a cleaned replacement series and is not permission
to discard influential observations silently. It asks a bounded question: how
much of the full-sample correlogram is being compressed by the extraordinary
COVID episode?

## Refreshing the cache

`R/fetch_fred.R` shows the standard live workflow. It requires the optional
`fredr` package and a FRED key read from `Sys.getenv("FRED_KEY")`. Nothing in the
Core lab calls it. To refresh, re-run that pull with a valid `FRED_KEY` in your
environment, write the result here, and update the coverage column above.

## The key rule

**Never write a credential into a course file or commit one to this folder.**
Keys live in your environment — in `.Renviron` or via `Sys.setenv()` — and are
read with `Sys.getenv("FRED_KEY")`. They never appear in a course file. This
pack is designed for eventual public distribution.

Get a free FRED key at <https://fred.stlouisfed.org/docs/api/api_key.html>.
