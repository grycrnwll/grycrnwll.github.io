# Learning Log — Module 3

**This log is private. It is never collected, never graded, and I never see it.**

That is not a technicality — it is the only reason it works. A log written to
look good for an instructor is worthless. A log that honestly records "I was
confident about this and I was wrong" is the most useful study document you will
produce in this course, because in week ten you can look back and see exactly
which of your instincts need watching.

It also has to be **in your own words**. If you're working with an AI tutor, it
is instructed to help you fill in the first three fields but to ask you for the
last two and record your answer verbatim — never to write them for you. If it
offers to draft "revised reasoning" for you, say no. A log in someone else's
words reads like understanding and isn't, and you will not be able to tell the
difference three weeks from now when you need it.

Five fields per entry. Two minutes each, written *during* the session rather than
reconstructed afterward.

- **Prediction** — what you expected before you ran anything. Be specific enough to be wrong.
- **AI interaction** — what you asked, and what it told you.
- **Verification** — what you ran in R, and what actually came out.
- **Revised reasoning** — what you now think, and what changed your mind. *Your words.*
- **Remaining uncertainty** — what you still don't understand or don't believe. *Your words.*

That last field is the most valuable one and the easiest to leave blank. "None"
is almost never the true answer. Starting your next session by pasting it in is
the fastest way to pick up where you left off.

---

## Entry — date: ____________

**Topic / lab section:**

**Prediction** (before running anything — what did you expect, and why?)

>

**AI interaction** (what you asked; what it said; anything that surprised you)

>

**Verification** (what you ran in R; what came out; did it match?)

>

**Revised reasoning** (your words — what do you think now, and what changed it?)

>

**Remaining uncertainty** (your words — what are you still unsure about?)

>

---

## Entry — date: ____________

**Topic / lab section:**

**Prediction**

>

**AI interaction**

>

**Verification**

>

**Revised reasoning** (your words)

>

**Remaining uncertainty** (your words)

>

---

## Entry — date: ____________

**Topic / lab section:**

**Prediction**

>

**AI interaction**

>

**Verification**

>

**Revised reasoning** (your words)

>

**Remaining uncertainty** (your words)

>

---

*Copy an entry block for each new session. Keep the old ones — the pattern across
entries is worth more than any single one.*
