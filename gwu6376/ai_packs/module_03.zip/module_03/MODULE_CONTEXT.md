# Module 3 Context — AR and MA Processes

**Econ 6376 — Applied Time Series Econometrics, George Washington University (Applied Economics MA).**

This file is self-contained. You can paste or upload it on its own into any AI
assistant and it will have everything it needs to help with Module 3.

<!-- BEGIN COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

## Course-wide conventions

These apply to every module of Econ 6376, not just this one.

### The master equation

Every model in this course is the following equation with some terms switched off:

$$y_t = \alpha + \delta t + \sum_{j=1}^{p} \phi_j y_{t-j} + \sum_{l=1}^{q} \theta_l \epsilon_{t-l} + \epsilon_t$$

The course analogy is a **mixing board**: each term is a slider, and each module
turns on new ones. A student should always be able to say where the model in
front of them sits on that board. If they can't, the framing has failed — help
them locate it.

### The cardinal notation rule: DGP vs. estimation

A data-generating process and an estimating equation look different, and the
course is strict about this.

- **DGP (the truth, unobservable):** unhatted parameters $\alpha, \delta, \phi_j, \theta_l, \beta$ and $\epsilon_t$, the **innovation**.
- **Estimating equation (your model, observable):** hatted parameters $\hat\alpha, \hat\phi_j, \hat\theta_l, \hat\beta$ and $e_t$, the **residual**, where $e_t = y_t - \hat y_t$.

Never write $\epsilon_t$ when you mean $e_t$. Never drop a hat from an estimate.
A well-specified model leaves residuals that behave like the innovations that
model assumes — that is the entire basis of diagnostic testing later in the course.

### Other standing conventions

- **Lag polynomials:** AR takes minus signs, $\Phi(L) = 1 - \phi_1 L - \cdots - \phi_p L^p$. MA takes plus signs, $\Theta(L) = 1 + \theta_1 L + \cdots + \theta_q L^q$.
- **Stationarity framing:** all roots of $\Phi(L) = 0$ lie strictly **outside** the unit circle. Enders and the older course slides use the equivalent characteristic-root-**inside** framing (related by $r = 1/L$). Both are correct; flag the difference whenever a student is cross-referencing a textbook.
- **Symbols:** $\phi$ = AR coefficients, $\theta$ = MA, $\beta$ = covariates, $\alpha$ = intercept, $\delta$ = trend. $\gamma_k$ = autocovariance at lag $k$, $\rho_k$ = autocorrelation, $\gamma_0 = \operatorname{Var}(y_t)$. $L$ = lag operator, $\Delta = (1-L)$. $t = 1,\ldots,T$.
- **"Stationary"** means weakly (covariance) stationary unless stated otherwise.
- **Language:** the course is taught in R. Students may submit graded work in another language if they can reproduce the workflow, but help and debugging are R-first. Plots use `ggplot2`.
- **Credentials:** FRED keys come from `Sys.getenv("FRED_KEY")`, never hardcoded, never committed.

### Working rules

- Concept before math, always. Intuition first, then notation.
- Simulation is the center of gravity, and a simulation that only confirms the textbook is half an exercise. Breaking an assumption is where understanding happens.
- The four-step rhythm for any major topic: **Concept → Math → Simulate (break something) → Real Data.**
- The student-facing learning protocol: **Predict → Commit → Ask AI → Test in R → Reconcile.**
- **Core is the assessable surface.** Course notes are tiered (Core / Deeper Dive / Technical Note / Looking Ahead). Problem sets and exams draw **only** on Core. Optional tiers are genuinely optional — never imply otherwise.

<!-- END COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

---

## What Modules 1 and 2 established

Six facts this pack assumes, so it stands alone without the earlier packs:

1. The AR(1), $y_t = \alpha + \phi y_{t-1} + \epsilon_t$, carries memory through past values of $y$; when stationary, $\rho_k = \phi^k$.
2. At $\phi=1$ the process is a random walk, its variance grows with time, and conventional levels inference can become spurious.
3. The lag and difference operators are $Ly_t=y_{t-1}$ and $\Delta=(1-L)$.
4. Stationarity is a verdict built from a plot, the ACF, opposite-null ADF/KPSS tests, and $\sigma_{\Delta y}/\sigma_y$ — no one exhibit proves it.
5. The order $d$ is settled before ARMA identification: difference only until the series is stationary.
6. Over-differencing plants an MA factor $(1-L)$, so $\theta=-1$ and the MA root lies on the unit circle. Module 3 gives that failure its name: non-invertibility.

## What Module 3 is about

Module 3 turns on the rest of the AR sliders $\phi_2,\ldots,\phi_p$ and the MA
sliders $\theta_1,\ldots,\theta_q$. The central question becomes: **what kind
of stationary memory is left after $d$ is settled?** AR processes remember
past values of $y$; MA processes remember past innovations; small ARMA models
combine both.

The working skill is fingerprint reading. The ACF and PACF together distinguish
pure AR and MA processes in the population, suggest candidates in samples, and
tell us when they cannot settle the order. They are evidence, not confessions.

### Core learning objectives

By the end of the module a student should be able to:

1. Write AR($p$), MA($q$), and ARMA($p,q$) DGPs in summation and lag-polynomial form with the course's signs.
2. Apply the AR stationarity condition to the three course AR(2) examples and connect real versus complex roots to smooth versus oscillating decay.
3. Derive the MA(1) autocovariances, cutoff, and population bound $|\rho_1|\leq 0.5$.
4. Distinguish MA stationarity from invertibility and explain reciprocal MA representations.
5. Explain the AR–MA isomorphism and why a small finite ARMA can be parsimonious.
6. Define the PACF as the deepest-lag OLS coefficient and reproduce it with `pacf_by_regression()`.
7. Use the ACF/PACF identification table while accounting for sample noise and short samples.
8. Diagnose a near-boundary MA(1), four sealed fingerprints, and the full-sample versus COVID-excluded UNRATE evidence.

---

## Core concepts and working framework

### Settle $d$ before reading $p$ and $q$

The identification order is fixed: establish stationarity, difference only as
needed, and then read the ACF/PACF of the stationary series. A near-one ACF on a
non-stationary level series is not a long-memory AR fingerprint; it is an
unsettled Module 2 question. Identify $d$ first, then $p$ and $q$.

### Two kinds of memory

An AR($p$) remembers the last $p$ values of the series:

$$y_t=\alpha+\sum_{j=1}^{p}\phi_jy_{t-j}+\epsilon_t,
\qquad \Phi(L)y_t=\alpha+\epsilon_t.$$

An MA($q$) remembers the current and last $q$ innovations:

$$y_t=\alpha+\epsilon_t+\sum_{l=1}^{q}\theta_l\epsilon_{t-l},
\qquad y_t=\alpha+\Theta(L)\epsilon_t.$$

An AR shock fades but never becomes exactly zero; an MA shock has a finite
horizon and expires after $q$ lags. Combined:

$$\Phi(L)y_t=\alpha+\Theta(L)\epsilon_t.$$

### AR roots and the three course AR(2)s

AR stationarity requires every root of $\Phi(L)=0$ outside the unit circle.
For an AR(2), it is convenient to use the reciprocal characteristic equation

$$r^2-\phi_1r-\phi_2=0,
\qquad \lambda_{1,2}=\frac{\phi_1\pm\sqrt{\phi_1^2+4\phi_2}}{2},$$

where stationarity requires $|\lambda_1|,|\lambda_2|<1$.

| $(\phi_1,\phi_2)$ | Characteristic roots | Classification | ACF shape |
|---|---|---|---|
| $(0.5,0.3)$ | $0.852,-0.352$ | stationary | smooth mixed-geometric decay |
| $(0.8,0.3)$ | $1.078,-0.278$ | mildly explosive | deviations grow along one mode |
| $(0.6,-0.5)$ | $0.3\pm0.640i$, modulus $0.707$ | stationary | damped oscillation |

The discriminant $\phi_1^2+4\phi_2$ tells real from complex roots; the root
moduli, separately, settle stationarity. Conditions on coefficients one at a
time do not work.

### Why an MA($q$) cuts off

A finite MA($q$) is always weakly stationary. For
$y_t=\epsilon_t+\theta\epsilon_{t-1}$,

$$\gamma_0=\sigma^2(1+\theta^2),\qquad
\gamma_1=\theta\sigma^2,\qquad
\gamma_k=0\ \text{for }k\geq2,$$

so

$$\rho_1=\frac{\theta}{1+\theta^2},\qquad
\rho_k=0\ \text{for }k\geq2.$$

There are no shared innovations once the separation exceeds the MA order. In
a minimal nondegenerate MA($q$), the population ACF's last nonzero spike is at
$q$. The bound $|\rho_1|\leq0.5$ is a **population** fact for a pure MA(1);
sampling variation can put $|\hat\rho_1|$ beyond it.

### Invertibility is not stationarity

MA stationarity is automatic. MA **invertibility** requires every root of
$\Theta(L)=0$ outside the unit circle. It selects the unique representation
from observationally equivalent reciprocal parameterizations and makes the
filter recovering innovations from observed history stable. For MA(1),
$\theta$ and $1/\theta$ produce the same autocorrelation; for a nonzero pair
away from $|\theta|=1$, exactly one member is invertible.

The over-differencing case $\Theta(L)=1-L$ has its root at $L=1$, exactly on the
boundary. A fitted $\hat\theta$ pinned near $-1$ is therefore a warning to
revisit differencing and specification. A printed convergence code or small
Hessian standard error does not restore ordinary interior-parameter inference
at the boundary.

### AR–MA isomorphism and parsimony

A stationary AR($p$) has an MA($\infty$) representation. More precisely, Wold
decomposes a covariance-stationary process into deterministic and one-sided
MA($\infty$) innovation components; the stationary ARMA models here are in the
purely nondeterministic applied case. An invertible MA($q$) has a convergent
AR($\infty$) representation. For $\theta=0.7$,

$$\Theta(L)^{-1}=1-0.7L+0.49L^2-0.343L^3+\cdots.$$

The payoff is parsimony: a small finite ARMA can encode dynamics that require a
long pure AR or MA. The lab keeps that conceptual payoff in Core; fitting a
high-order AR to make the infinite approximation numerical is optional.

### PACF: the second fingerprint

The partial autocorrelation at lag $k$, $\phi_{kk}$, is the association between
$y_t$ and $y_{t-k}$ after removing the linear effects of the intervening lags.
Operationally, regress

$$y_t=\hat\beta_0+\hat\beta_1y_{t-1}+\cdots+\hat\beta_ky_{t-k}+e_t$$

and take $\hat\phi_{kk}=\hat\beta_k$. The pack's
`pacf_by_regression()` repeats this deepest-lag OLS calculation on a common
window; `stats::pacf()` uses faster Yule–Walker/Durbin–Levinson machinery, so
small alignment differences are expected.

### The identification table

| Process | Population ACF | Population PACF |
|---|---|---|
| AR($p$) | tails off | **cuts off after $p$** |
| MA($q$) | **cuts off after $q$** | tails off |
| ARMA($p,q$) | tails off | tails off |

"Cutoff" means population entries are zero after the minimal order; it does
not promise every earlier entry is nonzero. A sample correlogram only
approximates this table. At $T=60$, the approximate bands are
$\pm1.96/\sqrt{60}\approx\pm0.25$, so a true second lag can disappear and
random later lags can poke out. A calibrated verdict may be "ambiguous at this
sample size."

### The near-invertibility break

For the legal but nearly non-invertible MA(1) with $\theta=-0.97$, the MA root
is $1/0.97\approx1.031$ and $\rho_1\approx-0.4998$. The population ACF still
cuts off after lag 1. In the seeded sample, `stats::arima()` puts
$\hat\theta$ essentially at $-1$. The correlogram can identify the class while
estimation at the boundary remains delicate; these are different questions.

### UNRATE: primary evidence and labeled sensitivity

Module 2's working verdict treats monthly UNRATE as $I(1)$, so Module 3 reads
the fingerprint of $\Delta$UNRATE. In the complete cached run through 2025-09,
the full-sample ACF is nearly flat: none of lags 1–24 clears the usual band and
$\hat\rho_1=0.036$. The April 2020 change was +10.4 percentage points, inflating
the variance denominator and compressing all sample correlations.

The full sample stays primary. Excluding March 2020–December 2021 is a clearly
labeled sensitivity analysis, not a silent deletion. In that view, 8 of 24 ACF
lags clear the band; both ACF and PACF tail off, and both show a negative lag-12
echo. A low-order ARMA with possible seasonal structure is a defensible
**candidate**, not an identified answer. Module 4 compares orders; Module 5
introduces seasonal terms.

---

## Vocabulary

AR($p$) · MA($q$) · ARMA($p,q$) · memory of $y$ · memory of shocks ·
$\Phi(L)$ · $\Theta(L)$ · lag-polynomial root · characteristic root
$\lambda_j$ · discriminant · modulus · real roots · complex-conjugate roots ·
damped oscillation · cutoff · tail-off · invertibility · reciprocal
representation · MA unit root · Wold decomposition · purely nondeterministic ·
MA($\infty$) · AR($\infty$) · parsimony · partial autocorrelation
$\phi_{kk}$ · deepest-lag coefficient · correlogram fingerprint · Bartlett
band · sensitivity analysis.

## Common misconceptions

Correct these when they appear, but correct them by asking a question or running
something, not by lecturing.

1. **"If every $|\phi_j|<1$, the AR($p$) is stationary."** No; stationarity is a joint root condition. The course's $(0.8,0.3)$ AR(2) is mildly explosive.
2. **"Complex roots mean the model is broken."** No; complex roots inside the characteristic unit circle are stationary and produce damped oscillation.
3. **"MA can be non-stationary."** A finite MA is always weakly stationary; it can be non-invertible.
4. **"Stationarity and invertibility are the same."** They mirror one another geometrically but govern different polynomials and different questions.
5. **"An ACF cutoff means AR."** Backwards: MA cuts off in ACF; AR cuts off in PACF.
6. **"A cutoff means every earlier bar must be significant."** It is a population statement about zeros *after* the minimal order; coefficient cancellation and sampling variation complicate earlier bars.
7. **"An MA(1) sample correlation cannot exceed 0.5."** The half-bound is on population $|\rho_1|$, not every sample $|\hat\rho_1|$.
8. **"PACF at lag 1 always equals the DGP's $\phi_1$."** It equals $\rho_1$; it matches $\phi_1$ for AR(1), but not generally for AR($p$).
9. **"AR and MA are disjoint families."** Stationary AR and invertible MA processes have infinite-order representations in the other direction.
10. **"Both correlograms tailing off identifies the exact ARMA order."** It suggests the mixed class; Module 4's information criteria arbitrate among candidate orders.
11. **"The fingerprint table works on levels whether or not they are stationary."** Identify $d$ first. A non-stationary ACF is not the Module 3 memory measurement.
12. **"Removing COVID reveals the true model."** It is a sensitivity analysis that explains fragility. The full sample remains the primary evidence.
13. **"A converged near-$-1$ MA estimate with a small standard error is reassuring."** Boundary likelihood behavior is nonstandard; revisit differencing and specification.
14. **"Short samples still confess their order if I stare harder."** Wide bands and noisy sample correlations can make "ambiguous at this $T$" the best verdict.

## The Module 3 → Module 4 handoff

The pure cases have readable cutoffs. In a mixed ARMA both ACF and PACF tail
off, so the plots suggest a class but not exact $(p,q)$. Module 4 introduces
likelihood and information criteria to compare a small candidate grid. If a
student asks now, explain that preview on request and keep the distinction
clear: Module 3 generates candidates; Module 4 scores them.
