# Stamped copy of helpers/diagnostics.R from the Econ 6376 course repo — behavior unchanged; edits belong in the canonical file.

# =============================================================================
# diagnostics.R — Residual diagnostics and fingerprint plotting
# Econ 6376: Applied Time Series Econometrics
# Canonical source: helpers/diagnostics.R
#
# The Module 3 notes and deck build these functions live in their live-coding
# sections and use inline definitions there. AI packs and later modules may
# source or stamp this canonical helper instead of redefining the functions.
# Requires: forecast, ggplot2, patchwork (show_fingerprint only)
# =============================================================================

show_fingerprint <- function(y, title = "") {
  # Create a 3-panel diagnostic: series plot + ACF + PACF.
  #
  # Arguments:
  #   y     : a ts object
  #   title : main title for the series panel
  #
  # Returns:
  #   A patchwork plot object (series on top, ACF + PACF side by side below).

  p1 <- forecast::autoplot(y) + ggplot2::ggtitle(title) + ggplot2::theme_bw()
  p2 <- forecast::ggAcf(y, lag.max = 24) + ggplot2::ggtitle("ACF") + ggplot2::theme_bw()
  p3 <- forecast::ggPacf(y, lag.max = 24) + ggplot2::ggtitle("PACF") + ggplot2::theme_bw()
  p1 / (p2 + p3)
}

pacf_by_regression <- function(y, k_max = 4) {
  # Compute the sample PACF the way L3 defines it: K separate OLS
  # regressions, each one lag deeper than the last, reading off the
  # coefficient on the *deepest* lag.
  #
  #   y_t = b_0 + b_1 y_{t-1} + ... + b_k y_{t-k} + e_t,   phi_kk = b_k
  #
  # Arguments:
  #   y     : a time series (ts or numeric vector)
  #   k_max : deepest lag to compute (default 4)
  #
  # Returns:
  #   A named numeric vector of length k_max: phi_11, phi_22, ..., phi_kk.
  #
  # Note:
  #   This is the partial-regression definition, not the Durbin-Levinson
  #   recursion that stats::pacf() runs on the Yule-Walker equations.
  #   The two agree to about three decimals; the small gap is the
  #   different treatment of the start of the sample. Every regression
  #   here uses the same window (aligned to lag k_max) so that the K
  #   coefficients are comparable to one another.

  n <- length(y)
  y <- as.numeric(y)
  if (k_max < 1 || n <= k_max + 1) {
    stop("k_max must be at least 1 and shorter than the series.")
  }

  y_t <- y[(k_max + 1):n]

  phi_kk <- vapply(seq_len(k_max), function(k) {
    # columns y_{t-1}, ..., y_{t-k} on the common window
    lags <- vapply(seq_len(k), function(j) y[(k_max + 1 - j):(n - j)],
                   numeric(length(y_t)))
    unname(coef(lm(y_t ~ lags))[k + 1])
  }, numeric(1))

  names(phi_kk) <- paste0("phi_", seq_len(k_max), seq_len(k_max))
  phi_kk
}
