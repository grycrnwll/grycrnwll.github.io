# =============================================================================
# checks.R — the referee for the Module 3 AI Learning Pack (Econ 6376)
#
# Seven assertions about things Module 3 claims are true. Base R plus the
# pack's own helpers (R/arma_simulator.R, R/diagnostics.R,
# R/fingerprint_mysteries.R). No package is attached: forecast, ggplot2, and
# patchwork are needed only by show_fingerprint(), which the checks never call.
# Run it from the pack root:   Rscript R/checks.R
# Each check prints one PASS/FAIL line. Any FAIL exits with a nonzero status.
#
# This file is deliberately readable. If your AI tutor tells you something that
# contradicts one of these checks, the check wins — or one of you has found a
# real bug, which is more interesting. Either way, read the code, don't guess.
# CHECKS.md explains what each check means and what a failure usually points to.
# =============================================================================

source(file.path("R", "arma_simulator.R"))
source(file.path("R", "diagnostics.R"))
source(file.path("R", "fingerprint_mysteries.R"))

# ---- tiny test harness ------------------------------------------------------
# Results accumulate here so one failure doesn't hide the checks after it.
results <- logical(0)

check <- function(label, passed, detail = "") {
  passed <- isTRUE(passed)
  results[[length(results) + 1L]] <<- passed
  cat(sprintf("%-4s %s%s\n",
              if (passed) "PASS" else "FAIL",
              label,
              if (nzchar(detail)) paste0("  [", detail, "]") else ""))
  invisible(passed)
}

cat("Module 3 checks\n---------------\n")


# ---- 1. the canonical simulator has a stable, seed-controlled contract ------
# Same seed, same call, same series: the simulator is deterministic given the
# RNG state, returns a ts object, and returns exactly n observations.
set.seed(101)
sim_a <- arma_simulator(n = 80, phi = c(0.55, -0.20), theta = 0.35)
set.seed(101)
sim_b <- arma_simulator(n = 80, phi = c(0.55, -0.20), theta = 0.35)
check("arma_simulator returns a deterministic length-n time series",
      inherits(sim_a, "ts") && length(sim_a) == 80L && identical(sim_a, sim_b),
      sprintf("class %s, length %d, identical on re-seed: %s",
              class(sim_a)[1], length(sim_a), identical(sim_a, sim_b)))


# ---- 2. lag-polynomial roots classify three representative AR(2) cases ------
# The roots of Phi(L) = 1 - phi_1 L - phi_2 L^2 must all lie outside the unit
# circle for stationarity. (0.5, 0.3) is stationary with real roots, (0.8, 0.3)
# is mildly explosive, and (0.6, -0.5) is stationary with complex roots.
lag_polynomial_roots <- function(phi) {
  polyroot(c(1, -phi[1], -phi[2]))
}

roots_stationary_real <- lag_polynomial_roots(c(0.50, 0.30))
roots_nonstationary <- lag_polynomial_roots(c(0.80, 0.30))
roots_stationary_complex <- lag_polynomial_roots(c(0.60, -0.50))

check("AR(2) root checks distinguish stationary, nonstationary, and complex cases",
      all(Mod(roots_stationary_real) > 1) &&
        any(Mod(roots_nonstationary) <= 1) &&
        all(Mod(roots_stationary_complex) > 1) &&
        any(abs(Im(roots_stationary_complex)) > 1e-8),
      sprintf("min |root|: (0.5, 0.3) = %.3f; (0.8, 0.3) = %.3f; (0.6, -0.5) = %.3f with |Im| = %.3f",
              min(Mod(roots_stationary_real)),
              min(Mod(roots_nonstationary)),
              min(Mod(roots_stationary_complex)),
              max(abs(Im(roots_stationary_complex)))))


# ---- 3. the MA(1) population ACF has its advertised formula and half-bound --
# rho(1) = theta / (1 + theta^2), rho(h) = 0 for h >= 2, and |rho(1)| can never
# exceed 1/2 — with equality exactly at theta = +/-1.
theta_values <- c(-3, -1, -0.4, 0, 0.7, 1, 2)
rho_one <- theta_values / (1 + theta_values^2)
acf_ma_one <- stats::ARMAacf(ma = 0.7, lag.max = 6)
check("MA(1) rho(1) = theta/(1+theta^2), rho(h)=0 after lag 1, and |rho(1)| <= 1/2",
      abs(acf_ma_one[2] - 0.7 / (1 + 0.7^2)) < 1e-12 &&
        max(abs(acf_ma_one[3:7])) < 1e-12 &&
        all(abs(rho_one) <= 0.5 + 1e-12) &&
        all(abs(rho_one[theta_values %in% c(-1, 1)]) == 0.5),
      sprintf("ARMAacf rho(1) = %.6f vs formula %.6f; max |rho(2..6)| = %.1e; max |rho(1)| on the theta grid = %.3f",
              acf_ma_one[2], 0.7 / (1 + 0.7^2),
              max(abs(acf_ma_one[3:7])), max(abs(rho_one))))


# ---- 4. population cutoff identities hold in the identifying diagnostic -----
# AR(p): the PACF cuts off after p. MA(q): the ACF cuts off after q. Both are
# exact in the population, so the tail beyond lag 2 should be numerically zero.
ar_two_pacf <- stats::ARMAacf(ar = c(0.60, -0.30), lag.max = 10, pacf = TRUE)
ma_two_acf <- stats::ARMAacf(ma = c(0.80, 0.50), lag.max = 10)
check("population AR(2) PACF and MA(2) ACF cut off after lag 2",
      max(abs(ar_two_pacf[3:10])) < 1e-10 &&
        max(abs(ma_two_acf[4:11])) < 1e-10,
      sprintf("max |AR(2) PACF| beyond lag 2 = %.1e; max |MA(2) ACF| beyond lag 2 = %.1e",
              max(abs(ar_two_pacf[3:10])), max(abs(ma_two_acf[4:11]))))


# ---- 5. the regression construction and stats::pacf agree ------------------
# pacf_by_regression() reads the deepest-lag OLS coefficient; stats::pacf()
# runs Durbin-Levinson on the Yule-Walker equations. They differ only in
# finite-sample start-of-sample conventions, so agreement within 0.02 is the
# target, not byte equality.
set.seed(8675309)
pacf_series <- stats::arima.sim(n = 500, model = list(ar = c(0.60, -0.30)))
pacf_ols <- pacf_by_regression(pacf_series, k_max = 4)
pacf_stats <- as.numeric(stats::pacf(pacf_series, lag.max = 4, plot = FALSE)$acf)
pacf_gap <- max(abs(pacf_ols - pacf_stats))
check("pacf_by_regression agrees with stats::pacf within 0.02 at lags 1-4",
      pacf_gap < 0.02,
      sprintf("maximum absolute difference = %.4f, tol 0.02", pacf_gap))


# ---- 6. a seeded near-boundary MA(1) fit lands near the invertibility boundary
# theta = -0.97 is invertible but barely; the ML estimate should sit just
# inside the boundary at -1, not somewhere comfortable in the interior.
set.seed(1999)
near_boundary <- arma_simulator(n = 500, theta = -0.97)
near_fit <- stats::arima(near_boundary, order = c(0, 0, 1), include.mean = FALSE)
theta_hat <- unname(near_fit$coef["ma1"])
check("the near-noninvertible MA(1) example estimates theta close to -1",
      is.finite(theta_hat) && theta_hat < -0.95 && theta_hat > -1.001,
      sprintf("estimated theta = %.5f, window (-1.001, -0.95), true theta -0.97",
              theta_hat))


# ---- 7. the sealed data and the cached UNRATE comparison are the documented ones
# The four mystery series still open with their pinned first three values (so
# every student sees identical series); the raw UNRATE cache keeps its one real
# 2025-10 release gap and runs through 2026-04; the modeling run stops at
# 2025-09 with 933 rows; and the full-sample vs. sensitivity contrast the lab
# and notes describe reproduces exactly.
mystery_pins <- rbind(
  c(-0.529904, -0.228377, 0.287689),
  c(1.115273, -0.043264, 1.543820),
  c(-0.066068, 0.269386, 0.637239),
  c(-2.123562, -1.230410, -0.508150)
)
mystery_observed <- t(vapply(
  1:4,
  function(id) round(as.numeric(fingerprint_mystery(id))[1:3], 6),
  numeric(3)
))
pins_ok <- identical(mystery_observed, mystery_pins)

unrate_raw <- utils::read.csv(
  file.path("data", "UNRATE.csv"),
  stringsAsFactors = FALSE
)
unrate_raw$observation_date <- as.Date(unrate_raw$observation_date)
unrate_raw <- unrate_raw[order(unrate_raw$observation_date), ]

gap_row <- unrate_raw$observation_date == as.Date("2025-10-01")
raw_cache_ok <- nrow(unrate_raw) == 940L &&
  sum(gap_row) == 1L && is.na(unrate_raw$UNRATE[gap_row]) &&
  identical(max(unrate_raw$observation_date), as.Date("2026-04-01")) &&
  !is.na(unrate_raw$UNRATE[unrate_raw$observation_date == as.Date("2026-04-01")])

unrate <- unrate_raw
first_missing <- which(is.na(unrate$UNRATE))[1]
if (!is.na(first_missing)) {
  unrate <- unrate[seq_len(first_missing - 1L), ]
}
delta_unrate <- diff(unrate$UNRATE)
delta_dates <- unrate$observation_date[-1]
keep_sensitivity <- !(delta_dates >= as.Date("2020-03-01") &
  delta_dates <= as.Date("2021-12-01"))
delta_sensitivity <- delta_unrate[keep_sensitivity]

acf_hits <- function(x, lag_max = 24) {
  values <- as.numeric(stats::acf(x, lag.max = lag_max, plot = FALSE)$acf)[-1]
  sum(abs(values) > 1.96 / sqrt(length(x)))
}

full_hits <- acf_hits(delta_unrate)
sensitivity_hits <- acf_hits(delta_sensitivity)
full_rho_one <- as.numeric(stats::acf(delta_unrate, lag.max = 1, plot = FALSE)$acf)[2]

check("sealed fingerprints and the cached UNRATE full/sensitivity contrast are reproducible",
      pins_ok &&
        raw_cache_ok &&
        nrow(unrate) == 933L &&
        identical(max(unrate$observation_date), as.Date("2025-09-01")) &&
        full_hits == 0L && sensitivity_hits == 8L &&
        abs(full_rho_one - 0.036) < 0.002,
      paste(
        "mystery pins:", if (pins_ok) "ok" else "CHANGED",
        "| raw cache:", if (raw_cache_ok) "ok" else "CHANGED",
        "| raw end:", max(unrate_raw$observation_date),
        "| raw rows:", nrow(unrate_raw),
        "| modeling rows:", nrow(unrate),
        "| full-sample hits:", full_hits,
        "| sensitivity hits:", sensitivity_hits,
        "| full-sample rho(1):", round(full_rho_one, 3)
      ))


# ---- verdict ----------------------------------------------------------------
n_pass <- sum(results)
n_all  <- length(results)
cat(sprintf("---------------\n%d/%d checks passed.\n", n_pass, n_all))

# Exit nonzero on failure when run from the command line. Inside a Quarto
# render, knitr sets knitr.in.progress, and we only print — killing the R
# session mid-render would be a very rude way to report a failing check.
if (n_pass < n_all && !isTRUE(getOption("knitr.in.progress"))) {
  quit(status = 1, save = "no")
}
