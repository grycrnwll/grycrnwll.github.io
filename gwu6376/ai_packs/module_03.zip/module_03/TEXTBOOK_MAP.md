# Textbook Map — Module 3

Pointers and notation translations for reading Module 3 alongside the course's
three common references.

**This file contains citations and translations only — no textbook text.**
Page ranges below are grounded in the canonical Module 3 notes for the listed
editions. A **(verify)** marker means the course materials name only a broader
location or do not document that convention; check your copy before relying on
the detail.

**Editions assumed:** Enders, *Applied Econometric Time Series*, 4th ed.;
Hamilton, *Time Series Analysis* (1994); Hyndman & Athanasopoulos,
*Forecasting: Principles and Practice*, 3rd ed. (fpp3), available at
<https://otexts.com/fpp3/>.

---

## Part A — Concept pointers

### AR($p$) processes and stationarity

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 48–60 — autoregressive processes and stationarity conditions. |
| Hamilton | Chs. 3–4 — chapter level (verify at page level); the rigorous development of stationary linear processes. |
| fpp3 | Ch. 9, "ARIMA models" — autoregressive models and stationarity (verify at section/page level). |

### AR autocorrelation and real versus complex roots

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 60–66 — ACF behavior for AR processes and the Yule–Walker connection. |
| Hamilton | Chs. 3–4 — chapter level (verify); covariance structure and lag-polynomial solutions. |
| fpp3 | Ch. 9 — practical ACF identification of autoregressive models (verify at section level). |

### MA($q$) processes and the ACF cutoff

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 68–72 — moving-average processes and their finite ACF. |
| Hamilton | Chs. 3–4 — chapter level (verify); linear processes and autocovariances. |
| fpp3 | Ch. 9 — moving-average models and correlogram identification (verify at section level). |

### Invertibility and reciprocal MA representations

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 77–78 — invertibility and AR($\infty$) representations. |
| Hamilton | Chs. 3–4 — chapter level (verify at page level); invertible lag polynomials. |
| fpp3 | Ch. 9 — invertibility inside the ARIMA treatment (verify at section level). |

### Wold decomposition and AR–MA isomorphism

| Book | Where |
|---|---|
| Hamilton | Ch. 4, §4.8, pp. 108–109 — Wold decomposition, including the deterministic component. |
| Enders | Ch. 2, pp. 77–78 for the applied invertible-MA-to-AR($\infty$) direction; the course notes use Hamilton for Wold's precise statement. |
| fpp3 | Ch. 9 — applied ARIMA representations (verify); not the course's source for the formal Wold qualification. |

### PACF and its computation

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 64–68; p. 65 for the Yule–Walker/Durbin–Levinson computation highlighted in the notes. |
| Hamilton | Chs. 3–4 — chapter level (verify at page level). |
| fpp3 | Ch. 9 — sample PACF and ARIMA identification (verify at section level). |

### Joint ACF/PACF identification

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 71–80 — sample ACF/PACF identification of ARMA models. |
| Hamilton | Chs. 3–4 — theoretical reference (verify at page level). |
| fpp3 | Ch. 9 — forecasting-workflow treatment with R examples (verify at section level). |

---

## Part B — Notation translation

Same mathematics, different alphabets. This is where most cross-referencing
confusion comes from.

Cells marked **(verify)** are conventions this course has not documented
explicitly — they match the common usage in those texts, but check your copy
before relying on one. Unmarked cells are conventions stated in this course's own
materials.

| Concept | This course | Enders | Hamilton |
|---|---|---|---|
| AR coefficient at lag $j$ | $\phi_j$ | $a_j$ | $\phi_j$ (verify) |
| MA coefficient at lag $l$ | $\theta_l$ | $\theta_l$ (same plus-sign convention) | $\theta_l$ (same plus-sign convention) |
| AR lag polynomial | $\Phi(L)=1-\sum_{j=1}^p\phi_jL^j$ | translated from coefficients $a_j$; check the displayed polynomial in your copy (verify) | $\Phi(L)$ with roots outside (same framing; verify symbol) |
| MA lag polynomial | $\Theta(L)=1+\sum_{l=1}^q\theta_lL^l$ | plus-sign convention | plus-sign convention |
| Stationarity criterion | roots of $\Phi(L)=0$ **outside** unit circle | characteristic roots **inside** unit circle | lag-polynomial roots **outside** unit circle |
| Characteristic root | $\lambda_j$, root of $r^p-\phi_1r^{p-1}-\cdots-\phi_p=0$ | characteristic-root-inside framing | commonly works with lag-polynomial roots (verify local symbol) |
| Lag-polynomial root | $L^*$, reciprocal of $\lambda_j$ | translate by $r=1/L$ | root-outside framing |
| Innovation / residual | $\epsilon_t$ / $e_t$ | not systematically separated (verify) | not systematically separated (verify) |
| Autocorrelation | $\rho_k$ | $\rho_s$ or equivalent (verify) | $\rho_j$ (verify) |
| Partial autocorrelation | $\phi_{kk}$ | check local notation (verify) | check local notation (verify) |
| AR($\infty$) inverse weights | $\pi_k$ in $\epsilon_t=\sum_{k\ge0}\pi_ky_{t-k}$ | check local notation (verify) | check local notation (verify) |

### The four that actually cause problems

1. **Inside versus outside roots.** Enders' characteristic roots inside and the course's lag-polynomial roots outside are equivalent, not competing conditions. They are reciprocals: $r=1/L$.
2. **AR signs versus MA signs.** The course has minus signs in $\Phi(L)$ and plus signs in $\Theta(L)$. Enders and Hamilton share the MA plus-sign convention used here. Box, Jenkins, and Reinsel use the opposite MA sign, so their reported $\theta$ translates to this course's $-\theta$.
3. **$\phi_j$ versus $\phi_{kk}$.** The first is a DGP AR coefficient; the double-subscript object is a partial autocorrelation. At the true deepest AR lag they coincide in the population, but they are not interchangeable symbols.
4. **Wold needs its qualification.** The precise result includes a deterministic component; the pure MA($\infty$) innovation representation applies to the purely nondeterministic case used for the stationary ARMA models here.

If a pointer disagrees with your edition, trust the book in front of you and
report the mismatch. Do not remove a `(verify)` marker by inference alone.
