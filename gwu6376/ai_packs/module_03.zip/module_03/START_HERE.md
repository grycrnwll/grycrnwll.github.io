# Start Here — Module 3 AI Learning Pack

**Econ 6376: Applied Time Series Econometrics — Module 3, "AR and MA Processes"**

This folder is a self-contained study environment. Point an AI assistant at it,
or upload pieces of it to a chat tool, and you get a tutor that knows this
course's notation, conventions, and the specific things students get wrong in
Module 3 — plus a lab you can actually run to check whether it's telling you the
truth.

Everything here runs with **no API key and no internet connection**.

This pack stands alone — you do not need the Module 1 or Module 2 packs to use
it. If you *did* work through them, bring your `LEARNING_LOG.md`: your last
entry there (especially the remaining-uncertainty field) is the fastest way to
start your first Module 3 session.

---

## What's in the folder

| File | What it is |
|---|---|
| `START_HERE.md` | This map. |
| `MODULE_CONTEXT.md` | Standalone Module 3 objectives, notation, framework, and misconceptions. Self-contained — this is the file you upload to a chat tool. |
| `AI_TUTOR_CONTRACT.md` | How the assistant should help: always comply, one-turn prediction, narrated execution, calibrated depth. Worth reading yourself so you know what to expect. |
| `AI_USE_GUIDE.md` | For you: student guidance, verification habits, disclosure policy, and the no-AI final boundary. |
| `module_03_lab.qmd` | The offline executable lab, following the production deck's learning arc. Runnable Quarto/R, start to finish, as shipped. |
| `R/arma_simulator.R` | Stamped canonical master-equation simulator. |
| `R/diagnostics.R` | Stamped canonical `show_fingerprint()` and `pacf_by_regression()` helpers. |
| `R/fingerprint_mysteries.R` | Four deterministic sealed fingerprints. **Source it; do not read below its SPOILERS banner.** |
| `R/fetch_fred.R` | Optional live FRED refresh; requires `fredr` and an environment key. Nothing in the lab requires it. |
| `R/checks.R` | Seven legible assertions that referee the pack, printing PASS/FAIL. Run it any time. |
| `CHECKS.md` | What each check means and what a failure usually indicates. No mystery answers. |
| `data/UNRATE.csv` | Cached monthly U.S. unemployment rate, 1948 onward. |
| `data/README.md` | Provenance, coverage, and the documented 2025-10 release gap. |
| `reference/module_03_notes.qmd` | **The full chapter** — your AI tutor can read and cite this. It's a stamped copy for reading and citing, not for rendering in place. |
| `TEXTBOOK_MAP.md` | Citation-only concept pointers into Enders, Hamilton, and Hyndman, plus a notation translation table; no textbook excerpts. |
| `LEARNING_LOG.md` | Your private log. Never collected, never graded. |
| `CLAUDE.md`, `AGENTS.md` | Identical auto-loaded briefings for folder-aware AI tools. You don't need to read these. |

There is no external ACF/PACF trainer dependency. The four mystery series in
this folder provide deterministic, offline commit-then-reveal practice.

---

## Recommended order

1. **`MODULE_CONTEXT.md`** — 10 minutes. Gives you the shape of the module and the notation.
2. **`AI_USE_GUIDE.md`** — 5 minutes. Read this before you start asking an AI anything, not after.
3. **`module_03_lab.qmd`** — the main event. Open it in RStudio (or any Quarto-capable editor) and work through it section by section, running chunks as you go. Write predictions before meaningful chunks. The four sealed fingerprints in section 9 are the payoff — commit a class and an order before revealing one series at a time.
4. **`reference/module_03_notes.qmd`** — when you want the full treatment of something the lab touched briefly. This is the canonical chapter; the lab is the sandbox.
5. **`LEARNING_LOG.md`** — as you go, not at the end. Record surprises while they are fresh.

`TEXTBOOK_MAP.md` and `CHECKS.md` are references. Reach for them when you need them.

---

## Starting a session with an agentic CLI tool

If you're using Claude Code, Codex, or anything else that can read a folder:

1. Open a terminal in **this folder** (`ai_packs/module_03/`).
2. Start the tool. It will pick up `CLAUDE.md` or `AGENTS.md` automatically and read the contract.
3. Just say what you want to do. For example:
   - "I'm starting Module 3. Walk me through the lab section by section."
   - "Run the common-innovations comparison and make me predict which shock expires."
   - "I think mystery 2 is an MA(2). Challenge the evidence, then reveal it."
   - "Why can the UNRATE full sample look like white noise when the sensitivity sample does not?"

You don't need a special prompt. The folder is the prompt.

## Starting a session with a chat tool

If you're using a web chat interface (ChatGPT, Claude, Gemini, a local model):

1. Upload or paste **`MODULE_CONTEXT.md`** and **`AI_TUTOR_CONTRACT.md`**. These two are designed to work standalone and together fit inside a small context window — a local model on your laptop gets the same tutor as anyone else.
2. Add whichever lab section you're working on, if the tool can take it.
3. Then ask your question normally.

If the tool has a persistent "custom instructions" or "project" feature, put the
contract there once and you won't have to re-upload it every session.

---

## Picking up where you left off

Sessions end. Context windows reset. AI tools forget everything between
conversations, and they will not tell you they've forgotten.

**`LEARNING_LOG.md` is your thread of continuity.** It's the only thing in this
folder that accumulates *your* thinking rather than the course's. Two habits make
it work:

- Write in it *during* a session, not from memory afterward.
- Start a new session by pasting or pointing at your last entry: *"Here's where I got to last time — I predicted X, found Y, and I'm still unsure about Z. Let's pick up from Z."*

That single sentence rebuilds more useful context than a long re-explanation,
because it tells the tutor what you already know and — more usefully — what you
don't.

The log is private. It is never collected and never graded. It only works if you
write what you actually thought, including the parts that turned out to be wrong.
Its revised-reasoning and remaining-uncertainty fields must stay in your words.

---

## If something breaks

Run this from the folder root:

```
Rscript R/checks.R
```

Seven lines come back, each PASS or FAIL. If they all pass, the pack is intact and
the problem is in something you changed — which is fine, that's what the lab is
for. If one fails, `CHECKS.md` explains what that check asserts and what usually
causes it to fail.

The lab needs R with `ggplot2`, `forecast`, and `patchwork` installed. `fredr` is
optional and used only for a live refresh; the cached data keeps every Core
chunk offline and credential-free.
