# What the Checks Check

`R/checks.R` holds seven assertions about things Module 3 claims are true. Run
it from the pack root at any time:

```
Rscript R/checks.R
```

Each check prints one `PASS` or `FAIL` line with the numbers it computed. Any
failure makes the script exit with a nonzero status, so it works in a script or
a CI job as well as by hand. The last chunk of the lab runs it too — inside a
Quarto render it prints its results without killing the render.

**This is not an answer key.** The checks verify that the *code and data* behave
the way the module says they do. They cannot tell you whether your AR/MA/ARMA
call on a correlogram is any good, and they don't try. They exist so that when
you and an AI tutor disagree about a fact, there's a referee neither of you
controls. Nor do they reveal the sealed mysteries: the pins verify the generated
observations without naming which AR, MA, or ARMA mechanism produced them, so
the file is safe to read.

The file is deliberately written in plain base R plus the pack's own helpers. If
a check confuses you, read it — it's about ten lines each. It runs in a few
seconds; nothing in it is a Monte Carlo.

---

## Check 1 — the canonical simulator has a stable, seed-controlled contract

**Asserts:** two calls to `arma_simulator(n = 80, phi = c(0.55, -0.20),
theta = 0.35)` under the same seed each return a `ts` object of exactly 80
observations, and the two draws are `identical()`.

**Why:** every seeded example in the lab, and every claim of the form "with
seed 1999 the estimate lands near $-1$," rests on the simulator being
deterministic given the RNG state and returning what it says it returns. If
that contract breaks, nothing downstream is reproducible and check 6 and check
7 stop meaning anything.

**A failure usually means:** `R/arma_simulator.R` was edited — an internal
`set.seed()` added, the `burn_in` bookkeeping changed so the returned length is
no longer `n`, or the `ts()` wrapper dropped. It is a stamped copy of the
canonical helper; restore it rather than patching the check.

## Check 2 — lag-polynomial roots classify three representative AR(2) cases

**Asserts:** for $\Phi(L) = 1 - \phi_1 L - \phi_2 L^2$, `polyroot()` puts both
roots outside the unit circle for $\phi = (0.5, 0.3)$ (smallest modulus 1.174),
at least one root on or inside it for $\phi = (0.8, 0.3)$ (smallest modulus
0.927), and both roots outside with a nonzero imaginary part for
$\phi = (0.6, -0.5)$ (modulus 1.414).

**Why:** these are the three AR(2) cases the lab and the notes use to separate
stationary-real, nonstationary, and stationary-complex behavior. Stationarity
is a joint root condition, not a coefficient-size condition — $(0.8, 0.3)$ has
every $|\phi_j| < 1$ and is still explosive — and this check pins that fact in
software.

**A failure usually means:** the coefficients were passed with the wrong sign
convention. `polyroot(c(1, -phi[1], -phi[2]))` is the lag-polynomial form
(roots *outside*); the lab's `characteristic_roots()` uses
`polyroot(c(-phi[2], -phi[1], 1))` (roots *inside*). Mixing the two flips every
verdict. If you edited the coefficient pairs, remember that the reciprocal
convention reverses the inequality you are testing.

## Check 3 — the MA(1) population ACF has its advertised formula and half-bound

**Asserts:** `stats::ARMAacf(ma = 0.7)` returns $\rho(1) = 0.7/(1 + 0.7^2)
\approx 0.4698$ to within $10^{-12}$ and exact zeros at lags 2 through 6; over
the grid $\theta \in \{-3, -1, -0.4, 0, 0.7, 1, 2\}$ the formula
$\theta/(1+\theta^2)$ never exceeds $1/2$ in absolute value and equals exactly
$1/2$ at $\theta = \pm 1$.

**Why:** the single-lag cutoff and the half-bound are the two population facts
that make an MA(1) recognizable. The bound is a *population* statement — the
lab makes a point of showing a sample $|\hat\rho(1)|$ crossing it by chance —
so the check confirms the theory side is exact before you go looking at noisy
samples.

**A failure usually means:** the formula in the check was retyped incorrectly
(the denominator is $1 + \theta^2$, not $1 - \theta^2$), or the MA sign
convention got flipped — the course writes $\Theta(L)$ with plus signs and
`ARMAacf()` agrees; a Box–Jenkins-style minus sign gives $-\rho(1)$. The
comparison is at $10^{-12}$, so an answer that is merely close is a wrong
formula, not rounding.

## Check 4 — population cutoff identities hold in the identifying diagnostic

**Asserts:** the population PACF of an AR(2) with $\phi = (0.6, -0.3)$ is
numerically zero (below $10^{-10}$) at lags 3 through 10, and the population
ACF of an MA(2) with $\theta = (0.8, 0.5)$ is numerically zero at lags 3
through 10.

**Why:** "PACF cuts off at $p$ for AR($p$); ACF cuts off at $q$ for MA($q$)" is
the module's identification table. This check makes the population half of it
executable, so that when a sample correlogram shows a spike at lag 5 you know
the population promises nothing there and the spike is sampling noise.

**A failure usually means:** the `pacf = TRUE` flag was dropped, so the AR(2)
side is now looking at an ACF — which tails off and never hits zero — or the
index ranges were edited. `ARMAacf()` with `pacf = TRUE` starts at lag 1, while
without it the first element is lag 0; that is why the two slices in the code
differ by one.

## Check 5 — the regression construction and stats::pacf agree

**Asserts:** on a seeded 500-observation AR(2) draw, `pacf_by_regression()` and
`stats::pacf()` differ by less than 0.02 in absolute value at every lag from 1
to 4. The shipped seed gives a maximum gap of about 0.0045.

**Why:** the lab defines the PACF as the deepest-lag coefficient in a sequence
of OLS regressions; `stats::pacf()` computes it by the Durbin–Levinson
recursion on the Yule–Walker equations. The two are the same object in the
population and differ in finite samples only by their treatment of the first
few observations. Agreement within tolerance is what lets you trust either one
for the lab's identification work.

**A failure usually means:** `R/diagnostics.R` was edited — the common-window
alignment in `pacf_by_regression()` was changed, or the coefficient being read
off is no longer the deepest lag. A gap that creeps toward 0.02 on a
*different* seed or a shorter series can just be a short-sample draw; the
tolerance is deliberately loose for that reason. A gap of 0.1 or more means the
regression is reading the wrong coefficient.

## Check 6 — a seeded near-boundary MA(1) fit lands near the invertibility boundary

**Asserts:** fitting an MA(1) by `stats::arima()` to a seeded $T = 500$ draw
with $\theta = -0.97$ produces $\hat\theta$ strictly between $-1.001$ and
$-0.95$. The shipped seed gives about $-0.982$.

**Why:** the lab's assumption-break section shows that an estimate piled up
near the invertibility boundary is a warning sign, and that the printed
standard error does not repair boundary asymptotics. The check pins the
estimate to the neighborhood of $-1$ so the lesson is anchored to a
reproducible number rather than to whatever your machine happened to draw.

**A failure usually means:** the seed or the true $\theta$ changed, or
`include.mean = FALSE` was dropped so the fit now spends a parameter on a mean
the DGP does not have. An estimate that lands in the interior (say $-0.7$) on
the shipped seed means `arma_simulator()` is no longer producing the documented
draw — see check 1. An estimate at exactly $-1.0000$ is still a PASS; the
window's lower edge exists only to catch a non-finite or absurd return.

## Check 7 — the sealed data and the cached UNRATE comparison are the documented ones

**Asserts:** each of the four `fingerprint_mystery()` series still opens with
its pinned first three values (to six decimal places); `data/UNRATE.csv` has
940 rows, runs through `2026-04-01`, and has **exactly one** missing value, at
`2025-10-01`; the modeling run trimmed at that first gap has 933 rows ending
`2025-09-01`; and on that run the full-sample differenced ACF has zero spikes
outside the approximate band with $\hat\rho(1) \approx 0.036$, while the
March 2020–December 2021-excluded sensitivity sample has exactly 8.

**Why:** the commit-then-reveal exercise assumes every student, tutor, and
machine sees identical mystery series (`fingerprint_mystery()` seeds
internally and deliberately, and its header says so). And the UNRATE section's
central contrast — a nearly flat full-sample correlogram against a sensitivity
sample with visible dependence — is a specific numerical claim the lab and the
canonical notes both make. The check verifies the observations without naming
which mechanism generated each mystery, so it is safe to read.

**A failure usually means:** one of four things. `R/fingerprint_mysteries.R`
was edited below its SPOILERS banner, so the pins fail. `data/UNRATE.csv` was
edited or re-downloaded — a newer file changes the row count and end date, and
a fresh download can change the column headers. Someone "cleaned" the NA row
at `2025-10-01`, which changes the raw row count and, if it was interpolated
rather than dropped, the length of the modeling run and every ACF built on it.
Or a different R version's RNG produced different mystery draws — the pins are
stable across the R 4.x releases this course supports, and a mismatch there is
worth reporting rather than papering over. In every case, restore the file
rather than patching the check. The detail line names which piece changed.

---

## If a check fails and you can't work out why

Read the check. It's a few lines of base R and it prints the numbers it
computed alongside the target, so the gap between "what we expected" and "what
we got" is right there in the output.

If you're working with an AI tutor, show it the failing line *and* the relevant
source file. "Check 5 fails with a gap of 0.08" plus `R/diagnostics.R` is a
solvable problem; "my checks fail" is not.
