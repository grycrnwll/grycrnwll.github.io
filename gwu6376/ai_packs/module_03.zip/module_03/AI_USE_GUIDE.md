# Using AI Well in This Course

**Econ 6376 — Module 3**

This is written for you, not for the assistant. It's about getting real value out
of an AI tutor instead of the appearance of value.

---

## The short version

AI is extraordinarily good at the things that used to waste your time in a course
like this — debugging R, explaining notation, generating variations of a
simulation, answering the question you were embarrassed to ask in class. Use it
for all of that, freely.

It is much less good at the thing this course actually grades: *judgment about
ambiguous evidence*. Whether a sample correlogram really cuts off after lag 2,
merely looks noisy, or cannot identify an order at the available $T$ is not a
fact to be retrieved. It's a call you make and defend.

Use AI to build the judgment. Don't use it to skip the judgment.

---

## Productive uses

- **Debugging.** "This chunk errors, here's the message." Get the fix, move on. Don't romanticize struggling with a missing comma.
- **Explaining notation.** "Why does $\Phi(L)$ carry minus signs while $\Theta(L)$ carries plus signs?" or "Why is a characteristic root the reciprocal of a lag-polynomial root?" This is exactly the kind of thing a textbook assumes you'll absorb by osmosis and you won't.
- **Generating variations.** "Re-run the MA(2) fingerprint at $T = 60$ instead of 500." Cheap, fast, and the fastest route to intuition about where sample correlograms stop being readable.
- **Being challenged.** "I think mystery 2 is an MA(2). Push back on me." Asking to be argued with is the single highest-value prompt in this course.
- **Rubber-ducking.** Explain your verdict on a mystery series to the AI and let it find the hole. You'll often find it yourself mid-sentence.
- **Checking algebra.** Derive the MA(1) cutoff or an AR(2) root by hand first, then ask it to check the steps — and verify the number in R either way.
- **Chasing tangents.** "What happens to the fingerprint if the innovations are heavy-tailed, or if there's a break?" Turn it into a simulation and find out. Your tutor is instructed to help you do this rather than steer you back to the syllabus.
- **Translating textbooks.** Paste a confusing passage from Enders Ch. 2 and ask it to reconcile the signs, roots, and symbols with the course's. See `TEXTBOOK_MAP.md`.

## Unproductive uses

- **Asking for the classification before you've formed one.** "Is this AR or MA?" gets you a fluent label you'll forget. Form a view first, then ask it to critique yours. The order matters more than it sounds like it should.
- **Asking for a mystery reveal before you've committed a verdict.** `reveal_fingerprint()` costs nothing to run and the reveal is worthless without a committed guess in front of it. The whole exercise is the gap between what you called and what it was.
- **Treating bars outside a band as a mechanical order counter.** The cutoff table is a population result. Short samples create missing and stray sample spikes.
- **Accepting numbers you didn't verify.** LLMs produce confident, plausible, wrong arithmetic. Especially on things like "which of these AR(2) coefficient pairs is stationary" — one sign error reverses the conclusion, and `polyroot()`, `acf()`, and `R/checks.R` are faster than trusting prose.
- **Letting the AI silently remove COVID.** The full UNRATE sample is primary. The exclusion is labeled sensitivity evidence, not a replacement data set.
- **Letting it write your log.** See below.
- **Using it as a search engine for the answer to a graded question.** Permitted, but see the section on assessed work — it doesn't work as well as it feels like it should.
- **Never disagreeing with it.** If you've gone ten sessions without once finding the AI wrong, you aren't checking. It is wrong regularly on this material.

---

## Verification habits

The pack is built so you never have to take anyone's word for anything — mine, or
your tutor's.

**Test claims in R.** Almost every claim in Module 3 is checkable in a few
lines. "An MA(1) ACF cuts off after lag 1" — call `ARMAacf()` and look. "The
PACF of an AR(2) is zero past lag 2" — simulate one and run `pacf()`. If your
tutor asserts something about this material and you can't immediately see how
to test it, ask it to write the test.

**Use `R/checks.R` as a referee.** It holds seven assertions about things this
module claims are true, in readable base R plus the pack's own helpers. Run
`Rscript R/checks.R` any time. If something you were told contradicts a passing
check, the check wins.

**Watch for these specific failure modes.** In my experience they're the common
ones on this material:

- Confusing AR stationarity with MA invertibility. Both use outside roots, but on different polynomials and for different purposes.
- Switching between lag-polynomial roots outside and characteristic roots inside without taking reciprocals.
- Reading an ACF cutoff as AR rather than MA, or forgetting that the AR cutoff appears in the PACF.
- Treating the MA(1) population bound $|\rho_1|\leq0.5$ as an impossible bound on every sample $|\hat\rho_1|$.
- Claiming the first PACF equals $\phi_1$ in every AR($p$). It equals $\rho_1$; only the deepest coefficient at the true order directly matches the corresponding AR coefficient.
- Calling exact $(p,q)$ from a tails/tails ARMA picture. That is the problem Module 4's information criteria solve.
- Calling a near-$-1$ estimate safe because `arima()` returned a small standard error. Boundary inference is the warning, not the reassurance.
- Treating the COVID-excluded UNRATE result as the main estimate. It is explicitly a sensitivity analysis.
- Confusing $\epsilon_t$ and $e_t$, or dropping hats off estimates — same as Modules 1 and 2, and it still matters.

**A good habit:** when the AI tells you something surprising, ask "how would I
check that in R?" before asking anything else. If it can't propose a check, be
suspicious of the claim.

---

## Graded work

**AI assistance is permitted on take-home graded work in this course** —
problem sets and the take-home midterm — **with disclosure.** The final is an
in-person, closed-book, paper-and-pencil exam, so no devices or AI may be used
during it. You may use this pack to prepare for the final.

Disclosure is a brief, free-form statement of how you used it. No form, no
template, no penalty. It just has to be honest and specific enough to be
meaningful. Two sentences is plenty:

> *I used ChatGPT to debug my PACF-by-regression loop in Question 1 and to
> challenge my initial reading of the correlogram in Question 2. I checked the
> roots and sample ACF/PACF in R and made the final model-class judgment myself.*

That's a complete disclosure. Notice it says what was done *where* — "I used AI"
alone doesn't tell me anything.

Your `LEARNING_LOG.md` is **not** the disclosure vehicle. The log is private and
I never see it. Disclosure goes with the submitted work.

### Why pasting through answers won't carry you

I want to be straightforward about this rather than issue a warning.

The assessments in this course are built to be AI-resilient, and they draw
**only** on the Core tier of the module notes. They ask you to interpret
ambiguous output, reconcile two results that disagree, explain why a method
failed, and defend a judgment call. Those questions don't have retrievable
answers — the evidence is genuinely ambiguous, which is the point, and what gets
graded is the quality of your reasoning about the ambiguity.

An answer you didn't build, you can't defend. That shows up immediately in the
follow-up parts of a question, and it shows up badly on a take-home where you had
plenty of time.

So the policy isn't a trap. Using AI heavily and understanding the material are
completely compatible — that's the intended outcome, and it's how you'll work
professionally. Using AI heavily *instead of* understanding the material is a
strategy that fails at the assessment, and more importantly fails in the job
where nobody tells you which model to fit.

---

## About the contract

`AI_TUTOR_CONTRACT.md` asks your tutor to do things like request a prediction
before running a simulation, and to ask for your own words before writing the
last two fields of your learning log.

The prediction ask pauses for one turn — it will hand you two or three options
and wait once. Answer it, or say "just run it" and it runs immediately and drops
the question. It will not ask you twice, and you can tell it to skip predictions
entirely for the whole session. It's your session.

One Module 3 specific: for the four fingerprint mysteries, the tutor runs the
fingerprint evidence without a gate. Its one ask comes immediately before the
reveal — AR, MA, ARMA, or ambiguous at this $T$, with an order if you claim one —
and then it reveals either way. If you ask directly for the answer, it complies;
you have simply chosen to spend that series' surprise. It should not spoil other
series you did not request.

The fourth mystery is deliberately short. "Ambiguous at this sample size" is a
real, calibrated conclusion, not a failure to play.

I'd just say plainly: the contract is there for your benefit, not as a rule
you're being held to. The prediction step exists because being surprised is how
things stick, and skipping it feels efficient in the moment and costs you in
November. Overriding it is a choice you're making about your own learning, and
you're an adult — I only want you making the choice knowingly rather than by
accident.

That's the last I'll say about it.

---

## Intellectual ownership

The point of this course is that you become someone who can take an unfamiliar
series, work out what it is, and defend a modeling decision to a skeptical room.

That capability is built by making predictions, being wrong, and figuring out
why. It is not transferable from a model, and it is not something you can borrow
under deadline. An AI can accelerate every step of building it — and it can also
let you produce work that looks like the finished product without any of the
building having happened.

Both paths are available to you here, and honestly, the second one is easier.
The difference shows up when you're the one in the room who has to say what the
data means.
