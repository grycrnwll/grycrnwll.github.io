# Module 7 Context — Forecast Evaluation and Combinations

**Econ 6376 — Applied Time Series Econometrics, George Washington University (Applied Economics MA).**

This file is self-contained. Paste or upload it on its own into any AI
assistant and it will have everything it needs to help with Module 7.

<!-- BEGIN COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

## Course-wide conventions

These apply to every module of Econ 6376, not just this one.

### The master equation

Every model in this course is the following equation with some terms switched off:

$$y_t = \alpha + \delta t + \sum_{j=1}^{p} \phi_j y_{t-j} + \sum_{l=1}^{q} \theta_l \epsilon_{t-l} + \epsilon_t$$

The course analogy is a **mixing board**: each term is a slider, and each module
turns on new ones. A student should always be able to say where the model in
front of them sits on that board. If they can't, the framing has failed — help
them locate it.

### The cardinal notation rule: DGP vs. estimation

A data-generating process and an estimating equation look different, and the
course is strict about this.

- **DGP (the truth, unobservable):** unhatted parameters $\alpha, \delta, \phi_j, \theta_l, \beta$ and $\epsilon_t$, the **innovation**.
- **Estimating equation (your model, observable):** hatted parameters $\hat\alpha, \hat\phi_j, \hat\theta_l, \hat\beta$ and $e_t$, the **residual**, where $e_t = y_t - \hat y_t$.

Never write $\epsilon_t$ when you mean $e_t$. Never drop a hat from an estimate.
A well-specified model leaves residuals that behave like the innovations that
model assumes — that is the entire basis of diagnostic testing later in the course.

### Other standing conventions

- **Lag polynomials:** AR takes minus signs, $\Phi(L) = 1 - \phi_1 L - \cdots - \phi_p L^p$. MA takes plus signs, $\Theta(L) = 1 + \theta_1 L + \cdots + \theta_q L^q$.
- **Stationarity framing:** all roots of $\Phi(L) = 0$ lie strictly **outside** the unit circle. Enders and the older course slides use the equivalent characteristic-root-**inside** framing (related by $r = 1/L$). Both are correct; flag the difference whenever a student is cross-referencing a textbook.
- **Symbols:** $\phi$ = AR coefficients, $\theta$ = MA, $\beta$ = covariates, $\alpha$ = intercept, $\delta$ = trend. $\gamma_k$ = autocovariance at lag $k$, $\rho_k$ = autocorrelation, $\gamma_0 = \operatorname{Var}(y_t)$. $L$ = lag operator, $\Delta = (1-L)$. $t = 1,\ldots,T$.
- **"Stationary"** means weakly (covariance) stationary unless stated otherwise.
- **Language:** the course is taught in R. Students may submit graded work in another language if they can reproduce the workflow, but help and debugging are R-first. Plots use `ggplot2`.
- **Credentials:** FRED keys come from `Sys.getenv("FRED_KEY")`, never hardcoded, never committed.

### Working rules

- Concept before math, always. Intuition first, then notation.
- Simulation is the center of gravity, and a simulation that only confirms the textbook is half an exercise. Breaking an assumption is where understanding happens.
- The four-step rhythm for any major topic: **Concept → Math → Simulate (break something) → Real Data.**
- The student-facing learning protocol: **Predict → Commit → Ask AI → Test in R → Reconcile.**
- **Core is the assessable surface.** Course notes are tiered (Core / Deeper Dive / Technical Note / Looking Ahead). Problem sets and exams draw **only** on Core. Optional tiers are genuinely optional — never imply otherwise.

<!-- END COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

---

## What Module 6 established

Three facts this pack relies on, so it stands alone:

1. A forecast is a distribution; the loss $g(e)$ picks the target; compare forecasts within one loss, never across.
2. A split is a date, never a random draw. `Arima(y, model = fit)` re-applies training coefficients to a longer series without re-estimating; `fitted()` then gives the one-step forecast at every date from information through $t-1$.
3. Module 6 fit the Module 5 SARIMA, ARIMA$(1,1,2)(1,0,1)_{12}$ on UNRATE through December 2017, forecast 2018–2019 from that one origin, and lost to the naive random walk by a few hundredths. It left one question open: *does that margin mean anything?*

## What Module 7 is about

Three questions: **how do I score several forecasts** ($U_2$, MASE), **is the
gap between two of them real** (Diebold-Mariano), and **should I pick one at
all** (combinations, and why the simple average is so hard to beat). Every
topic runs on a simulated DGP and on cached UNRATE 1960–2019.

**On the mixing board, Module 7 turns on nothing new.** Module 6 pushed *one*
fitted equation forward; Module 7 puts *several* forecasts on the table and
referees between them. Module 8 adds $\beta x_t$.

Lab map: 2 the PS3 design and six tracks on UNRATE · 3 the course simulation ·
4 three evaluation schemes · 5 $U_2$ and MASE · 6 Diebold-Mariano and the
power break · 7 why combine · 8 four methods · 9 the assumption-break and the
puzzle · 10 the PS3 workflow on UNRATE · 11 Explorations.

### Core learning objectives

1. Describe the PS3 one-step design; build the six tracks with correct alignment.
2. Name the three evaluation schemes and their costs.
3. Compute RMSE, MAE, MAPE, MASE and $U_2$; state each relative metric's question.
4. Run and read DM (`h = 1` assumes serially uncorrelated $d_t$); explain why short windows rarely reject.
5. Derive inverse-variance weights from the two-forecast error variance.
6. Compute the four combination methods; say what each estimates.
7. Explain the combination puzzle as attainable gain against estimation cost.
8. Execute the PS3 workflow on UNRATE and read it honestly.

---

## Notation for this module

**Tilde for forecasts, hat for estimates (decision 74).** Every forecast
carries a tilde, including the one-step tracks R returns from `fitted()` on a
refiltered model. A hat marks a fitted value or an estimate: $\hat\phi$, the
estimated weights $\hat w_0, \hat w_m, \hat{\mathbf w}$, $\hat\sigma_{\bar d}$.
From Module 7 on, a hat is never a forecast (Modules 5–6 wrote
$\hat y_{t+h\mid t}$ for what is now $\tilde y_{t+h\mid t}$).

| Symbol | Meaning |
|---|---|
| $m = 1,\ldots,M$ | Forecaster index; $M = 6$ in the PS3 design |
| $\tilde y^{(m)}_{t\mid t-1}$ | Forecaster $m$'s one-step forecast of $y_t$; $h = 1$ throughout |
| $\tilde{\mathbf y}_t$ | $M \times 1$ vector of the $M$ forecasts of $y_t$ |
| $e_{m,t} = y_t - \tilde y^{(m)}_{t\mid t-1}$ | One-step **forecast error**, out of sample, observable; not $\epsilon_t$, not a residual. DM's two are $e_{1,t}, e_{2,t}$ |
| $T$, $T_w$, $N$, $N_{\text{total}}$ | Training end ($T = N_{\text{total}} - 24$); weights-window length ($T_w = 12$); holdout length ($N = 12$, never $h$); total length |
| $\tilde y^{(c)}_{t\mid t-1} = w_0 + \mathbf w'\tilde{\mathbf y}_t$ | Combined forecast; $w_0$ is zero except for Granger-Ramanathan |
| $w_m$, $\hat w_m$, $w^*$ | Generic or fixed weight (the simple average's $1/M$, no hat); estimated weight (hat); population-optimal weight (star) |
| $e_{c,t}$ | Combined-forecast error; $c$ is a label, not an index |
| $v_t$ | Disturbance in the Granger-Ramanathan regression; not $\epsilon_t$, $e_t$, $e_{m,t}$ or $u_t$ |
| $\rho_{1,2}$ | Correlation between two forecasters' errors. **Always with the comma**: $\rho_{12}$ is the lag-12 autocorrelation |
| $g(\cdot)$; $d_t = g(e_{1,t}) - g(e_{2,t})$ | Loss function; loss differential |
| $\bar d$; $\hat\sigma_{\bar d}$; $\hat\sigma_d$ | Mean loss differential; its standard error (in general allows for serial correlation; `dm.test(h = 1)` truncates to lag 0); sample SD of $d_t$ |
| $\text{DM} = \bar d/\hat\sigma_{\bar d}$ | Diebold-Mariano statistic, $N(0,1)$ under $H_0\!: \mathbb{E}[d_t] = 0$ |
| $U_2^{(m)}$, $\text{MASE}^{(m)}$ | Relative metrics, defined below |

**Never**: $\alpha$/$\beta$ as weights; $F$ as a math symbol (Module 9's
$F$-test; `F` is fine in R); "moving average" for a $k$-period average forecast
(that is MA($q$)); $m$ for the seasonal lag in math (it is $s$; `mase()` calls
it `m`). Non-Core: $\boldsymbol\Sigma_e$, $z_t$.

---

## Core concepts

**The PS3 design: many origins, one horizon.** Module 6 used one origin and
many horizons. Module 7 estimates every model **once** on $y_1,\ldots,y_T$ and
forecasts one step ahead at each date, rolling the information set, not the
coefficients. Train $1{:}T$; weights window $(T{+}1){:}(T{+}12)$, where
combination weights are estimated; holdout $(T{+}13){:}(T{+}24)$, where
everything is scored. ARIMA tracks: `fitted(Arima(upto(y, T + 12), model =
fit))`, and `T + 24` for the holdout; extending the series never changes an
earlier one-step forecast. **`upto()` uses `window()`, not brackets**: `y[1:T]` drops
the frequency, so a fresh `auto.arima()` on it never searches seasonal models.
**Alignment check first**: `locf` on date $t$ must equal $y_{t-1}$.

**Six tracks.** Three ARIMA tracks and three **$k$-period average forecasts**
$\tilde y_{t\mid t-1} = \frac1k\sum_{j=1}^k y_{t-j}$: `locf` ($k = 1$, the naive
random walk), `avg_k` ($k = 3$ on UNRATE, smoothing survey noise; the choice of
$k$ is a statement about persistence), `meanf` ($k = t-1$, the expanding mean).
On UNRATE: `arima_1` = ARIMA$(1,1,2)(1,0,1)_{12}$, `arima_2` = ARIMA$(1,1,0)$,
`arima_3` = `auto.arima()` on train. **`meanf` on an I(1) series is broken**:
the average of a level that has wandered for sixty years. Order of integration
decides which baselines are credible.

**The course simulation.** $(1-0.7L)(1-0.5L^{12})y_t = 0.75 + \epsilon_t$,
$\epsilon_t \sim N(0,1)$, mean 5; 240 training months. `arima_1` is the true
specification (estimated, so not an oracle), `arima_2` an AR(1) missing the
season, `arima_3` an ARIMA$(0,1,1)$ with a needless difference. Built so **one
track is genuinely better** and equal weights are not optimal: a fair test.

**Three evaluation schemes.** Fixed-parameter one-step (PS3, the only one
built); expanding window, re-estimated; fixed-width rolling window,
re-estimated. Re-estimation buys robustness to change at the cost of
computation and noisier parameters; fixed-width windows forget old regimes on
purpose.

**$U_2$ versus MASE: two questions.** Over holdout dates $t = T+13,\ldots,T+24$:
$U_2^{(m)} = \text{RMSE}^{(m)}/\text{RMSE}^{(\texttt{locf})}$, both on the **same**
dates: *did the model beat the naive here?* $\text{MASE}^{(m)}$ = holdout MAE
of $m$ divided by `locf`'s one-step MAE on **training**,
$\frac{1}{T-1}\sum_{t=2}^{T}|y_t - y_{t-1}|$: *how big was the miss relative to
the naive's typical training miss?* MASE $< 1$ does **not** mean the model beat
the naive; on a calm holdout everything, the naive included, clears it.
Seasonal MASE scales by $\frac{1}{T-s}\sum_{t=s+1}^{T}|y_t - y_{t-s}|$. MAPE is a
percentage, undefined at $y_t = 0$. **`accuracy()` differs**:
for a seasonal `ts` its MASE uses the seasonal-naive scale (`m = 12`; on
seasonally adjusted UNRATE that measures a year of drift), and its "Theil's U"
is a relative-change cousin of $U_2$. $U_1$ is a Deeper Dive.

**Diebold-Mariano: a $t$-test on loss differentials** (the taste test: twelve
paired sips). $H_0\!: \mathbb{E}[d_t] = 0$, $\text{DM} = \bar d/\hat\sigma_{\bar
d}$, $N(0,1)$ under the null, $\hat\sigma_{\bar d}$ allowing for serial
correlation in $d_t$. **At `h = 1`, `dm.test()` uses only the lag-0 variance,
so it assumes $d_t$ is serially uncorrelated**: a condition on $d_t$, not
merely on the errors; optimal one-step errors make it plausible, not
guaranteed. With the Harvey-Leybourne-Newbold correction and a $t_{N-1}$
reference, DM at $h = 1$ equals the one-sample $t$ statistic of $d_t$. Rules:
out-of-sample errors only; same dates, same loss; DM $< 0$ means forecast 1
had the smaller loss. **Power**: DM rejects when the gap is large relative to
the variability of $d_t$; twelve dates buy little, so "failed to reject" means
"these dates cannot separate them", never "equally good". DM does not apply to
Module 6's single-origin 24-step errors (shared early shocks, spread growing
with the horizon). HAC machinery is a Technical Note; Clark-West a Deeper Dive.

**Why combine.** Forecasts are assets, errors their risks. With weights $w$,
$1-w$, $e_{c,t} = w e_{1,t} + (1-w)e_{2,t}$ and $\text{Var}(e_{c,t})$ is the
portfolio variance; minimizing it gives $w^*$ (Enders eqs. 2.71–2.73). Zero
covariance: $w^*$ is inversely proportional to each error variance; equal
variances $V$ give $w^* = 0.5$ and variance $0.5V$. **Correlation eats the
gain**: it vanishes once $\rho_{1,2} \ge \sqrt{\text{Var}(e_{1,t})/
\text{Var}(e_{2,t})}$ (forecast 1 the better); beyond that $w^* > 1$ shorts the
worse forecast.

**Four methods** (fit on the weights window, applied unchanged to the holdout
as $\hat w_0 + \hat{\mathbf w}'\tilde{\mathbf y}_t$; contract `f(y, F)` →
`list(intercept, weights)`):

1. **Simple average** $w_m = 1/M$, $w_0 = 0$. Nothing estimated.
2. **Inverse-MSE** $\hat w_m \propto 1/\text{MSE}_m$, each from its own column; MSE so bias is penalized.
3. **Granger-Ramanathan**: $y_t = w_0 + \sum_m w_m\tilde y^{(m)}_{t\mid t-1} + v_t$ by OLS, intercept, no constraints; $M + 1 = 7$ numbers from 12 points. An exactly collinear track gives `NA`: weight 0 (in the simulation `arima_2`'s forecast is an intercept plus a multiple of `locf`).
4. **Constrained LS**: no intercept, $w_m \ge 0$, $\sum w_m = 1$; one `quadprog::solve.QP()` call (`meq = 1` for the sum-to-one equality). Zeros are model selection. No intercept: reweighting can reduce bias but not remove a common same-direction bias.

A dial: SA estimates nothing, inverse-MSE a little, CLS more inside a box, GR
everything. Canonical copies in `R/` (`quadprog`; `ForecastComb` is retired).
Full-covariance Bates-Granger is a Technical Note; robust combinations, Enders'
drop-the-most-negative fix and the three GR regressions are Deeper Dives.

**The assumption-break: you don't know the weights.** GR minimizes the
weights-window SSE, so nothing fits that window better; but its weights are
estimates from twelve points. **A combination method is an estimator.** **The puzzle** (Stock and Watson 2004): theory says optimal
weights dominate, practice says the simple average is hard to beat; the
governing comparison is **attainable gain over equal weights versus the cost of
estimating the weights**. Near-equal optimal weights are the important special
case, not a necessary condition: redundant forecasts can leave little gain
even when optimal weights are far from $1/M$. Index-fund analogy: fees
(estimation error) eat the active manager's edge. **Equal weights are robust to
estimation error; whether they win depends on how large the attainable gain
is.**

**The PS3 workflow on UNRATE (section 10)**, "on a series that isn't yours":
weights fit on 2018, holdout 2019, then DM of each estimated-weight combination
against the simple average, three tests declared in advance (never pick the
winner, then test it on the same dates). Caveats: one calm window, one draw.

---

## Vocabulary

Beyond the terms above: refiltering · directional rejection (null benchmark
2.5%) · aliased coefficient · condition number · broken pool member.

---

## Two subtleties

1. **Two windows, two jobs.** The weights window *estimates* the combination;
   the holdout *scores* it. Scored on its own window, GR always wins.
2. **One principle, two datasets.** Whether estimated weights beat equal
   weights is always gain against estimation cost; the simulation and UNRATE
   can land on different sides of it. Let the student find out which.

---

## Common misconceptions

Correct these by asking a question or running something, not by lecturing.

1. **"MASE $< 1$ means my model beat the naive."** That is $U_2 < 1$. Ask what MASE `locf` itself gets in 5b.
2. **"DM failed to reject, so the models are equally good."** The dates cannot separate them (6b).
3. **"DM always fails with twelve observations."** Power is low at $N = 12$, but it depends on the gap relative to the noise in $d_t$: a large enough gap can reject.
4. **"I can feed `residuals(fit)` to `dm.test()`."** Out-of-sample errors only.
5. **"`h = 1` makes DM robust to autocorrelation."** It assumes $d_t$ is serially uncorrelated. Offer exploration 2, or run the $d_t$ ACF on the §6a errors in front of the student; never quote the exploration-2 anchors before they run it.
6. **"Granger-Ramanathan weights are optimal, so use them."** Optimal in population, estimated from twelve points.
7. **"A negative weight (or an `NA`) is a bug."** Negative: estimation error with correlated forecasts. `NA`: exact collinearity, weight zero.
8. **"The simple average always wins."** Only when the attainable gain from estimated weights is small relative to their estimation cost. Ask what could make that gain large.
9. **"`avg_k` is a moving-average model."** It is a $k$-period average forecast.
10. **"Re-fit the ARIMA on `y[1:(T+12)]` before the holdout."** Parameters are estimated once; and brackets drop the frequency.
11. **"`accuracy()` gives the course's MASE and $U_2$."** It does not; use `mase()` and `theil_u2()`.

---

## The Module 7 → Module 8 handoff

Every forecast here used only the series' own past, and combinations only
reshuffle the information in the pool. Module 8 asks: **what if an exogenous
regressor could improve the forecast?** It turns on $\beta x_t$ and its lags. If the student asks for
later-module machinery (an ADL forecast, a Granger test, a VAR forecast),
build it on request and flag it as a preview of the module it belongs to; do
not deflect them back to Module 7.

---

## Lab anchors (for the tutor: the numbers a student's predictions get reconciled against)

Reconcile after the student predicts, or give at once if asked outright. Core
concepts above also answer lab predictions; on lab-section questions, hold them
for the reconcile.

- **§1–2.** $T = 696$ (December 2017). `auto.arima()` picks ARIMA$(1,1,3)(2,0,2)_{12}$. Five credible tracks differ by hundredths; `meanf` sits near 6.0%.
- **§5a (sim holdout).** MASE / $U_2$: `arima_1` 0.831 / 0.861 (best on every metric); `arima_2` 1.004 / 0.929.

### Reveal anchors — for the tutor; do not volunteer before the lab asks

- **§6a.** Sim DM `arima_1` vs `locf` $= -0.90$, $p = 0.390$, equal to the $t$ statistic; no rejection.
- **§7.** Gain threshold $\rho_{1,2} \approx 0.82$ for variances 1 and 1.5.
- **§8 (sim weights window).** GR: $\hat w_0 = 261.7$, `meanf` $-50.8$, `locf` `NA` → 0. CLS: `arima_1` 0.657, `meanf` 0.343, others 0. IMSE: `arima_1` 0.271 highest, `locf` 0.093 lowest.
- **§5b (UNRATE 2019).** RMSE / MASE / $U_2$: `arima_1` 0.097 / 0.642 / 1.011; `arima_2` 0.097 / 0.607 / 1.016; `arima_3` 0.096 / 0.618 / 0.999; `locf` 0.096 / 0.580 / 1.000; `avg_k` 0.108 / 0.709 / 1.124; `meanf` 2.315 / 17.875 / 24.182. `locf` has the smallest MAE (0.075).
- **§6c.** UNRATE DM `arima_1` vs `locf` $= 0.13$, $p = 0.90$.
- **§6b power** (share of directional rejections favouring `arima_1`; null benchmark 2.5%). vs `locf`: 12.5% / 40.5% / 76.0% / 95.5% at $N = 12/24/60/120$; vs `arima_2`: 10.0% / 29.0% / 60.5% / 86.0%.
- **§9 Stage 1** (window / holdout RMSE): `arima_1` 0.706 / 1.120; SA 0.877 / 1.284; IMSE 0.804 / 1.281; CLS 0.681 / 1.237; **GR 0.282 / 3.009** (best window, worst holdout).
- **§9 Stage 2** ($T_w = 12$, ratio to SA: median / mean / p90 / % beating SA): IMSE 0.99 / 0.98 / 1.01 / 74.5%; CLS 0.95 / 0.95 / 1.12 / 64.0%; GR 1.68 / 2.22 / 4.07 / 16.0%.
- **§9 Stage 3** (medians at $T_w = 12/24/60/120$): GR 1.68 / 1.12 / 0.98 / 0.93 (crosses 1 between 24 and 60); CLS 0.95 / 0.93 / 0.94 / 0.90; IMSE 0.98–0.99 throughout; `arima_1` alone 0.90 / 0.90 / 0.92 / 0.90.
- **§10 weights.** IMSE: `meanf` 0.001, credible tracks 0.158–0.235. CLS: `arima_1` 0.69, `avg_k` 0.31, others 0. GR: $\hat w_0 = -141.45$, `meanf` 24.8, `locf` 5.10, `arima_2` $-5.83$; condition number ≈ 41,620.
- **§10 holdout RMSE.** Credible tracks 0.096–0.108; SA **0.416**; IMSE 0.093; CLS 0.094; GR 0.463. `meanf`'s sixth of the vote drags SA about 0.39 points off.
- **§10 DM vs SA.** IMSE $-9.1$, $p = 1.9\times10^{-6}$; CLS $-9.1$, $p = 1.8\times10^{-6}$; GR 0.87, $p = 0.40$.
- **Exploration 2.** Ljung-Box $p$ 0.58–0.97 on lags 1–3; lag-1 ACFs $-0.33$ to $0.10$; Bartlett $h = 2$–4 re-runs change no verdict at 5%.
