# Stamped copy of the whole of helpers/combination_utils.R in the Econ 6376 course repo — behavior unchanged; edits belong in the canonical file.

# =============================================================================
# combination_utils.R — Forecast-combination weights
# Econ 6376: Applied Time Series Econometrics
#
# The four Core combination methods of Module 7 (notes §7.6):
#   comb_simple()  : simple average, w_m = 1/M
#   comb_inv_mse() : inverse-MSE weights (the M-forecast version of the
#                    zero-covariance Bates-Granger weight; Enders ch. 2 §13,
#                    eq. 2.74)
#   comb_gr()      : unconstrained least squares with an intercept
#                    (Granger-Ramanathan 1984; Enders eq. 2.75; Wang, Hyndman,
#                    Li & Kang 2023, IJF, §2.2 eq. 4)
#   comb_cls()     : constrained least squares — no intercept, w_m >= 0,
#                    sum(w_m) = 1 (one quadprog::solve.QP() call)
#
# Built inline in the Module 7 notes (§7.6); this file is the canonical copy
# that Problem Set 3 and Module 8+ source. The Module 7 notes build these
# inline rather than sourcing this file; the Module 7 pack sources it only to
# compare against the inline builds and in its checks.
#
# Common contract
#   y : actuals on the weights window (numeric, length T_w)
#   F : T_w x M matrix of one-step forecasts of those same dates, one column
#       per forecaster, WITH column names (F is an R argument name only; the
#       course never uses F as a math symbol — that is the Granger F-test)
# Each function returns list(intercept = <scalar>, weights = <named, length M>).
#
# PS3 usage pattern
#   cw     <- comb_cls(y_w, F_w)                     # fit on the weights window
#   y_comb <- cw$intercept + F_h %*% cw$weights      # apply to the holdout
#
# Requires: quadprog (comb_cls only; installed with forecast via tseries).
# =============================================================================

.check_comb_inputs <- function(y, F) {
  # Shared input checks: F a numeric matrix with column names, y the same
  # number of rows, no missing values. Returns F as a matrix.
  F <- as.matrix(F)
  if (!is.numeric(F)) stop("F must be a numeric matrix of forecasts.")
  if (is.null(colnames(F))) {
    stop("F needs column names (one per forecaster), e.g. ",
         "cbind(arima_1 = ..., locf = ...).")
  }
  y <- as.numeric(y)
  if (length(y) != nrow(F)) {
    stop("length(y) = ", length(y), " but nrow(F) = ", nrow(F),
         ": y and F must cover the same dates.")
  }
  if (anyNA(y) || anyNA(F)) {
    stop("y or F contains NA. Check the alignment of your forecast tracks.")
  }
  F
}

comb_simple <- function(y, F) {
  # Simple average: w_0 = 0, w_m = 1/M. Nothing is estimated.
  # `y` is unused; it is kept so all four methods share one interface.
  F <- .check_comb_inputs(y, F)
  M <- ncol(F)
  list(intercept = 0,
       weights   = setNames(rep(1 / M, M), colnames(F)))
}

comb_inv_mse <- function(y, F) {
  # Inverse-MSE weights: w_m = (1/MSE_m) / sum_j (1/MSE_j), w_0 = 0.
  # MSE (not variance), so a biased forecaster is penalized for its bias.
  F <- .check_comb_inputs(y, F)
  mse <- colMeans((as.numeric(y) - F)^2)   # y recycles down each column
  if (any(mse == 0)) {
    stop("Track(s) with zero MSE on the weights window: ",
         paste(colnames(F)[mse == 0], collapse = ", "),
         ". A track that equals the actuals is a leak, not a forecast.")
  }
  w <- (1 / mse) / sum(1 / mse)
  list(intercept = 0, weights = setNames(w, colnames(F)))
}

comb_gr <- function(y, F) {
  # Granger-Ramanathan: regress the actuals on the forecasts WITH an
  # intercept and no constraints. Weights can be negative and need not sum
  # to one. With M = 6 and T_w = 12 this estimates 7 numbers from 12 points.
  #
  # Exactly collinear tracks give aliased (NA) coefficients: warn, naming
  # them, and set their weight to 0. The fitted values are unchanged —
  # equivalent to dropping the duplicate. This is not hypothetical: the
  # one-step forecast of an AR(1)-with-mean track is exactly
  # mu(1 - phi) + phi * y_{t-1}, an intercept plus a multiple of locf, so with
  # GR's intercept the two are one regressor (Module 7 notes, §7.6, on the
  # course DGP). avg_k with k = 1 duplicating locf is another case.
  F <- .check_comb_inputs(y, F)
  y <- as.numeric(y)
  fit <- lm(y ~ F)
  b <- coef(fit)
  w <- setNames(b[-1], colnames(F))
  aliased <- is.na(w)
  if (any(aliased)) {
    warning("Exactly collinear track(s) given weight 0: ",
            paste(names(w)[aliased], collapse = ", "),
            ". Fitted values are unchanged; consider dropping the duplicate.",
            call. = FALSE)
    w[aliased] <- 0
  }
  list(intercept = unname(b[1]), weights = w)
}

comb_cls <- function(y, F) {
  # Constrained least squares: no intercept, w_m >= 0, sum(w_m) = 1.
  #   min_w sum_t (y_t - w'ytilde_t)^2   s.t.  1'w = 1,  w >= 0
  # quadprog::solve.QP() minimizes (1/2) w'Dw - d'w subject to A'w >= b,
  # the first `meq` constraints holding with equality:
  #   D = F'F, d = F'y, A = [1 | I_M], b = (1, 0, ..., 0), meq = 1.
  #
  # solve.QP needs F'F positive definite. Under exact collinearity this
  # stops and names the tracks; there is no silent ridge.
  F <- .check_comb_inputs(y, F)
  y <- as.numeric(y)
  M <- ncol(F)
  q <- qr(F)
  if (q$rank < M) {
    dropped <- colnames(F)[q$pivot[(q$rank + 1):M]]
    stop("Exactly collinear forecast tracks on the weights window (",
         paste(dropped, collapse = ", "),
         " is a linear combination of the others). Drop one and refit.")
  }
  D    <- crossprod(F)                 # M x M:  F'F
  d    <- crossprod(F, y)              # M x 1:  F'y
  Amat <- cbind(rep(1, M), diag(M))    # col 1: sum-to-one; cols 2..M+1: w_m >= 0
  bvec <- c(1, rep(0, M))
  sol  <- quadprog::solve.QP(Dmat = D, dvec = d, Amat = Amat,
                             bvec = bvec, meq = 1)
  w <- pmax(sol$solution, 0)           # clip -1e-17 round-off to exact zero
  w <- w / sum(w)
  list(intercept = 0, weights = setNames(w, colnames(F)))
}
