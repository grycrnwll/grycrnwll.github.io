# =============================================================================
# checks.R — the referee for the Module 7 AI Learning Pack (Econ 6376)
#
# Seven assertions about the numerical claims, helpers and shipped data in
# Module 7. Run from the pack root:   Rscript R/checks.R
# Each check prints one PASS/FAIL line. Any FAIL exits with a nonzero status.
#
# Uses base R plus the lab's own packages: forecast (Arima, dm.test) and
# quadprog (inside comb_cls). The helpers are the stamped canonical copies in
# R/, not the lab's inline builds. This is readable evidence, not an answer key.
# =============================================================================

suppressPackageStartupMessages({
  library(forecast)
  library(quadprog)
})
# local = TRUE: the helpers land in the environment this script runs in. When
# the lab runs source("R/checks.R", local = new.env()), that is a private
# environment, so the student's inline upto(), tracks_on(), comb_*() and data
# objects are never overwritten.
source("R/forecast_utils.R", local = TRUE)      # rmse(), theil_u2(), mase()
source("R/track_utils.R", local = TRUE)         # upto(), kavg(), tracks_on()
source("R/combination_utils.R", local = TRUE)   # comb_simple(), comb_inv_mse(), comb_gr(), comb_cls()

# ---- tiny test harness ------------------------------------------------------
# A failed assertion does not hide later checks.
results <- logical(0)

check <- function(label, passed, detail = "") {
  passed <- isTRUE(passed)
  results[[length(results) + 1L]] <<- passed
  cat(sprintf("%-4s %s%s\n",
              if (passed) "PASS" else "FAIL",
              label,
              if (nzchar(detail)) paste0("  [", detail, "]") else ""))
  invisible(passed)
}

# TRUE if expr stops with an error, FALSE otherwise
stops <- function(expr) inherits(try(expr, silent = TRUE), "try-error")

# Run one check's block; a runtime error inside it becomes a FAIL line
# instead of stopping the script (so later checks still run, and a knitr
# render still reaches the verdict).
run <- function(label, expr) {
  tryCatch(expr, error = function(e)
    check(paste(label, "could not run"), FALSE, conditionMessage(e)))
}

cat("Module 7 checks\n---------------\n")

# ---- shared setup (unguarded) -----------------------------------------------
# The data and the PS3 dates used by checks 1, 2 and 7. Kept outside the
# per-check guards so that an error inside one check cannot remove an object a
# later check needs. If this block itself errors, the script stops here.
unr <- read.csv("data/UNRATE.csv", stringsAsFactors = FALSE)
unrate <- window(ts(unr$UNRATE, start = c(1948, 1), frequency = 12),
                 start = c(1960, 1), end = c(2019, 12))
T_origin <- length(unrate) - 24
train_un <- upto(unrate, T_origin)
w_dates  <- T_origin + 1:12          # weights window: 2018
h_dates  <- T_origin + 13:24         # holdout: 2019
y_num    <- as.numeric(unrate)


# ---- 1. the data are the data ------------------------------------------------
run("Check 1", {
# UNRATE keeps its two columns and its single known blank (2025-10-01); the
# 1960-2019 window is 720 months, so T = 720 - 24 = 696 ends in December 2017.
in_win <- unr$observation_date >= "1960-01-01" & unr$observation_date <= "2019-12-01"
data_ok <- identical(names(unr), c("observation_date", "UNRATE")) &&
  sum(is.na(unr$UNRATE)) == 1L &&
  identical(unr$observation_date[is.na(unr$UNRATE)], "2025-10-01") &&
  sum(in_win) == 720L && !anyNA(unrate) && length(unrate) == 720L &&
  isTRUE(all.equal(time(unrate)[T_origin], 2017 + 11/12))
check("UNRATE cache intact: one blank (2025-10), 720 months in 1960-2019, T = 696 ends December 2017",
      data_ok,
      sprintf("rows = %d, blanks = %d, window = %d, T = %d, Dec 2017 = %.1f, Dec 2019 = %.1f",
              nrow(unr), sum(is.na(unr$UNRATE)), sum(in_win), T_origin,
              unrate[T_origin], unrate[720]))
})


# ---- 2. the track builders roll the information set, not the parameters -----
run("Check 2", {
# upto() keeps the monthly frequency where `[` drops it; locf is y_{t-1};
# avg_k is the mean of the 3 previous actuals; meanf is the expanding mean; and
# an ARIMA one-step forecast of an early date does not change when the series
# is extended (a forecast of y_t uses only data before t).
fit_a <- Arima(train_un, order = c(1, 1, 0))
fit_b <- Arima(train_un, order = c(0, 1, 1))
fits_ab <- list(fit_a, fit_b, fit_a)
F_w_short <- tracks_on(unrate, fits_ab, w_dates)            # series extended to T + 12
os_long   <- as.numeric(fitted(Arima(upto(unrate, T_origin + 24), model = fit_a)))[w_dates]
F_h2 <- tracks_on(unrate, fits_ab, h_dates)
gap_refilter <- max(abs(F_w_short[, "arima_1"] - os_long))
tracks_ok <- frequency(train_un) == 12 && frequency(unrate[1:T_origin]) == 1 &&
  isTRUE(all.equal(F_h2[, "locf"], y_num[h_dates - 1])) &&
  isTRUE(all.equal(F_h2[, "avg_k"], sapply(h_dates, function(t) mean(y_num[(t - 3):(t - 1)])))) &&
  isTRUE(all.equal(F_h2[, "meanf"], sapply(h_dates, function(t) mean(y_num[1:(t - 1)])))) &&
  gap_refilter < 1e-8
check("upto() keeps frequency 12 (brackets give 1); locf = y_{t-1}, avg_k = 3-month mean, meanf = expanding mean; extending the series leaves earlier one-step forecasts unchanged",
      tracks_ok,
      sprintf("refilter gap = %.1e; meanf on the first holdout date = %.3f", gap_refilter, F_h2[1, "meanf"]))
})


# ---- 3. the relative metrics are the course's definitions --------------------
run("Check 3", {
# theil_u2 = RMSE(model)/RMSE(benchmark) on the SAME dates (and 1 for the
# benchmark itself); mase = holdout MAE / training MAE of the lag-m naive;
# both stop rather than divide by zero; theil_u2 ignores ts date alignment.
set.seed(7)
tr  <- cumsum(rnorm(60)); act <- tr[60] + cumsum(rnorm(12))
fc  <- act + rnorm(12, sd = 0.5); bm <- c(tr[60], act[-12])        # bm is locf
u2_hand  <- sqrt(mean((act - fc)^2)) / sqrt(mean((act - bm)^2))
m1_hand  <- mean(abs(act - fc)) / mean(abs(diff(tr)))
m12_hand <- mean(abs(act - fc)) / mean(abs(tr[13:60] - tr[1:48]))
u2_ts <- theil_u2(ts(act, start = 1), ts(fc, start = 5), ts(bm, start = 9))
metrics_ok <- abs(theil_u2(act, fc, bm) - u2_hand) < 1e-12 &&
  theil_u2(act, bm, bm) == 1 &&
  abs(mase(act, fc, tr) - m1_hand) < 1e-12 &&
  abs(mase(act, fc, tr, m = 12) - m12_hand) < 1e-12 &&
  abs(u2_ts - u2_hand) < 1e-12 &&
  stops(theil_u2(act, fc, act)) && stops(mase(act, fc, rep(3, 60)))
check("theil_u2() and mase() match their formulas (m = 1 and m = 12), ignore ts dates, and stop on a zero denominator",
      metrics_ok,
      sprintf("U2 = %.4f, MASE = %.4f, seasonal MASE = %.4f", u2_hand, m1_hand, m12_hand))
})


# ---- 4. at h = 1, Diebold-Mariano is a t-test on d_t -----------------------
run("Check 4", {
# With h = 1, dm.test() uses only the lag-0 variance of d_t, so after the
# small-sample correction its statistic is the one-sample t statistic of d_t
# and its p-value comes from t_{N-1}. That is also why h = 1 ASSUMES d_t is
# serially uncorrelated rather than allowing for it.
set.seed(6376)
e1 <- rnorm(12); e2 <- rnorm(12, sd = 1.3)
dmt <- dm.test(e1, e2, h = 1, power = 2)
tt  <- t.test(e1^2 - e2^2)
p_t <- 2 * pt(-abs(unname(tt$statistic)), df = 11)
check("dm.test(h = 1, power = 2) equals the one-sample t-test on d_t = e1^2 - e2^2, p-value from t with N - 1 = 11 df",
      abs(unname(dmt$statistic) - unname(tt$statistic)) < 1e-10 &&
        abs(dmt$p.value - p_t) < 1e-10,
      sprintf("DM = %.4f, t = %.4f, p = %.4f", unname(dmt$statistic), unname(tt$statistic), dmt$p.value))
})


# ---- 5. the two-forecast portfolio algebra ----------------------------------
run("Check 5", {
# w* = (V2 - C) / (V1 + V2 - 2C) minimizes the combined error variance; with
# zero covariance it is the inverse-variance weight; equal variances and zero
# covariance give w* = 0.5 and half the variance; at rho_{1,2} = sqrt(V1/V2)
# the optimum reaches w* = 1 (no gain over forecast 1 alone).
cvar <- function(w, v1, v2, rho) {
  cv <- rho * sqrt(v1 * v2); w^2 * v1 + (1 - w)^2 * v2 + 2 * w * (1 - w) * cv
}
wstar <- function(v1, v2, rho) {
  cv <- rho * sqrt(v1 * v2); (v2 - cv) / (v1 + v2 - 2 * cv)
}
cases <- rbind(c(1, 1.5, -0.5), c(1, 1.5, 0), c(1, 1.5, 0.5), c(1, 3, 0.2), c(2, 1, 0.3))
gaps <- apply(cases, 1, function(cc) {
  num <- optimize(cvar, c(-5, 5), v1 = cc[1], v2 = cc[2], rho = cc[3], tol = 1e-12)$minimum
  abs(num - wstar(cc[1], cc[2], cc[3]))
})
inv_ok   <- abs(wstar(1, 1.5, 0) - (1 / 1) / (1 / 1 + 1 / 1.5)) < 1e-12
half_ok  <- wstar(1, 1, 0) == 0.5 && abs(cvar(0.5, 1, 1, 0) - 0.5) < 1e-12
thresh   <- sqrt(1 / 1.5)
thresh_ok <- abs(wstar(1, 1.5, thresh) - 1) < 1e-12
check("Two-forecast w* minimizes Var(e_c) (5 cases); zero covariance gives inverse-variance weights; equal variances halve; w* = 1 at rho_{1,2} = sqrt(V1/V2)",
      max(gaps) < 1e-5 && inv_ok && half_ok && thresh_ok,
      sprintf("max |numeric - formula| = %.1e; threshold rho_{1,2} = %.3f", max(gaps), thresh))
})


# ---- 6. the four combination methods keep their contracts -------------------
run("Check 6", {
# On a fixed pool: simple average = 1/M; inverse-MSE weights are positive, sum
# to one and rank inversely to MSE; CLS weights are non-negative, sum to one,
# and fit the window at least as well as SA and inverse-MSE (both feasible for
# its constraints); GR fits the window best of all, equals lm(); an exactly
# duplicated track gets GR weight 0 with a warning and makes CLS stop.
set.seed(6378)
yy <- 5 + cumsum(rnorm(12, sd = 0.3))
FF <- cbind(a = yy + rnorm(12, sd = 0.2), b = yy + rnorm(12, sd = 0.5),
            c = yy + 0.4 + rnorm(12, sd = 0.3), d = rep(mean(yy) - 1, 12) + rnorm(12, sd = 0.05))
sse <- function(w) sum((yy - (w$intercept + FF %*% w$weights))^2)
sa <- comb_simple(yy, FF); im <- comb_inv_mse(yy, FF)
cl <- comb_cls(yy, FF);    gr <- comb_gr(yy, FF)
mse_cols <- colMeans((yy - FF)^2)
FF_dup <- cbind(FF, a2 = FF[, "a"])
gr_dup_warned <- FALSE
gr_dup <- withCallingHandlers(comb_gr(yy, FF_dup),
                              warning = function(w) { gr_dup_warned <<- TRUE; invokeRestart("muffleWarning") })
comb_ok <- all(sa$weights == 1 / 4) && sa$intercept == 0 &&
  all(im$weights > 0) && abs(sum(im$weights) - 1) < 1e-12 &&
  identical(order(im$weights), order(mse_cols, decreasing = TRUE)) &&
  all(cl$weights >= 0) && abs(sum(cl$weights) - 1) < 1e-12 && cl$intercept == 0 &&
  sse(cl) <= min(sse(sa), sse(im)) + 1e-10 &&
  sse(gr) <= sse(cl) + 1e-10 &&
  isTRUE(all.equal(unname(c(gr$intercept, gr$weights)), unname(coef(lm(yy ~ FF))))) &&
  gr_dup_warned && any(gr_dup$weights[c("a", "a2")] == 0) &&
  stops(comb_cls(yy, FF_dup))
check("comb_*: SA = 1/M; IMSE positive, sums to 1, ranks by inverse MSE; CLS on the simplex and beats SA/IMSE in-window; GR = lm(), best in-window; duplicates: GR weight 0 + warning, CLS stops",
      comb_ok,
      sprintf("in-window SSE: SA %.3f, IMSE %.3f, CLS %.3f, GR %.3f", sse(sa), sse(im), sse(cl), sse(gr)))
})


# ---- 7. the UNRATE workflow is pinned ---------------------------------------
run("Check 7", {
# Section 10 of the lab, recomputed from the canonical helpers: arima_1 is the
# Module 5/6 SARIMA, arima_2 ARIMA(1,1,0), arima_3 auto.arima()'s pick on train,
# which must be ARIMA(1,1,3)(2,0,2)[12]. DM arima_1 vs locf on 2019:
# p = 0.902. The simple average's holdout RMSE is 0.416; inverse-MSE gives meanf
# about 0.001; GR's intercept is about -141; IMSE and CLS reject against the
# simple average (p about 2e-6), GR does not.
fit1 <- Arima(train_un, order = c(1, 1, 2), seasonal = list(order = c(1, 0, 1), period = 12))
fit2 <- Arima(train_un, order = c(1, 1, 0))
fit3 <- auto.arima(train_un)
pick <- as.character(fit3)
fits_un <- list(fit1, fit2, fit3)
F_w <- tracks_on(unrate, fits_un, w_dates); F_h <- tracks_on(unrate, fits_un, h_dates)
y_w <- y_num[w_dates]; y_h <- y_num[h_dates]
ws <- list(SA = comb_simple(y_w, F_w), IMSE = comb_inv_mse(y_w, F_w),
           CLS = comb_cls(y_w, F_w),   GR = comb_gr(y_w, F_w))
comb_h <- sapply(ws, function(w) as.numeric(w$intercept + F_h %*% w$weights))
p_dm <- function(e1, e2) unname(dm.test(e1, e2, h = 1, power = 2)$p.value)
p_a1_locf <- p_dm(y_h - F_h[, "arima_1"], y_h - F_h[, "locf"])
p_comb <- sapply(c("IMSE", "CLS", "GR"), function(m) p_dm(y_h - comb_h[, m], y_h - comb_h[, "SA"]))
rmse_sa <- rmse(y_h, comb_h[, "SA"])
check("UNRATE 2019: auto.arima() picks ARIMA(1,1,3)(2,0,2)[12]; DM arima_1 vs locf p = 0.902; SA holdout RMSE = 0.416; IMSE meanf weight < 0.01; GR intercept = -141; IMSE, CLS reject vs SA, GR does not",
      identical(pick, "ARIMA(1,1,3)(2,0,2)[12]") && abs(p_a1_locf - 0.902) < 0.005 && abs(rmse_sa - 0.416) < 0.001 &&
        ws$IMSE$weights[["meanf"]] < 0.01 && abs(ws$GR$intercept + 141.45) < 0.5 &&
        all(p_comb[c("IMSE", "CLS")] < 1e-4) && p_comb[["GR"]] > 0.05,
      sprintf("pick = %s; p = %.3f; SA RMSE = %.3f; IMSE meanf = %.4f; GR w0 = %.2f; p vs SA: IMSE %.1e, CLS %.1e, GR %.3f",
              pick, p_a1_locf, rmse_sa, ws$IMSE$weights[["meanf"]], ws$GR$intercept,
              p_comb[["IMSE"]], p_comb[["CLS"]], p_comb[["GR"]]))
})


# ---- verdict ----------------------------------------------------------------
n_pass <- sum(results)
n_all <- length(results)
cat(sprintf("---------------\n%d/%d checks passed.\n", n_pass, n_all))

# Inside a Quarto render, print failures without terminating knitr mid-document.
if (n_pass < n_all && !isTRUE(getOption("knitr.in.progress"))) {
  quit(status = 1, save = "no")
}
