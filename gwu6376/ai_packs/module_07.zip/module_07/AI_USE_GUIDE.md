# Using AI Well in This Course

**Econ 6376 — Module 7**

This is written for you, not for the assistant. It's about getting real value out
of an AI tutor instead of the appearance of value.

---

## The short version

AI is extraordinarily good at the things that used to waste your time in a course
like this — debugging R, explaining notation, generating variations of a
simulation, answering the question you were embarrassed to ask in class. Use it
for all of that, freely.

It is much less good at the thing this course actually grades: *judgment about
ambiguous evidence*. Whether a twelve-month gap between two forecasts means
anything, or whether a forecaster belongs in your pool at all, is not a fact
to be retrieved. It's a call you make and
defend.

Use AI to build the judgment. Don't use it to skip the judgment.

---

## Productive uses

- **Debugging.** "This chunk errors, here's the message." Get the fix, move on. Don't romanticize struggling with a missing comma.
- **Explaining notation.** "Why is the forecast written $\tilde y$ now, and why do the estimated weights get hats?" Exactly the kind of thing a textbook assumes you'll absorb by osmosis.
- **Generating variations.** "Show me Stage 1 again with a different seed." Cheap, fast, and the fastest route to intuition about how much one realization can and can't tell you.
- **Being challenged.** "I think the simple average always wins. Push back on me." Asking to be argued with is the single highest-value prompt in this course.
- **Rubber-ducking.** Explain why constrained least squares can't remove a bias every track shares, and let the AI find the hole. You'll often find it yourself mid-sentence.
- **Chasing tangents.** "What if I re-estimated the combination weights every month instead of once?" Turn it into a loop and find out. Your tutor is instructed to help you do this rather than steer you back to the syllabus.
- **Translating textbooks.** Paste a confusing passage from Enders or Hyndman and ask it to reconcile the notation with the course's. See `TEXTBOOK_MAP.md`.

## Unproductive uses

- **Asking for the interpretation before you've formed one.** "Which combination is best?" gets you a fluent paragraph you'll forget. Name your pick and your reason first, then ask it to critique yours.
- **Accepting numbers you didn't check.** LLMs produce confident, plausible, wrong arithmetic — weights, $p$-values, "the RMSE is...". Run it.
- **Letting it pick which comparison to test after seeing the scores.** Testing the holdout winner on the same holdout is choosing the hypothesis after seeing the data — whoever does the choosing.
- **Letting it write your log.** See below.
- **Using it as a search engine for the answer to a graded question.** Permitted, but see the section on assessed work — it doesn't work as well as it feels like it should.
- **Never disagreeing with it.** If you've gone ten sessions without once finding the AI wrong, you aren't checking. It is wrong regularly on this material.

---

## Verification habits

The pack is built so you never have to take anyone's word for anything — mine, or
your tutor's.

**Test claims in R.** Almost every claim in Module 7 is checkable in five lines.
"DM is just a $t$-test" — run `dm.test()` and `t.test()` on the same $d_t$ and
compare. "Granger-Ramanathan fits best" — score it on the weights window *and*
the holdout. "MASE below 1 means a win" — compute `locf`'s own MASE and see. If your tutor asserts something about this
material and you can't immediately see how to test it, ask it to write the test.

**Use `R/checks.R` as a referee.** It holds seven assertions about things this
module claims are true, in readable R. Run `Rscript R/checks.R`
any time. If something you were told contradicts a passing check, the check wins.

**Watch for these specific failure modes.** In my experience they're the common
ones on this material:

- Reading MASE below 1 as "beat the naive". That is $U_2$'s question, not MASE's.
- Feeding `residuals(fit)` to `dm.test()`. DM needs out-of-sample forecast errors.
- Re-fitting the ARIMA on the weights window before forecasting the holdout. Parameters are estimated once; the information set rolls.
- Subsetting a `ts` with square brackets. `y[1:T]` drops the frequency; use `window()`.
- Calling `avg_k` a moving average. It is a $k$-period average forecast.
- Scoring a combination on the window its weights were fit on. That is in-sample, and Granger-Ramanathan always wins it.
- Treating one calm 2019 holdout as a verdict on the methods. It is one window; the Monte Carlo is the distribution.

**A good habit:** when the AI tells you something surprising, ask "how would I
check that in R?" before asking anything else. If it can't propose a check, be
suspicious of the claim.

---

## Graded work

**AI assistance is permitted on take-home graded work in this course** —
problem sets and the take-home midterm — **with disclosure.** The final is an
in-person, closed-book, paper-and-pencil exam, so no devices or AI may be used
during it. You may use this pack to prepare for the final.

Disclosure is a brief, free-form statement of how you used it. No form, no
template, no penalty. It just has to be honest and specific enough to be
meaningful. Two sentences is plenty:

> *I used Claude to debug the date alignment of my forecast tracks in Question 1
> and to explain a `solve.QP()` error message in Question 2. The reading of the
> results in Question 3 is my own, though I asked Claude to argue for the
> opposite conclusion before I settled on mine.*

That's a complete disclosure. Notice it says what was done *where* — "I used AI"
alone doesn't tell me anything.

Your `LEARNING_LOG.md` is **not** the disclosure vehicle. The log is private and
I never see it. Disclosure goes with the submitted work.

### Why pasting through answers won't carry you

I want to be straightforward about this rather than issue a warning.

The assessments in this course are built to be AI-resilient, and they draw
**only** on the Core tier of the module notes. They ask you to interpret
ambiguous output, reconcile two results that disagree, explain why a method
failed, and defend a judgment call. Those questions don't have retrievable
answers — the evidence is genuinely ambiguous, which is the point, and what gets
graded is the quality of your reasoning about the ambiguity.

An answer you didn't build, you can't defend. That shows up immediately in the
follow-up parts of a question, and it shows up badly on a take-home where you had
plenty of time.

So the policy isn't a trap. Using AI heavily and understanding the material are
completely compatible — that's the intended outcome, and it's how you'll work
professionally. Using AI heavily *instead of* understanding the material is a
strategy that fails at the assessment, and more importantly fails in the job
where nobody tells you which model to fit.

---

## About the contract

`AI_TUTOR_CONTRACT.md` asks your tutor to do things like request a prediction
before running a simulation, and to ask for your own words before writing the
last two fields of your learning log.

The prediction ask pauses for one turn — it will hand you two or three options
and wait once. Answer it, or say "just run it" and it runs immediately and drops
the question. It will not ask you twice, and you can tell it to skip predictions
entirely for the whole session. It's your session.

I'd just say plainly: the contract is there for your benefit, not as a rule
you're being held to. The prediction step exists because being surprised is how
things stick, and skipping it feels efficient in the moment and costs you in
November. Overriding it is a choice you're making about your own learning, and
you're an adult — I only want you making the choice knowingly rather than by
accident.

That's the last I'll say about it.

---

## Intellectual ownership

The point of this course is that you become someone who can take an unfamiliar
series, work out what it is, and defend a modeling decision to a skeptical room.

That capability is built by making predictions, being wrong, and figuring out
why. It is not transferable from a model, and it is not something you can borrow
under deadline. An AI can accelerate every step of building it — and it can also
let you produce work that looks like the finished product without any of the
building having happened.

Both paths are available to you here, and honestly, the second one is easier.
The difference shows up when you're the one in the room who has to say what the
data means.
