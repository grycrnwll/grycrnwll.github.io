# Textbook Map — Module 7

Where Module 7's ideas live in the books you are most likely to read alongside
this course, and how to translate the notation when you get there.

**This file contains pointers and translations only — no textbook text.** If you
want to know what Enders *says*, read Enders. What this file does is get you to
the right pages and stop the notation from tripping you.

**How to read the pointers.** Section and equation numbers are the ones this
course's own notes use (this module's "Connection to Enders and Other Texts"
section, and the Module 4 and Module 6 notes for page ranges in the same part
of Enders), for the editions listed below. Where the notes only name a chapter
or a section, the pointer stays at that level. Nothing is guessed at the page
level — if your copy disagrees, trust your copy and tell me. Cells marked
**(verify)** are locations or symbols the course's notes nowhere pin down;
check your copy before relying on one.

**Editions assumed:** Enders, *Applied Econometric Time Series*, 4th ed.
Hamilton, *Time Series Analysis* (1994). Hyndman & Athanasopoulos, *Forecasting:
Principles and Practice*, 3rd ed. (fpp3), free online at <https://otexts.com/fpp3/>.
Two further sources the Module 7 notes lean on: Hyndman's 2014 *Forecasting:
Principles and Practice* workshop notes, and Wang, Hyndman, Li and Kang (2023),
"Forecast combinations: an over 50-year review", *International Journal of
Forecasting*.

---

## Part A — Concept pointers

### The PS3 design and the three evaluation schemes (lab sections 2 and 4)

| Book | Where |
|---|---|
| Hyndman (2014 workshop notes) | §5.1 ("Cross-validation"): the rolling forecasting origin the lab's scheme diagram follows. |
| fpp3 | Ch. 5 (evaluating forecast accuracy), time-series cross-validation **(verify section)**. |
| Enders | Ch. 2, pp. 82–87, out-of-sample forecast evaluation (the Module 4 notes' pointer). |
| Hamilton | Not a source for applied evaluation designs **(verify)**. |

The six-track pool, the weights window and the fixed-parameter one-step design
are the course's own.

### Relative metrics: Theil's $U_2$, MASE, and `accuracy()` (lab section 5)

| Book | Where |
|---|---|
| Hyndman (2014 workshop notes) | §2.6 ("Evaluating forecast accuracy") defines MASE. |
| fpp3 | Ch. 5, the accuracy-measures material including MASE (the Module 6 notes' pointer); chapter level. |
| Original | Hyndman and Koehler (2006) for MASE. |
| Enders, Hamilton | No location for $U_2$ or MASE pinned by the course notes **(verify)**. |

### The Diebold-Mariano test (lab section 6)

| Book | Where |
|---|---|
| Enders | Ch. 2, §9 ("Properties of Forecasts"), eqs. (2.61)–(2.62): the loss differential, the truncated long-run variance, the Harvey-Leybourne-Newbold version with a $t_{H-1}$ reference, the regress-on-a-constant shortcut, and the Clark-McCracken nested-model caveat with the Clark-West adjustment. The Module 6 notes put §9 at pp. 79–83; the exact page of eq. (2.61) is **(verify)**. |
| Hamilton | §10.5 ("The Sample Mean of a Vector Process"): the long-run variance of a sample mean and the Newey-West estimator, eq. (10.5.15). The rigorous version of why $\hat\sigma_{\bar d}$ must allow for serial correlation (a Technical Note in the notes). |
| fpp3 | No DM location pinned by the course notes **(verify)**. |
| Original | Harvey, Leybourne and Newbold (1997, *IJF*) for the small-sample correction `dm.test()` uses; Clark and McCracken (2001); Clark and West (2007); Newey and West (1987); Mikusheva, MIT 14.384 Lecture 3, for the kernel estimator. |

### Why combine: the two-forecast algebra (lab section 7)

| Book | Where |
|---|---|
| Enders | Ch. 2, §13, eqs. (2.71)–(2.73): the two-forecast combined error variance and the optimal weight; the zero-covariance form is stated in the text after (2.73), unnumbered. Page numbers for §13 are **(verify)**. |
| Wang et al. (2023) | §2.2, eq. (1): optimal weights for $M$ forecasts. |
| Hamilton | Not a source for forecast combination **(verify)**. |
| Original | Bates and Granger (1969). |

### The four combination methods (lab section 8)

| Book | Where |
|---|---|
| Enders | Ch. 2, §13: eq. (2.74) inverse-variance weights for many forecasts; eq. (2.75) the Granger-Ramanathan regression; eq. (2.76) and the spread example, with the drop-the-most-negative-weight fix and SBC weights. |
| Wang et al. (2023) | §2.2, eqs. (1)–(4): the optimal weights and the three Granger-Ramanathan regressions (the lab's Method 3 is their eq. 4). |
| fpp3 | Forecast combinations: a section in a late chapter on practical forecasting issues **(verify chapter and section)**. |
| Original | Granger and Ramanathan (1984); Newbold and Granger (1974) for $M > 2$; Diebold and Pauly (1990) and Stock and Watson (2004) on shrinking toward $1/M$; Hsiao and Wan (2014) for eigenvector weights. |

Constrained least squares solved with `quadprog::solve.QP()` is the course's
own build; no textbook pointer is given for it.

### The assumption-break and the forecast combination puzzle (lab section 9)

| Book | Where |
|---|---|
| Wang et al. (2023) | §2.6 for the combination puzzle; §2.5 on which forecasts to combine (diversity and redundant pools). |
| Enders | Ch. 2, §13, the spread example: an illustration of the near-equal-weights case (seven nearly identical error variances), one forecast date only. |
| Original | Stock and Watson (2004) named the puzzle; Timmermann (2006), Smith and Wallis (2009), and Claeskens, Magnus, Vasnev and Wang (2016) for the estimation-error explanation; Elliott (2011) for bounds on the gain over equal weights (reviewed in Wang et al. 2023, §2.6). |

The Monte Carlo itself (the course DGP, Stages 1–3, the $T_w$ sweep) is the
course's own.

### What is not in any textbook here

The UNRATE pool, the 2018 weights window and 2019 holdout, the broken-`meanf`
reading, and the DGP built so that one track is genuinely better are the
course's own.

---

## Part B — Notation translation

Same mathematics, different alphabets. This is where most cross-referencing
confusion comes from.

| Concept | This course | Enders | Hamilton / fpp3 / Wang et al. |
|---|---|---|---|
| A forecast | $\tilde y^{(m)}_{t\mid t-1}$ (tilde from Module 7; Modules 5–6 wrote $\hat y$ for the same object) | $f_{it}$, forecaster $i$ | fpp3 $\hat y_{T+h\mid T}$; Hamilton $\hat Y_{t+h\mid t}$ **(verify)**: a hat where the course now writes a tilde |
| Number of forecasts | $M$, indexed by $m$ | $n$, indexed by $i$ | Wang et al. write $N$ |
| Combination weights | $w_0, w_1, \ldots, w_M$; estimated $\hat w$, optimal $w^*$ | $\alpha_0, \alpha_1, \ldots, \alpha_n$ in the Granger-Ramanathan regression ($\alpha$ is the master-equation intercept in this course) | Wang et al.: symbol **(verify)** |
| Forecast error | $e_{m,t} = y_t - \tilde y^{(m)}_{t\mid t-1}$, throughout | $e_{it} = y_t - f_{it}$ in the derivation, then $f_{it} - y_t$ in the spread example (the sign does not change variances or weights) | fpp3 $e_{T+h}$ **(verify)** |
| Evaluation-window size | $N$ (never $h$) | $H$ | fpp3: the test-set length, no fixed symbol |
| DM reference distribution | $t_{N-1}$ (inside `dm.test()`) | $t_{H-1}$ | — |
| Loss differential, DM statistic | $d_t = g(e_{1,t}) - g(e_{2,t})$; $\text{DM} = \bar d/\hat\sigma_{\bar d}$ | Symbols **(verify)** | — |
| Error variances and covariance | $\text{Var}(e_{1,t})$, $\text{Cov}(e_{1,t}, e_{2,t})$ ($\sigma^2$ is reserved for the innovation variance) | Var and Cov, as the course | — |
| Error correlation | $\rho_{1,2}$, always with the comma | Symbol **(verify)** | — |
| Long-run variance of $d_t$ | $\hat\sigma_{\bar d}$ (Technical Note) | Truncated sum at $q$ lags, eq. (2.62) | Hamilton: eq. (10.5.15), symbol **(verify)** |
| Seasonal period | $s$ (the helper's `m` argument is the same lag) | — | fpp3 $m$ |
| Information criterion | BIC | SBC | — |
| AR coefficient, stationarity roots | $\phi_j$; roots of $\Phi(L)$ outside | $a_i$; characteristic roots inside | as in Modules 3–6 |
| HLN citation | Harvey, Leybourne & Newbold (1997) | Cites a different HLN paper (1998) in the DM discussion | — |

### The four that actually cause problems

1. **Enders' $\alpha$'s are weights here.** In the Granger-Ramanathan regression
   Enders writes $\alpha_0, \ldots, \alpha_n$; in this course those are $w_0,
   \ldots, w_M$, because $\alpha$ is the intercept of the master equation.
2. **A hat is not a forecast any more.** fpp3 and Hamilton write forecasts with
   a hat (symbols as carried over from the Module 6 map, **(verify)** in your
   edition); from Module 7 the course writes $\tilde y$ and keeps the hat for
   fitted values and estimates, such as $\hat w_m$.
3. **$N$ and $H$ and $h$.** The course's $N$ is the number of evaluation dates,
   Enders' $H$; $h$ is always the horizon, which is 1 throughout this module.
   Wang et al.'s $N$ is a different thing again: the number of forecasts, the
   course's $M$.
4. **Hyndman's $m$ is this course's $s$.** And `mase(..., m = 12)` uses the same
   letter for the seasonal lag, while in the math $m$ is the forecaster index.
