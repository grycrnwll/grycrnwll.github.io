# data/ — The data behind the Module 7 lab

Everything the lab needs is in this folder, so it runs with no FRED key and no
internet connection. That holds for every pack in this course: nothing should
need a network call to work.

If you want to see how the data are actually pulled, `R/fetch_fred.R` shows the
live `fredr` call — but nothing requires you to run it.

| File | What it is | Coverage |
|---|---|---|
| `UNRATE.csv` | U.S. civilian unemployment rate, monthly, **seasonally adjusted**, percent (FRED `UNRATE`; Bureau of Labor Statistics, Current Population Survey). The series you have used since Module 2. The lab uses January 1960 to December 2019: training through December 2017, the weights window 2018, the holdout 2019. | 1948-01 to 2026-04, 940 rows, one blank month |

The columns follow the FRED CSV export:

```text
observation_date,UNRATE
1948-01-01,3.4
```

The simulated series in the lab are not stored here: they are generated at run
time from fixed seeds (6376–6379) by `R/sarima_simulator.R`, so every run of the
lab draws the same numbers.

## The one gap you should know about

`UNRATE.csv` has exactly one blank: **October 2025**, a federal data-release
gap. The lab uses January 1960 through December 2019, the same window Modules 4
to 6 used, so the gap never touches it. Do not interpolate or silently "clean"
the file; check 1 in `R/checks.R` looks for that blank on purpose.

The window stops at 2019 because April 2020's jump (from 4.4 to 14.8) dominates
every autocorrelation it touches, and the course's models have no outlier or
break treatment. A 2019 holdout is also a *calm* one, which is part of the
lab's honest reading: on a calm stretch every reasonable forecast, the naive
included, has small errors. Moving the window past 2019 is a fine experiment,
as long as you label it a sensitivity analysis and know what is coming.

## A note on vintages

Published seasonally adjusted unemployment rates are revised when the seasonal
factors are re-estimated, typically each January for the most recent years. The
cached file is one vintage, so a fresh download may differ slightly. With
holdout errors measured in hundredths of a point, even small revisions could
move the lab's combination weights and $p$-values. That is why the lab works from this cached copy, and why check 7 pins
section 10's numbers.

## Refreshing the data

Re-run the `fredr` pull with a valid `FRED_KEY` in your environment
(`R/fetch_fred.R`), write the result here, and update the coverage column above.
If you refresh anything, the lab's printed numbers and `R/checks.R` will notice;
update them together rather than loosening a check.

## The key rule

**Never commit an API key, or any file containing one, to this folder.** Keys
live in your environment — in `.Renviron` or via `Sys.setenv()` — and are read
with `Sys.getenv("FRED_KEY")`. They never appear in a course file. This pack is
meant to be shareable.

Get a free FRED key at <https://fred.stlouisfed.org/docs/api/api_key.html>.
