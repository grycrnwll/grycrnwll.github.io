# What the Checks Check

`R/checks.R` holds seven assertions about things Module 7 claims are true. Run it
from the pack root at any time:

```
Rscript R/checks.R
```

Each check prints one `PASS` or `FAIL` line with the numbers it computed. Any
failure makes the script exit with a nonzero status, so it works in a script as
well as by hand. The last chunk of the lab runs it too — inside a Quarto render
it prints its results without killing the render, and in a private environment,
so the functions and objects you built in the lab are left untouched. A line
reading `FAIL Check N could not run [message]` means that check hit an R error
before it could compare anything; the message in brackets is the error, and the
other checks still run.

**This is not an answer key.** The checks confirm that the *code and data* behave
the way the module says they do. They cannot tell you whether your reading of a
combination table is any good, and they don't try. They exist so that when you
and an AI tutor disagree about a fact, there's a referee neither of you controls.

The script uses the lab's own packages, `forecast` and `quadprog`, and nothing
else. It runs the **canonical** helpers in `R/` (`R/track_utils.R`,
`R/combination_utils.R`, `R/forecast_utils.R`), not the inline versions you
build in the lab, so it also confirms that the copies you will source later
behave the way the lab says. If a check confuses you, read it — each one is a
short block, and the whole script takes a few seconds.

---

## Check 1 — the data are the data

**Asserts:** `UNRATE.csv` has its two columns and its single known blank at
2025-10-01; January 1960 to December 2019 is 720 months with no gaps; so
$T = 720 - 24 = 696$ and the training sample ends in December 2017.

**Why:** every UNRATE number in the lab descends from this file and this
window. The PS3 split is defined by counting back 24 months from the end, so a
window that gained or lost a month would silently move every date.

**A failure usually means:** the data file was refreshed or edited, or the blank
was "cleaned". Refreshing is fine; update `data/README.md` and the lab's numbers
with it rather than loosening the check.

## Check 2 — the track builders roll the information set, not the parameters

**Asserts:** `upto()` keeps the monthly frequency where `y[1:T]` drops it to 1;
on the 2019 holdout, `locf` equals $y_{t-1}$, `avg_k` equals the mean of the
three previous actuals and `meanf` the mean of everything before $t$; and an
ARIMA one-step forecast of a 2018 date is identical whether the series is
extended to $T + 12$ or to $T + 24$.

**Why:** these are the alignment and design facts the whole module rests on. If
`locf` is off by one date, every metric, test and weight downstream is wrong.
The last part is the PS3 design in one line: a forecast of $y_t$ uses only data
before $t$, so feeding the filter more data later cannot change it.

**A failure usually means:** an edit to `kavg()` shifted the window by one (a
common one: `x[(t - k + 1):t]`, which includes $y_t$ itself), or someone
subset with square brackets.

## Check 3 — the relative metrics are the course's definitions

**Asserts:** on a fixed random-walk example, `theil_u2()` equals
$\text{RMSE}(\text{model})/\text{RMSE}(\text{benchmark})$ on the same dates and
returns exactly 1 for the benchmark scored against itself; `mase()` equals the
holdout MAE divided by the training MAE of the lag-1 naive (and of the lag-12
naive with `m = 12`); `theil_u2()` gives the same answer on `ts` objects with
different start dates (it ignores date alignment); and both functions stop
rather than divide by zero.

**Why:** section 5's whole argument is that $U_2$ and MASE answer different
questions. That is only true if each one is computed the way its formula says,
with the naive's holdout errors in $U_2$ and its training errors in MASE.

**A failure usually means:** an edit to `R/forecast_utils.R`. The usual
casualty is MASE's denominator being computed on the holdout instead of on
training, which turns it into something close to $U_2$.

## Check 4 — at `h = 1`, Diebold-Mariano is a $t$-test on $d_t$

**Asserts:** for twelve fixed pairs of errors, `dm.test(e1, e2, h = 1, power =
2)` returns the same statistic as `t.test()` on $d_t = e_{1,t}^2 - e_{2,t}^2$,
and its $p$-value is the two-sided $t_{11}$ tail.

**Why:** this is the lab's "DM really is a $t$-test" claim, and it is also why
`h = 1` *assumes* that $d_t$ is serially uncorrelated: the variance it uses is
the plain lag-0 variance of $d_t$, with no autocovariance terms.

**A failure usually means:** a different `forecast` version changed
`dm.test()`'s small-sample correction or its reference distribution. Check
`packageVersion("forecast")` and the function's help page.

## Check 5 — the two-forecast portfolio algebra

**Asserts:** for five combinations of error variances and $\rho_{1,2}$, the
closed-form $w^* = \frac{\text{Var}(e_{2,t}) - \text{Cov}}{\text{Var}(e_{1,t}) +
\text{Var}(e_{2,t}) - 2\text{Cov}}$ is where a numerical minimizer of
$\text{Var}(e_{c,t})$ lands; with zero covariance it equals the
inverse-variance weight; with equal variances and zero covariance it is 0.5
and halves the variance; and at $\rho_{1,2} = \sqrt{\text{Var}(e_{1,t})/
\text{Var}(e_{2,t})}$ it reaches exactly 1.

**Why:** section 7's diversification argument and its "correlation eats the
gain" threshold both come from this one formula.

**A failure usually means:** an edit to the formula (the usual slip is a sign on
the covariance term, or forgetting the factor of 2 in the denominator).

## Check 6 — the four combination methods keep their contracts

**Asserts:** on a fixed pool of four forecasts over twelve dates, the simple
average gives $1/M$ with no intercept; inverse-MSE weights are positive, sum to
one and rank inversely to each track's MSE; constrained least-squares weights
are non-negative, sum to one, and fit the window at least as well as the simple
average and inverse-MSE (both are points its optimizer was allowed to choose);
Granger-Ramanathan reproduces `lm()` and fits the window best of all; and with
an exactly duplicated track, `comb_gr()` warns and gives one copy weight 0 while
`comb_cls()` stops and names it.

**Why:** "Granger-Ramanathan fits the weights window best" is the premise of
section 9's assumption-break; "CLS cannot short a forecaster" and "IMSE
penalizes the worst track most" are section 8's descriptions. The duplicate-track
behaviour is the guard rail you will meet if your own pool contains two tracks
that are the same forecast.

**A failure usually means:** an edit to `R/combination_utils.R`, or a
`quadprog` problem (check that `library(quadprog)` loads).

## Check 7 — the UNRATE workflow is pinned

**Asserts:** rebuilding section 10 from the canonical helpers: `auto.arima()`
on the training sample picks ARIMA$(1,1,3)(2,0,2)_{12}$ for `arima_3`; the DM
test of `arima_1` against `locf` on 2019 has $p = 0.902$; the simple average's
holdout RMSE is 0.416; inverse-MSE gives `meanf` a weight below 0.01;
Granger-Ramanathan's intercept is about $-141$; and inverse-MSE and CLS reject
against the simple average while Granger-Ramanathan does not.

**Why:** these are the numbers section 10's honest reading rests on. Recomputing
them through the canonical helpers, rather than the lab's inline builds, means
the two routes have to agree.

**A failure usually means:** the data file changed, a different `forecast`
version moved the ARIMA estimates or changed `auto.arima()`'s search (the
`pick =` value in the output shows which), or a track builder was edited. A failure on
this check alone, with checks 2 and 6 passing, almost always points to the data
or the package version.

---

## If a check fails and you can't work out why

Read the check. It's a few lines of R and it prints the numbers it computed
alongside the target, so the gap between "what we expected" and "what we got" is
right there in the output.

If you're working with an AI tutor, show it the failing line, your R version,
your `forecast` version, *and* the relevant file. "Check 7 fails — SA RMSE is
0.43" plus `packageVersion("forecast")` is a solvable problem; "my checks fail"
is not.
