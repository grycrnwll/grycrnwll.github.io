# =============================================================================
# checks.R — the referee for the Module 5 AI Learning Pack (Econ 6376)
#
# Seven assertions about the numerical claims and shipped evidence in Module 5.
# Run from the pack root:   Rscript R/checks.R
# Each check prints one PASS/FAIL line. Any FAIL exits with a nonzero status.
#
# Base R and stats::arima() only: no forecast, no ggplot2, no seasonal. The lab
# fits with forecast::Arima(); the two agree on these models to the tolerances
# used below. CHECKS.md explains what every check establishes and what a
# failure suggests. This is readable evidence, not an answer key.
# =============================================================================

source("R/diagnostics.R")    # lb_both() works on stats::arima() fits too
source("R/seasonality.R")    # seasonal_dummies()

# ---- tiny test harness ------------------------------------------------------
# A failed assertion does not hide later checks.
results <- logical(0)

check <- function(label, passed, detail = "") {
  passed <- isTRUE(passed)
  results[[length(results) + 1L]] <<- passed
  cat(sprintf("%-4s %s%s\n",
              if (passed) "PASS" else "FAIL",
              label,
              if (nzchar(detail)) paste0("  [", detail, "]") else ""))
  invisible(passed)
}

cat("Module 5 checks\n---------------\n")

# The 1960-01 to 2019-12 window used throughout the lab.
read_window <- function(path, column) {
  raw <- read.csv(path, stringsAsFactors = FALSE)
  raw <- raw[raw$observation_date >= "1960-01-01" &
             raw$observation_date <= "2019-12-01", ]
  ts(raw[[column]], start = c(1960, 1), frequency = 12)
}
unrate      <- read_window("data/UNRATE.csv", "UNRATE")
unratensa   <- read_window("data/UNRATENSA.csv", "UNRATENSA")
d_unrate    <- diff(unrate)
d_unratensa <- diff(unratensa)

sfit <- function(y, order, seasonal = c(0, 0, 0)) {
  stats::arima(y, order = order,
               seasonal = list(order = seasonal, period = 12))
}
rho_at <- function(x, lags) {
  stats::acf(as.numeric(x), lag.max = max(lags), plot = FALSE)$acf[lags + 1]
}


# ---- 1. the Module 4 callback is pinned -------------------------------------
# ARMA(1,2) on diff(UNRATE), Module 4's zero-mean policy: spikes at 12/24/36,
# and a Ljung-Box verdict that passes at h = 10 and fails at h = 24 (fitdf = 3).
fit_l4 <- stats::arima(d_unrate, order = c(1, 0, 2), include.mean = FALSE)
rho_l4 <- rho_at(residuals(fit_l4), c(12, 24, 36))
lb_l4  <- lb_both(fit_l4)
check("Module 4 residuals spike at 12/24/36; Ljung-Box passes h = 10, fails h = 24",
      all(abs(rho_l4 - c(-0.145, -0.125, -0.130)) < 0.002) &&
        lb_l4$fitdf[1] == 3 && lb_l4$p[1] > 0.5 && lb_l4$p[2] < 0.01,
      sprintf("rho = %.4f / %.4f / %.4f; p(h=10) = %.3f, p(h=24) = %.4f",
              rho_l4[1], rho_l4[2], rho_l4[3], lb_l4$p[1], lb_l4$p[2]))


# ---- 2. the Ljung-Box arithmetic --------------------------------------------
# The hand formula Q(h) = T(T+2) sum rho_k^2 / (T - k) equals Box.test(), and
# the reference distribution has h - fitdf degrees of freedom.
e_l4   <- residuals(fit_l4)
T_e    <- length(e_l4)
r24    <- rho_at(e_l4, 1:24)
Q_hand <- T_e * (T_e + 2) * sum(r24^2 / (T_e - 1:24))
bt     <- Box.test(e_l4, lag = 24, type = "Ljung-Box", fitdf = 3)
check("Hand-built Q(24) equals Box.test(), on 24 - fitdf degrees of freedom",
      abs(Q_hand - unname(bt$statistic)) < 1e-8 && unname(bt$parameter) == 21,
      sprintf("hand = %.6f, Box.test = %.6f, df = %d",
              Q_hand, unname(bt$statistic), as.integer(bt$parameter)))


# ---- 3. the seasonal assumption-break ---------------------------------------
# Seasonal AR(1)_12, Phi_1 = 0.7, seed 2005, the lab's hand loop. A
# non-seasonal ARMA(1,1) leaves the seasonal structure behind; the right class
# recovers Phi_1 and cleans the residuals.
set.seed(2005)
n <- 500
eps <- rnorm(n + 12)
y_sar <- numeric(n + 12)
for (t in 13:(n + 12)) y_sar[t] <- 0.7 * y_sar[t - 12] + eps[t]
y_sar <- ts(y_sar[-(1:12)], frequency = 12)

fit_wrong <- stats::arima(y_sar, order = c(1, 0, 1))
p_wrong   <- Box.test(residuals(fit_wrong), lag = 24, type = "Ljung-Box", fitdf = 2)$p.value
fit_right <- sfit(y_sar, c(0, 0, 0), c(1, 0, 0))
Phi_hat   <- unname(coef(fit_right)["sar1"])
p_right   <- Box.test(residuals(fit_right), lag = 24, type = "Ljung-Box", fitdf = 1)$p.value
check("Seasonal DGP: ARMA(1,1) rejected at h = 24; SARIMA recovers Phi_1 and passes",
      p_wrong < 0.001 && abs(Phi_hat - 0.7) < 0.05 && p_right > 0.05,
      sprintf("wrong-class p = %.2g; Phi_1-hat = %.3f, right-class p = %.3f",
              p_wrong, Phi_hat, p_right))


# ---- 4. path 1: seasonal dummies --------------------------------------------
X   <- seasonal_dummies(d_unratensa)
fit_dum <- lm(d_unratensa ~ X)
r2  <- summary(fit_dum)$r.squared
rho_dum12 <- rho_at(residuals(fit_dum), 12)
half  <- factor(time(d_unratensa) >= 1990, labels = c("1960-89", "1990-2019"))
month <- factor(month.abb[cycle(d_unratensa)], levels = month.abb)
# The between-halves evidence is the size of the shifts, not the nominal
# anova() F p-value (that assumes uncorrelated errors, which rho_12 rules out).
m_half <- tapply(d_unratensa, list(month, half), mean)
shift  <- m_half[, "1990-2019"] - m_half[, "1960-89"]
check("Dummies: 11 columns, R^2 near 0.721, residual lag-12 near 0.350, June falls and July rises between halves",
      ncol(X) == 11 && all(rowSums(X) <= 1) &&
        abs(r2 - 0.721) < 0.005 && abs(rho_dum12 - 0.350) < 0.005 &&
        shift[["Jun"]] < -0.3 && shift[["Jul"]] > 0.3,
      sprintf("cols = %d, R^2 = %.4f, rho_12 = %.3f, June shift = %+.2f, July shift = %+.2f",
              ncol(X), r2, rho_dum12, shift[["Jun"]], shift[["Jul"]]))


# ---- 5. the differencing commitment, from both sides -------------------------
# One seasonal difference too few (raw series, D = 0): Phi_1-hat -> +1.
# One too many (published series, D = 1): Theta_1-hat -> -1.
# The path-2 winner (1,1,2)(0,1,1)_12 on the raw series sits in between.
fit_d0  <- sfit(unratensa, c(1, 1, 2), c(1, 0, 1))
fit_air <- sfit(unrate,    c(0, 1, 1), c(0, 1, 1))
fit_win <- sfit(unratensa, c(1, 1, 2), c(0, 1, 1))
Phi_d0   <- unname(coef(fit_d0)["sar1"])
Theta_air <- unname(coef(fit_air)["sma1"])
Theta_win <- unname(coef(fit_win)["sma1"])
lb_win  <- lb_both(fit_win)
check("D too few pins Phi_1 near +1; D too many pins Theta_1 near -1; the winner is interior and clean",
      Phi_d0 > 0.98 && Theta_air < -0.99 && abs(Theta_win) < 0.95 &&
        all(lb_win$p > 0.05),
      sprintf("Phi_1 (D=0, raw) = %.4f; Theta_1 (airline, published) = %.6f; winner Theta_1 = %.3f, p = %.3f / %.3f",
              Phi_d0, Theta_air, Theta_win, lb_win$p[1], lb_win$p[2]))


# ---- 6. the model handed to Module 6 is diagnostic-clean --------------------
fit_full <- sfit(unrate, c(1, 1, 2), c(1, 0, 1))
lb_full  <- lb_both(fit_full)
rho_full12 <- rho_at(residuals(fit_full), 12)
check("ARIMA(1,1,2)(1,0,1)_12 on published UNRATE passes both horizons, lag 12 inside the band",
      lb_full$fitdf[1] == 5 && all(lb_full$p > 0.05) && abs(rho_full12) < 0.073,
      sprintf("fitdf = %d, p = %.3f / %.3f, rho_12 = %.3f",
              lb_full$fitdf[1], lb_full$p[1], lb_full$p[2], rho_full12))


# ---- 7. data and shipped evidence are intact --------------------------------
raw_sa  <- read.csv("data/UNRATE.csv", stringsAsFactors = FALSE)
raw_nsa <- read.csv("data/UNRATENSA.csv", stringsAsFactors = FALSE)
gap_ok <- function(d, col) {
  identical(names(d), c("observation_date", col)) &&
    sum(is.na(d[[col]])) == 1L &&
    identical(d$observation_date[is.na(d[[col]])], "2025-10-01")
}
x13 <- read.csv("data/x13_vs_published.csv", stringsAsFactors = FALSE)
x13_cor <- cor(x13$X13_default, x13$UNRATE_published)
x13_mad <- mean(abs(x13$X13_default - x13$UNRATE_published))
x13_ok <- nrow(x13) == 720L && abs(x13_cor - 0.9985) < 0.0005 &&
  abs(x13_mad - 0.0647) < 0.002 &&
  all(abs(x13$UNRATE_published - as.numeric(unrate)) < 1e-9) &&
  all(abs(x13$UNRATENSA - as.numeric(unratensa)) < 1e-9)
check("UNRATE/UNRATENSA caches and the saved X-13 comparison are intact",
      gap_ok(raw_sa, "UNRATE") && gap_ok(raw_nsa, "UNRATENSA") &&
        length(unrate) == 720L && length(unratensa) == 720L &&
        !anyNA(unrate) && !anyNA(unratensa) && x13_ok,
      # The X-13 summary numbers are the prediction target in lab section 11,
      # so this line reports only whether they match, not what they are.
      sprintf("window = %d + %d months; X-13 file rows = %d, summary matches = %s",
              length(unrate), length(unratensa), nrow(x13), x13_ok))


# ---- verdict ----------------------------------------------------------------
n_pass <- sum(results)
n_all <- length(results)
cat(sprintf("---------------\n%d/%d checks passed.\n", n_pass, n_all))

# Inside a Quarto render, print failures without terminating knitr mid-document.
if (n_pass < n_all && !isTRUE(getOption("knitr.in.progress"))) {
  quit(status = 1, save = "no")
}
