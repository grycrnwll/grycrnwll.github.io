# Stamped copy of the whole of helpers/seasonality.R in the Econ 6376 course repo — behavior unchanged; edits belong in the canonical file.

# =============================================================================
# seasonality.R — Seasonal regressors and the raw periodogram
# Econ 6376: Applied Time Series Econometrics
# Canonical source: helpers/seasonality.R
#
# All three functions are built inline in the Module 5 notes (seasonal_dummies()
# in §5.8.2, path 1 on UNRATENSA; periodogram_df() and seasonal_bin_ratios() in
# the §5.9 Deeper Dive). The Module 5 notes build these inline; the deck's live
# code sources this copy. Later modules and AI packs may source or stamp this canonical
# copy.
# Requires: base R only (stats::spec.pgram); seasonal_bin_ratios() takes an
# object returned by freqseas::seas_test().
# =============================================================================

seasonal_dummies <- function(y, ref = 1) {
  # The (s - 1) seasonal indicator columns for a ts object y, with the
  # reference season `ref` dropped so a regression intercept is that
  # season's mean. Column names follow the calendar (Jan..Dec for s = 12,
  # Q1..Q4 for s = 4, s1..s_s otherwise).
  #
  # Arguments:
  #   y   : a ts object with frequency s > 1
  #   ref : the season to drop (1 = January for monthly data)
  #
  # Returns:
  #   A length(y) x (s - 1) numeric 0/1 matrix, ready for lm(y ~ X) or
  #   forecast::Arima(y, ..., xreg = X).

  s <- frequency(y)
  if (s < 2) stop("seasonal_dummies() needs a ts object with frequency > 1.")
  season <- as.numeric(cycle(y))
  labels <- if (s == 12) month.abb else if (s == 4) paste0("Q", 1:4) else paste0("s", seq_len(s))
  keep   <- setdiff(seq_len(s), ref)
  X <- sapply(keep, function(j) as.numeric(season == j))
  colnames(X) <- labels[keep]
  X
}

periodogram_df <- function(x) {
  # Raw periodogram of a series on the Fourier grid of the padded series
  # (spec.pgram's default fast = TRUE pads T to a highly composite length;
  # 719 becomes 720): omega in radians
  # per observation on (0, pi], I the ordinate. No taper, no smoothing, no
  # detrending; the mean is removed. Difference first if the series is I(1).
  #
  # Arguments:
  #   x : a numeric vector or ts object
  #
  # Returns:
  #   A data frame with columns `omega` (radians per observation) and `I`
  #   (periodogram ordinate), one row per frequency on that padded grid.

  sp <- stats::spec.pgram(as.numeric(x), taper = 0, detrend = FALSE,
                          demean = TRUE, plot = FALSE)
  data.frame(omega = 2 * pi * sp$freq, I = sp$spec)
}

seasonal_bin_ratios <- function(test) {
  # Seasonal-bin dip check on a freqseas::seas_test() object (Module 5,
  # §5.9.6; bench item 5b). For each seasonal bin of the test's fixed
  # partition, the mean standardized periodogram ordinate of the whitened
  # residuals divided by the mean over the bin's neighbouring non-seasonal
  # bins. A ratio below 1 is a dip (less seasonal-frequency power than the
  # bands beside it); above 1 is an excess. The Nyquist ordinate is
  # excluded, as in the package's detection statistic.
  #
  # Arguments:
  #   test : an object returned by freqseas::seas_test()
  #
  # Returns:
  #   A data frame with one row per seasonal bin: harmonic, bin, bin_mean,
  #   neighbour_mean, ratio (bin mean over neighbour mean), harmonic_ratio
  #   (the single ordinate on the harmonic itself over the same neighbour
  #   mean; NA when no ordinate sits on the harmonic, as at Nyquist); the
  #   attribute "overall" holds the ratio of the mean over all seasonal bins
  #   to the mean over all their neighbours.

  breaks <- test$partition$breaks
  M1     <- test$partition$M1
  n_bins <- length(breaks) - 1L
  n      <- test$pgram$n
  j      <- seq_len(floor(n / 2))
  omega  <- 2 * pi * j / n                 # Fourier frequencies, radians per obs
  I      <- test$pgram$pgram_std[j + 1L]   # element i is Fourier index j = i - 1
  keep   <- omega > 0 & abs(omega - pi) > 1e-9
  omega  <- omega[keep]; I <- I[keep]
  bin    <- findInterval(omega, breaks, left.open = TRUE, rightmost.closed = TRUE)

  neighbours <- function(m) setdiff(intersect(c(m - 1L, m + 1L), seq_len(n_bins)), M1)
  labels <- if (length(M1) == 6) c("pi/6", "pi/3", "pi/2", "2pi/3", "5pi/6", "pi") else paste0("bin ", M1)
  harm   <- if (length(M1) == 6) (1:6) * pi / 6 else rep(NA_real_, length(M1))

  rows <- lapply(seq_along(M1), function(k) {
    m <- M1[k]; nb <- neighbours(m); nb_mean <- mean(I[bin %in% nb])
    # the single ordinate sitting on the harmonic itself (NA if none is on the
    # Fourier grid, as at the Nyquist frequency, whose ordinate is excluded)
    ih <- which.min(abs(omega - harm[k]))
    on_grid <- !is.na(harm[k]) && abs(omega[ih] - harm[k]) <= 0.51 * pi / length(omega)
    data.frame(harmonic = labels[k], bin = m,
               bin_mean = mean(I[bin == m]), neighbour_mean = nb_mean,
               ratio = mean(I[bin == m]) / nb_mean,
               harmonic_ratio = if (on_grid) I[ih] / nb_mean else NA_real_)
  })
  out <- do.call(rbind, rows)
  nb_all <- unique(unlist(lapply(M1, neighbours)))
  attr(out, "overall") <- mean(I[bin %in% M1]) / mean(I[bin %in% nb_all])
  out
}
