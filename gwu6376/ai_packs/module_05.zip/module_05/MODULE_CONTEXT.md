# Module 5 Context — Model Diagnostics and Seasonality

**Econ 6376 — Applied Time Series Econometrics, George Washington University (Applied Economics MA).**

This file is self-contained. You can paste or upload it on its own into any AI
assistant and it will have everything it needs to help with Module 5.

<!-- BEGIN COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

## Course-wide conventions

These apply to every module of Econ 6376, not just this one.

### The master equation

Every model in this course is the following equation with some terms switched off:

$$y_t = \alpha + \delta t + \sum_{j=1}^{p} \phi_j y_{t-j} + \sum_{l=1}^{q} \theta_l \epsilon_{t-l} + \epsilon_t$$

The course analogy is a **mixing board**: each term is a slider, and each module
turns on new ones. A student should always be able to say where the model in
front of them sits on that board. If they can't, the framing has failed — help
them locate it.

### The cardinal notation rule: DGP vs. estimation

A data-generating process and an estimating equation look different, and the
course is strict about this.

- **DGP (the truth, unobservable):** unhatted parameters $\alpha, \delta, \phi_j, \theta_l, \beta$ and $\epsilon_t$, the **innovation**.
- **Estimating equation (your model, observable):** hatted parameters $\hat\alpha, \hat\phi_j, \hat\theta_l, \hat\beta$ and $e_t$, the **residual**, where $e_t = y_t - \hat y_t$.

Never write $\epsilon_t$ when you mean $e_t$. Never drop a hat from an estimate.
A well-specified model leaves residuals that behave like the innovations that
model assumes — that is the entire basis of diagnostic testing later in the course.

### Other standing conventions

- **Lag polynomials:** AR takes minus signs, $\Phi(L) = 1 - \phi_1 L - \cdots - \phi_p L^p$. MA takes plus signs, $\Theta(L) = 1 + \theta_1 L + \cdots + \theta_q L^q$.
- **Stationarity framing:** all roots of $\Phi(L) = 0$ lie strictly **outside** the unit circle. Enders and the older course slides use the equivalent characteristic-root-**inside** framing (related by $r = 1/L$). Both are correct; flag the difference whenever a student is cross-referencing a textbook.
- **Symbols:** $\phi$ = AR coefficients, $\theta$ = MA, $\beta$ = covariates, $\alpha$ = intercept, $\delta$ = trend. $\gamma_k$ = autocovariance at lag $k$, $\rho_k$ = autocorrelation, $\gamma_0 = \operatorname{Var}(y_t)$. $L$ = lag operator, $\Delta = (1-L)$. $t = 1,\ldots,T$.
- **"Stationary"** means weakly (covariance) stationary unless stated otherwise.
- **Language:** the course is taught in R. Students may submit graded work in another language if they can reproduce the workflow, but help and debugging are R-first. Plots use `ggplot2`.
- **Credentials:** FRED keys come from `Sys.getenv("FRED_KEY")`, never hardcoded, never committed.

### Working rules

- Concept before math, always. Intuition first, then notation.
- Simulation is the center of gravity, and a simulation that only confirms the textbook is half an exercise. Breaking an assumption is where understanding happens.
- The four-step rhythm for any major topic: **Concept → Math → Simulate (break something) → Real Data.**
- The student-facing learning protocol: **Predict → Commit → Ask AI → Test in R → Reconcile.**
- **Core is the assessable surface.** Course notes are tiered (Core / Deeper Dive / Technical Note / Looking Ahead). Problem sets and exams draw **only** on Core. Optional tiers are genuinely optional — never imply otherwise.

<!-- END COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

---

## What Module 4 established

Five facts this pack relies on, so it stands alone:

1. The unemployment rate is modeled in first differences (Module 2's verdict).
2. The Module 3 table: AR($p$) PACF cuts off, MA($q$) ACF cuts off, ARMA both tail off. Stationary ARs are MA($\infty$)s; invertible MAs are AR($\infty$)s.
3. AIC, AICc and BIC rank candidates fitted to the same data under one likelihood convention. The winner of a candidate set is not a validated model.
4. On 1960–2019 $\Delta$UNRATE ($T = 719$), under Module 4's zero-mean policy, every criterion picked ARMA(1,2) (ARMA(2,2) was a close second on AIC).
5. Its residual ACF showed spikes at lags 12, 24 and 36 that Module 4 called "residual annual-lag dependence" and deliberately left for Module 5.

## What Module 5 is about

**Part A** learns to *check* a fitted model; Ljung-Box turns a residual ACF into a verdict. **Part B** meets what Module 4's residuals kept pointing at — seasonality — treats it three ways on the raw unemployment rate, and ends on published UNRATE with a name for the spike. The same lesson in a trench coat: diagnostics say the model is wrong; the seasonal toolkit says how to fix it.

**On the mixing board, Module 5 turns on the seasonal band** — SARIMA$(p,d,q)(P,D,Q)_s$ terms at lags $s, 2s, \ldots$, seasonal differencing, and seasonal dummies. After it, every slider of the univariate mean equation is on; Module 8 adds $x_t$, and Module 14 gives the variance its own equation.

Lab map: 2–6 Part A (4 misspecify and watch, 6 the verdict) · 7 seasonal assumption-break · 8 raw series · 9–11 paths 1–3 · 12 epilogue.

### Core learning objectives

1. If the model is right, $e_t$ behaves like $\epsilon_t \sim \text{WN}(0,\sigma^2)$; structure in $e_t$ means the model is wrong.
2. Rank the four residual checks: serial correlation, heteroskedasticity (Module 14 preview), zero mean, normality.
3. Read a residual ACF against the Module 3 table to propose what the fit missed.
4. Write Ljung-Box, its $\chi^2_{h-\text{fitdf}}$ reference, fitdf $= p+q$ (or $p+q+P+Q_s$), and the choice of $h$.
5. Show by simulation that residual ACF and Ljung-Box catch a non-seasonal ARMA fit to a seasonal DGP.
6. Use the three terms precisely: autocorrelation, serial correlation, residual seasonality.
7. Compare general-to-specific (Mizon, 1995) with specific-to-general; walk one trimming step.
8. Distinguish deterministic from stochastic seasonality, place the seasonal unit root at the stochastic edge, explain why there is no clean "isn't", and apply the triage.
9. Apply $\Delta_s$ and read seasonal ACFs: decaying versus flat at $s, 2s, 3s$.
10. Write the SARIMA specification and the airline model ARIMA$(0,1,1)(0,1,1)_{12}$.
11. Work the three paths on UNRATENSA in R, comparing IC only within a differencing class.
12. State the differencing commitment from both sides.
13. Describe seasonal adjustment at recognition level, and why an adjusted series is a model's output.
14. Fit seasonal candidates to published UNRATE, spot $\hat\Theta_1 \approx -1$ under $D = 1$, and test whether the lag-12 spike survives ARIMA$(1,1,2)(1,0,1)_{12}$.

---

## Core concepts

**Residuals should behave like innovations.** $\epsilon_t$ is unobserved; $e_t = y_t - \hat y_t$ is observed. The question is never "are the residuals white noise" (no finite sample is) but "could they plausibly be?" The film room: gaps between play called and play run always exist; a *pattern* in them means the playbook is missing a page.

**Three terms, kept apart on purpose.**

| Term | Meaning | Belongs to |
|---|---|---|
| Autocorrelation | A property of any series, measured by its ACF | the data |
| Serial correlation | The verdict that a fitted model's residuals show autocorrelation | the model, relative to the data |
| Residual seasonality | Seasonal autocorrelation left in a published seasonally adjusted series | the adjustment procedure, itself a model |

The instructor's rule, verbatim: *"Serial correlation is not a property of the data — it is a property of your model relative to the data. It means your model is wrong."* Never say "the data has serial correlation." Textbooks blur the first two terms; flag that once. Say "serial correlation" aloud and someone hears "cereal killer" — neither lives in the data.

**Reading residuals.** The Module 3 table, pointed at what the fit *missed*: lag-1 spike → short-run AR or MA; geometric decay → AR; cutoff → MA; spikes at $s, 2s, 3s$ → seasonal dependence; large persistent correlations → too little differencing. A proposal, not a verdict: refit and re-check.

**Ljung-Box.** $Q(h) = T(T+2)\sum_{k=1}^{h}\hat\rho_k^2/(T-k) \stackrel{a}{\sim} \chi^2_{h-\text{fitdf}}$, on residuals. fitdf $= p+q$ for ARMA, $p+q+P+Q_s$ for SARIMA, $0$ for a raw series or a dummy regression. Horizons: $h = 10$ non-seasonal, $h = 24$ monthly; on monthly data report both, chosen before looking. **A large $p$-value is good news.** `Box.test()` defaults to `lag = 1`; always set `lag` and `fitdf`. `lb_both(fit)` reads fitdf from the fit and reports both horizons. When the horizons disagree (the Module 4 ARMA(1,2), fitdf 3, section 6), ask which lags each can see.

**Misspecify and watch.** On known ARMA DGPs ($T = 500$): fit one block short, then add the missing block. Beats 3–5 go beyond the notes' Core (practice, not assessable): fake an MA(2) with longer ARs, fit an AR(2) by MA(3), over-fit with ARMA(3,3). Residual structure is the fingerprint of what the fit left out, so diagnostics catch under-fitting and cannot see over-fitting (beyond Core; the notes' Core version is 'passing diagnostics means adequate, not true', the notes' misconception 9); parsimony (IC) handles that. The washing machine: a stain that survives the wash says the machine failed. For the tutor: each of section 4's five beats is its own work unit, so ask one prediction before each fit, not one for the whole section. Guessing what one missing block leaves behind is the section's whole point.

**The seasonal assumption-break (objective 5).** $y_t = 0.7y_{t-12} + \epsilon_t$, $T = 500$. Fit what Module 4 would fit, ARMA(1,1), then SARIMA$(0,0,0)(1,0,0)_{12}$; compare coefficients and both horizons. A small power curve over $\Phi_1$ (practice, not assessable) asks what the test does with nothing to catch.

**General-to-specific (Mizon, 1995).** Start one size bigger, confirm diagnostics pass, trim while they still pass; starting small picks terms from contaminated residuals. It works *within* a correct class: you cannot trim a non-seasonal model into a seasonal one.

**What seasonality is.** Four traditions (calendar means, seasonal unit roots, unobserved components, spectral), none nesting the others; Zellner's black cat. Course position: *we do not fully agree on what seasonality is, but you can see it.* Deterministic (fixed calendar pattern) versus stochastic (drifting), with the seasonal unit root at the stochastic edge. No clean "isn't"; the one safe non-example: monthly sampling alone makes nothing seasonal. Triage: fixed → dummies; drifting → SARIMA; "gone, not modeled" → adjustment. A twice-a-year rhythm shows up at lags 6, 12, 18 (the Deeper Dive periodogram separates the $\pi/6$ and $\pi/3$ harmonics; not assessable).

**SARIMA.** $\Phi_p(L)\Phi_P(L^s)(1-L)^d(1-L^s)^D y_t = \Theta_q(L)\Theta_Q(L^s)\epsilon_t$. Uppercase is seasonal; AR minus, MA plus; $Q_s$ for the seasonal MA order in prose. The bands multiply: $(1-\phi_1L)(1-\Phi_1L^{12})$ forces a lag-13 cross term (expansion: Deeper Dive, notes §5.7). Decaying seasonal spikes suggest stationary seasonal ARMA; spikes that stay high suggest a seasonal unit root and $\Delta_s$. Images: the two-band console, the tide under the weather. The airline model on log `AirPassengers` is a benchmark, not a default.

**The three paths on UNRATENSA (1960–2019).** The raw ACF of $\Delta$UNRATENSA at 12/24/36 is autocorrelation, no model involved.

- *Path 1, dummies*: absorb a fixed calendar pattern. Read what the residual ACF keeps and whether month effects hold between 1960–89 and 1990–2019; the nominal split $F$ ignores autocorrelated errors, so the size of the shifts is the evidence.
- *Path 2, SARIMA*: the airline model $(0,1,1)(0,1,1)_{12}$, $(1,1,2)(1,0,1)_{12}$, `auto.arima()` (a very good intern, so read its work) and $(1,1,2)(0,1,1)_{12}$. IC compares only within $(d,D)$.
- *$D$ from both sides*: one seasonal difference too many pushes $\hat\Theta_1$ toward −1, one too few pushes $\hat\Phi_1$ toward +1. Either boundary estimate says revisit $D$. A residual spike at 12 alone never licenses $D = 1$.
- *Path 3, adjustment* (recognition level): trend-cycle + seasonal + irregular; agencies run X-13ARIMA-SEATS, and most headline FRED series are outputs of this kind of procedure. UNRATE is one, with a twist: BLS adjusts unemployment and the labor force by age and sex (X-11 filters, not the SEATS default) and computes the rate from the totals. Adjustment is a model, so it can leave residual seasonality. No simulate step, by design.

**The epilogue.** ARIMA$(1,1,2)(1,0,1)_{12}$ on published UNRATE, fitdf 5, then one trim step to $(1,1,2)(1,0,0)_{12}$ and $(1,1,2)(0,0,1)_{12}$. The Module 4 spike was serial correlation on that fit; on a published adjusted series its name is residual seasonality. The negative sign is *consistent with* a seasonal deficit (adjustment removing slightly more than the seasonal component) — only with that hedge; not a claim about BLS practice. (Pending instructor ratification.)

---

## Vocabulary

Beyond the terms defined above: residual ACF · fitdf · horizon $h$ · size and power · seasonal period $s$ · $\Delta_s$ · $\Phi_j$, $\Theta_l$, $Q_s$ · multiplicative structure · seasonal dummies · Fourier terms · trend-cycle / seasonal / irregular · UNRATENSA (not seasonally adjusted) · differencing class.

---

## Common misconceptions

Correct these by asking a question or running something, not by lecturing.

1. **"My data has serial correlation."** The data has autocorrelation. Serial correlation is a verdict on your fit: change the model and it can vanish while the data stays put (lab beats 1 and 2).
2. **"Small Ljung-Box $p$ — significant, great!"** In diagnostics you want to fail to reject. Small $p$ means the model failed the check.
3. **"Ljung-Box has $h$ degrees of freedom."** It has $h - \text{fitdf}$. With fitdf $= 0$ on ARMA residuals the $p$-value comes out too large — try it on the callback fit.
4. **"It passed at $h = 10$, so I'm done."** Run `lb_both()` on the Module 4 fit. A test that never looks at lag 12 cannot see lag 12.
5. **"Tidy coefficients and a good AIC mean the model is fine."** Coefficients and IC score a fit; they do not audit what it left behind. Read section 7's wrong-class ARMA(1,1) coefficients, then its residuals.
6. **"Any spike outside the band means the model is wrong."** Across 24 lags, expect about one by chance. Spikes recurring at 12, 24 and 36 are different.
7. **"Passing diagnostics means the model is true."** (Beyond Core.) Diagnostics catch structure a fit left out; they cannot object to terms it did not need. Over-fit the ARMA(2,2) data with an ARMA(3,3) (lab beat 5) and watch it pass.
8. **"Monthly data means seasonal."** Monthly sampling gives seasonality a place to live, not seasonality. Label a simulated random walk monthly and look at lag 12 of its *changes*.
9. **"Dummies and SARIMA are interchangeable."** Dummies assume a fixed pattern; UNRATENSA's July effect flipped sign between halves.
10. **"Every monthly series needs $D = 1$."** Fit the airline model to published UNRATE and read $\hat\Theta_1$, then fit $D = 0$ to raw UNRATENSA and read $\hat\Phi_1$. Both boundary estimates say revisit $D$.
11. **"I'll let AIC choose between $D = 0$ and $D = 1$."** A $D = 1$ likelihood is computed on a shorter, different series, so IC compares only within a differencing class.
12. **"The seasonally adjusted series is the data."** It is a procedure's output, and can leave residual seasonality behind. What the survey measured is the not-seasonally-adjusted series.

**Respecify, or fix the standard errors?** For an ARMA model, residual serial correlation means respecify. Module 1 still stands: in a *regression*, dependence-robust standard errors are a legitimate response. Different setting, different fix.

---

## The Module 5 → Module 6 handoff

Module 5 hands Module 6 a diagnostic-clean ARIMA$(1,1,2)(1,0,1)_{12}$ on the published UNRATE, its seasonal ARMA terms absorbing the residual seasonality the adjustment left behind. Module 6 asks what it says about next month and how far to trust it. If the student asks for later-module machinery (a forecast, a fan chart, an ARCH test on the residuals), build it on request and flag it as a preview of the module it belongs to — do not deflect them back to Module 5.

---

## Lab anchors (for the tutor: the numbers a student's predictions get reconciled against)

Reconcile after the student predicts, or give them at once if asked outright.

- **§2.** Residual $\hat\rho$ at 12/24/36 $= -0.145/-0.125/-0.130$ against $\pm 0.073$. Fit with `include.mean = FALSE` (Module 4's policy); estimating the mean instead (about $-0.002$) moves them only in the fourth decimal.
- **§4.** One block short leaves its fingerprint at low lags; the right orders leave nothing Ljung-Box can reject; AR($p$) faking an MA(2) leaves less as $p$ grows; MA(3) on AR(2) data still rejects; the over-fit ARMA(3,3) passes.
- **§6.** fitdf 3: $h = 10$, $Q = 3.76$, $p = 0.807$ (pass); $h = 24$, $Q = 46.1$, $p = 0.0012$ (fail).
- **§7.** Wrong-class ARMA(1,1): unremarkable coefficients, $p \approx 0.95$ at $h = 10$, $Q \approx 378$ at $h = 24$. SARIMA$(0,0,0)(1,0,0)_{12}$: $\hat\Phi_1 = 0.703$, $p = 0.90$. The power curve's $\Phi_1 = 0$ row is the test's size.
- **§8.** Raw $\Delta$UNRATENSA ACF at 12/24/36: 0.804/0.777/0.742; published at lag 12: $-0.089$. Monthly-labeled random walk's changes: lag 12 inside the band.
- **§9.** $R^2 = 0.721$; residual $\hat\rho$ 0.350/0.298/0.223; lags 2, 3, 5, 7, 11 also breach. June $+0.84 \to +0.43$, July $-0.33 \to +0.02$; nominal $F(11,695) = 12.5$.
- **§10.** $(1-0.5L)(1-0.7L^{12})$: lags 1, 12, 13 at $-0.5$, $-0.7$, $+0.35$. Seasonal AR with $\Phi_1 = 0.8$ decays (theory at lag 24: $0.8^2 = 0.64$; read the sample value off the table); the seasonal random walk stays flat. Candidates: only 1 fails. 1 (airline): $\hat\Theta_1 = -0.78$, fails both horizons from lags 2–5. 2 passes with $\hat\Phi_1 = 0.994$. 3 (`auto.arima()`: $(2,0,2)(2,1,2)_{12}$) passes. 4 passes, $p = 0.88/0.42$, $\hat\Theta_1 = -0.75$. Airline on published UNRATE: $\hat\Theta_1 = -0.99999$.
- **§11 (the module's surprise; hold until predicted).** One default `seas()` call vs published UNRATE, 720 months: correlation 0.9985; mean absolute gap 0.065 points; 80% within 0.1; largest gap 0.37 (February 1976); X-13 chose $(1,1,2)(0,1,1)$, the path-2 winner. Say "closely approximates, not equals": BLS adjusts components with X-11 filters and computes the rate, so the closeness itself is worth a question.
- **§12.** Residual $\hat\rho$ 0.028/−0.024/−0.065; $p = 0.55/0.33$. Both trims fail at $h = 24$ ($p = 0.0019$, $0.0054$). Candidate 4's orders on the published series put $\hat\Theta_1$ near $-1$ again.
