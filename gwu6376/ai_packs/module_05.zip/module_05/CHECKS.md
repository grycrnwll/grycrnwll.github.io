# What the Checks Check

`R/checks.R` holds seven assertions about things Module 5 claims are true. Run it
from the pack root at any time:

```
Rscript R/checks.R
```

Each check prints one `PASS` or `FAIL` line with the numbers it computed. Any
failure makes the script exit with a nonzero status, so it works in a script as
well as by hand. The last chunk of the lab runs it too — inside a Quarto render
it prints its results without killing the render.

**This is not an answer key.** The checks confirm that the *code and data* behave
the way the module says they do. They cannot tell you whether your reading of a
residual ACF is any good, and they don't try. They exist so that when you and an
AI tutor disagree about a fact, there's a referee neither of you controls.

The file is plain base R: it fits with `stats::arima()` and needs neither
`forecast` nor `ggplot2`, even though the lab uses both. If a check confuses you,
read it — each one is a short block, and the whole script takes a couple of
seconds.

---

## Check 1 — the Module 4 spike is really there

**Asserts:** the ARMA(1,2) on $\Delta$UNRATE, 1960–2019, leaves residual
autocorrelations within 0.002 of $-0.145$, $-0.125$ and $-0.130$ at lags 12, 24
and 36, and its Ljung-Box verdict (fitdf $= 3$) passes at $h = 10$ ($p > 0.5$)
and fails at $h = 24$ ($p < 0.01$).

**Why:** this is the cliffhanger the whole module answers. If it moved, every
later section would be answering a different question.

**A failure usually means:** the data window changed (someone let 2020 in), the
data file was updated, or the model orders were edited.

## Check 2 — Ljung-Box is just arithmetic

**Asserts:** $Q(24) = T(T+2)\sum_{k=1}^{24}\hat\rho_k^2/(T-k)$, computed by hand
from the residual ACF, equals `Box.test()`'s statistic to $10^{-8}$, and the
test reports $24 - 3 = 21$ degrees of freedom.

**Why:** the formula in section 5 is the whole test. Seeing it match once is what
lets you trust it every other time — and the degrees of freedom are where most
real mistakes happen.

**A failure usually means:** the hand formula was edited (a common one: dividing
by $T$ instead of $T - k$), or `fitdf` in the `Box.test()` call no longer
matches $p + q$.

## Check 3 — the detector catches a planted seasonal miss

**Asserts:** on the section 7 series (seasonal AR(1) at lag 12, $\Phi_1 = 0.7$,
seed 2005, the hand loop), a non-seasonal ARMA(1,1) fails Ljung-Box at $h = 24$
with $p < 0.001$, while SARIMA$(0,0,0)(1,0,0)_{12}$ recovers $\hat\Phi_1$ within
0.05 of 0.7 and passes ($p > 0.05$).

**Why:** a diagnostic you have never seen fire on a known problem is a diagnostic
you are taking on faith.

**A failure usually means:** the seed or the loop changed. With $T = 500$ and
$\Phi_1 = 0.7$ the wrong-class rejection is overwhelming, so a failure here is
almost never bad luck.

## Check 4 — path 1 does what the lab says

**Asserts:** `seasonal_dummies()` returns 11 columns with no row having more
than one 1; the dummy regression on $\Delta$UNRATENSA has $R^2$ within 0.005 of
0.721 and residual lag-12 autocorrelation within 0.005 of 0.350; and between
1960–89 and 1990–2019 the average June change falls by more than 0.3 points
while the average July change rises by more than 0.3 points.

**Why:** these are the three facts path 1 rests on — the dummies absorb a lot,
they leave seasonal structure behind, and the pattern moved between halves.
(The check tests the size of the shifts, not the lab's split-halves $F$ test.
That test's $p$-value assumes uncorrelated errors, which the residual ACF rules
out, so it is nominal and far too small.)

**A failure usually means:** the reference month or the window changed, or
`R/seasonality.R` no longer matches the course helper.

## Check 5 — $D$ gets pushback from both sides

**Asserts:** on raw UNRATENSA, $(1,1,2)(1,0,1)_{12}$ gives $\hat\Phi_1 > 0.98$
(too few seasonal differences); on published UNRATE, the airline model gives
$\hat\Theta_1 < -0.99$ (too many); and the path-2 winner $(1,1,2)(0,1,1)_{12}$ on
raw UNRATENSA has $|\hat\Theta_1| < 0.95$ and passes Ljung-Box at both horizons.

**Why:** the boundary estimates are how the data tell you the differencing is
wrong, and they never show up in an IC table.

**A failure usually means:** the two series were swapped (raw where published
belongs, or the reverse), or the model orders changed.

## Check 6 — the model handed to Module 6 is clean

**Asserts:** ARIMA$(1,1,2)(1,0,1)_{12}$ on published UNRATE has fitdf $= 5$,
passes Ljung-Box at $h = 10$ and $h = 24$, and has residual lag-12
autocorrelation inside $\pm 0.073$.

**Why:** Module 6 forecasts with this model. It should arrive having passed the
checks Module 5 taught.

**A failure usually means:** the window or data changed, or `fitdf` was miscounted
(it is $p + q + P + Q_s = 1 + 2 + 1 + 1$).

## Check 7 — the data are the data

**Asserts:** `UNRATE.csv` and `UNRATENSA.csv` keep their two columns and their
single known blank at 2025-10-01; the 1960–2019 window is 720 complete months
for each; and `x13_vs_published.csv` has 720 rows, matches both series month for
month, and reproduces its headline summary numbers.

**Why:** everything above depends on these files. A silent refresh, an
interpolated gap, or an edited saved file would change the lab's numbers without
announcing itself.

**A failure usually means:** a data file was updated or edited. Updating is fine;
update `data/README.md` and the lab's numbers with it rather than loosening the
check.

---

## If a check fails and you can't work out why

Read the check. It's a few lines of base R and it prints the numbers it computed
alongside the target, so the gap between "what we expected" and "what we got" is
right there in the output.

If you're working with an AI tutor, show it the failing line, your R version,
*and* the relevant file. "Check 4 fails — $R^2$ is 0.69" plus `R/seasonality.R`
is a solvable problem; "my checks fail" is not.
