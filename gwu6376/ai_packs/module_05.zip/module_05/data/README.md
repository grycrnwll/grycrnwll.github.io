# data/ — The data behind the Module 5 lab

Everything the lab needs is in this folder, so it runs with no FRED key and no
internet connection. That holds for every pack in this course: nothing should
need a network call to work.

If you want to see how the data are actually pulled, `R/fetch_fred.R` shows the
live `fredr` call — but nothing requires you to run it.

| File | What it is | Coverage |
|---|---|---|
| `UNRATE.csv` | U.S. civilian unemployment rate, monthly, **seasonally adjusted**, percent (FRED `UNRATE`). The series you have used since Module 2. | 1948-01 to 2026-04, 940 rows, one blank month |
| `UNRATENSA.csv` | The same rate **not seasonally adjusted** (FRED `UNRATENSA`): what the survey measures before any adjustment. | 1948-01 to 2026-08, 944 rows, one blank month |
| `x13_vs_published.csv` | What one default seasonal-adjustment call on the raw series produced, month by month, next to the raw and published series. Used in lab section 11. | 1960-01 to 2019-12, 720 rows |
| `x13_stats.csv` | A one-row summary of that same call. Used in lab section 11 and by `R/checks.R`. | one row |

## The one gap you should know about

Both FRED files have exactly one blank: **October 2025**, a federal data-release
gap. The lab uses January 1960 through December 2019, the same window as Module
4, so the gap never touches it. Do not interpolate or silently "clean" the
file; check 7 in `R/checks.R` looks for that blank on purpose.

The window stops at 2019 because April 2020's jump (from 4.4 to 14.8 on the
adjusted series) dominates every autocorrelation it touches, and this module has
no outlier or break treatment yet. Running past 2019 is a fine exploration, as
long as you label it a sensitivity analysis.

Columns in both FRED files follow the FRED CSV export:

```text
observation_date,UNRATE
1948-01-01,3.4
```

## The seasonal-adjustment files

Section 11 asks you to predict something about these before you look, so this
README does not describe the results.

- **Where they came from:** one call to `seasonal::seas(unratensa)` with every
  option at its default (X-13ARIMA-SEATS via the `seasonal` and `x13binary`
  packages), run on UNRATENSA over the 1960–2019 window. The output was saved
  here on 2026-09-23, so you see the same numbers whether or not X-13 is
  installed on your laptop.
- **`x13_vs_published.csv` columns:** `date`, `UNRATENSA` (raw), `X13_default`
  (the call's adjusted series), `UNRATE_published` (FRED's adjusted series), and
  `X13_minus_published`.
- **`x13_stats.csv` columns:** the model X-13 chose automatically, plus summary
  numbers comparing its output with the published series.
- **Why they ship:** X-13 needs two optional packages that not every laptop
  has. With them installed, the lab runs the call live and checks it against
  this file; without them, the lab reads this file and says so.

## Refreshing the data

Re-run the `fredr` pull with a valid `FRED_KEY` in your environment
(`R/fetch_fred.R`), write the result here, and update the coverage column above.
If you refresh anything, the lab's printed numbers and `R/checks.R` will notice;
update them together rather than loosening a check.

## The key rule

**Never commit an API key, or any file containing one, to this folder.** Keys
live in your environment — in `.Renviron` or via `Sys.setenv()` — and are read
with `Sys.getenv("FRED_KEY")`. They never appear in a course file. This pack is
meant to be shareable.

Get a free FRED key at <https://fred.stlouisfed.org/docs/api/api_key.html>.
