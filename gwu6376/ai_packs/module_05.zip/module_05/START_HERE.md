# Start Here — Module 5 AI Learning Pack

**Econ 6376: Applied Time Series Econometrics — Module 5, "Model Diagnostics and Seasonality"**

This folder is a self-contained study environment. Point an AI assistant at it,
or upload pieces of it to a chat tool, and you get a tutor that knows this
course's notation, conventions, and the specific things students get wrong in
Module 5 — plus a lab you can actually run to check whether it's telling you the
truth.

Everything here runs with **no API key and no internet connection**.

This pack stands alone — you do not need the Module 4 pack to use it. If you
*did* work through the Module 4 pack, bring your `LEARNING_LOG.md` from it: your
last entry there (especially the remaining-uncertainty field) is the fastest way
to start your first Module 5 session.

---

## What's in the folder

| File | What it is |
|---|---|
| `START_HERE.md` | This map. |
| `MODULE_CONTEXT.md` | The module distilled: objectives, concepts, notation, vocabulary, misconceptions. Self-contained — this is the file you upload to a chat tool. |
| `AI_TUTOR_CONTRACT.md` | Instructions to the assistant about how to help you. Worth reading yourself so you know what to expect. |
| `AI_USE_GUIDE.md` | For you: what AI is good and bad at here, how to verify claims, and how disclosure works on graded work. |
| `module_05_lab.qmd` | The lab. Runnable Quarto/R, start to finish, as shipped. |
| `R/arma_simulator.R` | The Module 3 simulator: an ARMA DGP written as a loop. |
| `R/sarima_simulator.R` | Its seasonal sibling: the same loop with a seasonal band. |
| `R/diagnostics.R` | `lb_both()`, which runs Ljung-Box at both course horizons in one line. |
| `R/seasonality.R` | `seasonal_dummies()` and `periodogram_df()`, used in the lab and one exploration. |
| `R/fetch_fred.R` | Optional live FRED pull. Needs a free API key. Nothing in the lab requires it. |
| `R/checks.R` | Seven assertions that referee the pack. Run it any time. |
| `CHECKS.md` | What each check means and what a failure usually points to. |
| `data/UNRATE.csv` | The U.S. unemployment rate you have used since Module 2, 1948 onward. |
| `data/UNRATENSA.csv` | The same rate *before* seasonal adjustment. You meet it in section 8. |
| `data/x13_vs_published.csv`, `data/x13_stats.csv` | What one default seasonal-adjustment call on the raw series produced. Used in section 11 — worth not peeking before then. |
| `data/README.md` | Where the data came from, including one gap you should know about. |
| `reference/module_05_notes.qmd` | **The full chapter** — your AI tutor can read and cite this. It's a copy for reading and citing, not for rendering in place. |
| `TEXTBOOK_MAP.md` | Where Module 5 topics live in Enders, Hamilton, Hyndman, and Shumway & Stoffer, plus a notation translation table. |
| `LEARNING_LOG.md` | Your private log. Never collected, never graded. |
| `CLAUDE.md`, `AGENTS.md` | Auto-loaded briefings for folder-aware AI tools. You don't need to read these. |

---

## Recommended order

1. **`MODULE_CONTEXT.md`**: 3 minutes now, the rest later. Read the two short sections "What Module 4 established" and "What Module 5 is about", and **stop at "Core learning objectives".** Almost everything below that line gives away something the lab asks you to predict: which horizon fails, which coefficient runs into the boundary, whether the bloated model passes. Come back and read the whole file after the lab. It makes a very good review sheet.
2. **`AI_USE_GUIDE.md`** — 5 minutes. Read this before you start asking an AI anything, not after.
3. **`module_05_lab.qmd`** — the main event. Open it in RStudio (or any Quarto-capable editor) and work through it section by section, running chunks as you go. Write each prediction down before you run its chunk — the gap between the two is the payoff.
4. **`reference/module_05_notes.qmd`** — when you want the full treatment of something the lab touched briefly. This is the course's chapter; the lab is the sandbox.
5. **`LEARNING_LOG.md`** — as you go, not at the end.

`TEXTBOOK_MAP.md` and `CHECKS.md` are references. Reach for them when you need them.

---

## Starting a session with an agentic CLI tool

If you're using Claude Code, Codex, or anything else that can read a folder:

1. Open a terminal in **this folder** (`ai_packs/module_05/`).
2. Start the tool. It will pick up `CLAUDE.md` or `AGENTS.md` automatically and read the contract.
3. Just say what you want to do. For example:
   - "I'm starting Module 5. Walk me through the lab section by section."
   - "Run section 4 and make me predict the residual ACF before every fit."
   - "I think serial correlation is just something unemployment data has. Convince me I'm wrong, or agree with me."
   - "I think the airline model is the safe default for any monthly series. Convince me I'm wrong, or agree with me."
   - "Help me invent a DGP that fools Ljung-Box for exploration 4."

You don't need a special prompt. The folder is the prompt.

## Starting a session with a chat tool

If you're using a web chat interface (ChatGPT, Claude, Gemini, a local model):

1. Upload or paste **`MODULE_CONTEXT.md`** and **`AI_TUTOR_CONTRACT.md`**. These two are designed to work standalone and together fit inside a small context window — a local model on your laptop gets the same tutor as anyone else.
2. Add whichever lab section you're working on, if the tool can take it.
3. Then ask your question normally.

If the tool has a persistent "custom instructions" or "project" feature, put the
contract there once and you won't have to re-upload it every session.

---

## Picking up where you left off

Sessions end. Context windows reset. AI tools forget everything between
conversations, and they will not tell you they've forgotten.

**`LEARNING_LOG.md` is your thread of continuity.** It's the only thing in this
folder that accumulates *your* thinking rather than the course's. Two habits make
it work:

- Write in it *during* a session, not from memory afterward.
- Start a new session by pasting or pointing at your last entry: *"Here's where I got to last time — I predicted X, found Y, and I'm still unsure about Z. Let's pick up from Z."*

That single sentence rebuilds more useful context than a long re-explanation,
because it tells the tutor what you already know and — more usefully — what you
don't.

The log is private. It is never collected and never graded. It only works if you
write what you actually thought, including the parts that turned out to be wrong.

---

## If something breaks

Run this from the folder root:

```
Rscript R/checks.R
```

Seven lines come back, each PASS or FAIL. If they all pass, the pack is intact and
the problem is in something you changed — which is fine, that's what the lab is
for. If one fails, `CHECKS.md` explains what that check asserts and what usually
causes it to fail.

The lab needs R with `ggplot2` and `forecast` installed. Those are the only
required packages. Section 11 can also run one live seasonal-adjustment call if
you have the optional `seasonal` and `x13binary` packages; without them it uses
the saved output and says so.
