# Textbook Map — Module 5

Where Module 5's ideas live in the books you are most likely to read alongside
this course, and how to translate the notation when you get there.

**This file contains pointers and translations only — no textbook text.** If you
want to know what Enders *says*, read Enders. What this file does is get you to
the right pages and stop the notation from tripping you.

**How to read the pointers.** Page ranges are the ones this course's own notes
use, for the editions listed below. Where the notes only name a chapter, the
pointer stays at chapter level. The Shumway & Stoffer section pointers, the
Hamilton section pointers, and the Enders notation cells were checked against
the course's own copies of those books (editions below). Nothing is guessed at
the page level — if your copy disagrees, trust your copy and tell me. Cells
marked **(verify)** are locations or conventions not yet pinned down; check your
copy before relying on one.

**Editions assumed:** Enders, *Applied Econometric Time Series*, 4th ed.
Hamilton, *Time Series Analysis* (1994). Hyndman & Athanasopoulos, *Forecasting:
Principles and Practice*, 3rd ed. (fpp3), free online at <https://otexts.com/fpp3/>.
Shumway & Stoffer, *Time Series Analysis and Its Applications: With R
Examples*, 3rd ed.

---

## Part A — Concept pointers

### Residual diagnostics and Box-Jenkins adequacy checking

Does your fitted model leave anything behind?

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 72–79: residual checks inside the Box-Jenkins workflow. |
| Hamilton | §4.8 (the Box-Jenkins steps) defers diagnostic checking to Chapters 5 and 14; Hamilton is not the course's main source for applied diagnostics. |
| Shumway & Stoffer | §3.8, "Building ARIMA Models" (p. 144). |
| fpp3 | Ch. 5 (residual diagnostics) **(verify section)** and Ch. 9 (ARIMA models), chapter level. fpp3 uses `gg_tsresiduals()` and `ljung_box`; `checkresiduals()` is the forecast-package (fpp2) equivalent. |

### The Ljung-Box $Q$ statistic and the fitted-model degrees of freedom

| Book | Where |
|---|---|
| Enders | Ch. 2, p. 68. |
| Hamilton | Location **(verify)**. |
| fpp3 | Ch. 5 (residual diagnostics, `ljung_box`) **(verify section)**; applied to ARIMA fits in Ch. 9, chapter level. |
| Shumway & Stoffer | §3.8 (p. 144): the Ljung-Box-Pierce $Q$ on $H - p - q$ degrees of freedom. |

### Seasonal processes, seasonal differencing, and multiplicative seasonal models

How the seasonal band works, and why lag 13 comes for free.

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 96–102. |
| Hamilton | §6.4: seasonal differencing seen as a filter, in the frequency domain. |
| Shumway & Stoffer | §3.9, "Multiplicative Seasonal ARIMA Models" (p. 154). |
| fpp3 | Ch. 9, the seasonal ARIMA material, chapter level. |

### The airline model

| Book | Where |
|---|---|
| Enders | Ch. 2, p. 102. |
| fpp3 | Ch. 9, chapter level **(verify whether the book works this exact example)**. |
| Original | Box & Jenkins (1970), the source of both the model and the diagnostic-checking step. |

### Seasonal adjustment and decomposition (recognition level)

What trend-cycle + seasonal + irregular means, and what X-11 and SEATS are.

| Book | Where |
|---|---|
| fpp3 | Ch. 3 (time series decomposition). Note the difference in stance: the book treats decomposition as a descriptive tool; this course treats adjustment as a model with its own diagnostics. |
| Enders | Location **(verify)**. |
| Hamilton | Location **(verify)**. |

### General-to-specific modeling

| Source | Where |
|---|---|
| Mizon (1995) | "Progressive Modelling of Macroeconomic Time Series: The LSE Methodology." The course's source for this strategy; none of the three textbooks is pinned for it **(verify)**. |

### The periodogram and the frequency domain (Deeper Dive, not assessable)

| Book | Where |
|---|---|
| Shumway & Stoffer | Ch. 4. |
| Hamilton | Ch. 6. |
| Enders, fpp3 | Not used for this. |

### Where the four traditions of "what seasonality is" come from

The primary sources are listed in the references at the end of the notes'
section 5.9 (Falkner 1924; Kallek 1978; Hylleberg, Engle, Granger & Yoo 1990;
Canova & Hansen 1995; Hillmer & Tiao 1982; Bell & Hillmer 1984; Nerlove 1964;
Granger 1978; Zellner, ed., 1978). No textbook chapter is pinned for this.

---

## Part B — Notation translation

Same mathematics, different alphabets. This is where most cross-referencing
confusion comes from.

| Concept | This course | Enders | Hamilton / fpp3 / Shumway & Stoffer |
|---|---|---|---|
| Seasonal period | $s$ (12 for monthly) | $s$, as in ARIMA$(p,d,q)(P,D,Q)_s$ (same as the course) | fpp3 writes $m$, as in $(P,D,Q)_m$; Shumway & Stoffer write $s$ |
| Seasonal AR / MA coefficients | $\Phi_1, \ldots$ and $\Theta_1, \ldots$ (uppercase) | Lowercase, indexed by the lag: $a_4$ (AR), $\beta_4$ (MA) in a quarterly example | Shumway & Stoffer: uppercase $\Phi$, $\Theta$, as in the course; fpp3 **(verify)** |
| Seasonal MA order, alone in prose | $Q_s$ (to avoid the Ljung-Box $Q$) | — | Usually just $Q$ **(verify)** |
| AR coefficient | $\phi_j$ | $a_i$ | $\phi_j$ **(verify local context)** |
| MA polynomial sign | $\Theta(L) = 1 + \theta_1 L + \cdots$ (plus) | Plus signs, $(1 + \beta_1 L)$ (same as the course) | Shumway & Stoffer: plus signs; older Box–Jenkins-tradition texts may write minus signs; R reports plus |
| Stationarity / invertibility roots | Roots of $\Phi(L)$, $\Theta(L)$ outside the unit circle | Characteristic roots inside (reciprocal, same condition) | Hamilton: lag-polynomial roots outside |
| Lag operator, noise | $L$, $\epsilon_t$ | $L$, $\varepsilon_t$ | Shumway & Stoffer: $B$ (backshift), $w_t$ |
| Frequency | Radians per observation, $\omega \in (0, \pi]$ | — | Shumway & Stoffer: cycles per observation on $(0, 1/2]$; multiply by $2\pi$ |
| "Autocorrelation" vs "serial correlation" | Kept apart: the series has autocorrelation; serial correlation is a verdict on a fit | Used interchangeably | Hamilton and fpp3: used interchangeably; Shumway & Stoffer **(verify)** |
| Ljung-Box degrees of freedom | $h - \text{fitdf}$, fitdf $= p + q$ (or $p + q + P + Q_s$) | Number of $Q$ lags minus $p + q$, and one fewer again if a constant is estimated; the course and R's `fitdf` do not count the intercept. Enders writes the number of $Q$ lags as $s$ — not the seasonal period | Shumway & Stoffer: $H - p - q$. fpp3's `ljung_box` takes `dof` by hand; forecast's `checkresiduals()` (fpp2) fills it from the model |

### The four that actually cause problems

1. **$m$ is $s$.** fpp3's seasonal period $m$ is this course's $s$. Same number, different letter.
2. **Serial correlation means something narrower here.** When a textbook says the data "have serial correlation", translate it to *autocorrelation* before you reason with it. In this course, serial correlation is always a verdict on a fitted model.
3. **Check the MA sign before copying a coefficient.** Enders and Shumway & Stoffer use plus signs, as this course does. A text that writes the MA polynomial with minus signs reports $\theta$ and $\Theta$ with the opposite sign from R and this course. The seasonal over-differencing flag is $\hat\Theta_1 \approx -1$ in *course* sign.
4. **Cycles versus radians.** A Shumway & Stoffer frequency of $1/12$ is this course's $\pi/6$.
