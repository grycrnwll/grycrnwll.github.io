# What the Checks Check

`R/checks.R` holds six assertions about things Module 1 claims are true. Run it
from the pack root at any time:

```
Rscript R/checks.R
```

Each check prints one `PASS` or `FAIL` line with the numbers it computed. Any
failure makes the script exit with a nonzero status, so it works in a script or
a CI job as well as by hand. The last chunk of the lab runs it too — inside a
Quarto render it prints its results without killing the render.

**This is not an answer key.** The checks verify that the *code and data* behave
the way the module says they do. They cannot tell you whether your interpretation
of a correlogram is any good, and they don't try. They exist so that when you and
an AI tutor disagree about a fact, there's a referee neither of you controls.

The file is deliberately written in plain base R. If a check confuses you, read it
— it's about six lines each.

---

## Check 1 — `rho_1` of a phi = 0.5 AR(1) is close to 0.5

**Asserts:** simulate 20,000 observations of an AR(1) with $\phi = 0.5$; the
lag-1 sample autocorrelation lands within 0.05 of 0.5.

**Why:** this is the module's headline result, $\rho_k = \phi^k$, at $k = 1$. If
this fails, the relationship between the memory parameter and the ACF is broken
somewhere.

**A failure usually means:** you edited `R/ar1_simulator.R` and changed how the
loop uses `phi` (a common one: applying `phi` to the innovation instead of to
`data[t-1]`). It can also mean the seed was changed *and* the tolerance is tight
— but with 20,000 observations the sampling error is roughly 0.007, so seed
choice alone should never move it by 0.05. Suspect the simulator, not luck.

## Check 2 — `ar1_simulator()` returns 500 finite values as a `ts`

**Asserts:** with `n = 500` and `burn_in = 200`, the output is a `ts` object of
length exactly 500 containing no `NA` and no infinities.

**Why:** everything downstream assumes this contract. It's worth stating out loud
once rather than discovering a length mismatch three plots later.

**A failure usually means:** the burn-in slicing was edited. Note a genuine quirk
of this function you should know about: **with `burn_in = 0` it returns `n - 1`
values, not `n`.** That's because `data[-c(1:0)]` drops the first element. It is
not a bug you need to fix — the lab works around it in section 4 by asking for
`n = 201` when it wants 200 dates — but it will surprise you if you set
`burn_in = 0` and count on getting `n` back.

Infinities point at an explosive parameter: if you set $|\phi| > 1$, the series
grows geometrically and overflows to `Inf`. That's the model behaving correctly,
not the code failing.

## Check 3 — a phi = 0.5, alpha = 2 AR(1) has sample mean near 4

**Asserts:** with $\alpha = 2$ and $\phi = 0.5$, the sample mean of a long
simulation lands within 0.15 of $\mu = \alpha/(1-\phi) = 4$.

**Why:** this is the "$\alpha$ sets the level, $\phi$ sets the memory" result
made concrete, and it's the misconception students most reliably arrive with.

**A failure usually means:** `alpha` isn't entering the recursion additively at
each step (for example, being applied only to the initial value), or the
innovations were given a nonzero mean, which folds into the intercept and shifts
$\mu$ without you asking. If you changed `mu` from 0 in the simulator call, this
check is *supposed* to fail — the true long-run mean becomes
$(\alpha + \mu)/(1 - \phi)$.

## Check 4 — random walk spread at t = 200 is far wider than at t = 10

**Asserts:** simulate 500 independent random walks from $y_0 = 0$; the variance
*across paths* at date 200 is more than 8 times the variance at date 10.
(Theory says the ratio is 20.)

**Why:** $\operatorname{Var}(y_t) = t\sigma^2$ is the reason a random walk is
nonstationary, and it is a statement about the **process**, not about any single
path. You cannot see it in one series — you have to look across replications at
a fixed date. That distinction is the conceptual heart of this check.

**A failure usually means:** the simulation is collapsing the replications
somehow (for example, the seed being reset *inside* the `replicate()` call, which
would produce 500 identical paths and a variance of zero at every date). If you
see a ratio near 1, look for accidentally shared randomness. If you see a ratio
around 8 rather than 20, check whether the dates being compared were changed —
the ratio is just $t_{\text{late}}/t_{\text{early}}$.

## Check 5 — independent random walks reject far more than 5% of the time

**Asserts:** 500 regressions of one random walk on an independent one; the
fraction with $p < 0.05$ on the slope exceeds 0.50. It typically comes out near
0.78.

**Why:** the true slope is zero by construction, so a well-calibrated 5% test
should reject about 5% of the time. It doesn't come close. This is the
spurious-regression result and the strongest single argument for why the rest of
the course exists.

**A failure usually means:** the two series stopped being independent random
walks. The classic edit is dropping the `cumsum()`, which leaves two independent
white-noise series — those *do* reject at about 5%, so the check fails and the
result is correct and interesting. Rerun with `cumsum()` restored and compare the
two numbers deliberately; the contrast is the lesson.

A rejection rate near 0.05 with `cumsum()` still in place would be genuinely
strange. Look at whether `n_obs` got very small.

## Check 6 — `data/UNRATE.csv` has the expected columns and its one 2025-10 gap

**Asserts:** the file has columns `observation_date` and `UNRATE`, more than 900
rows, and **exactly one** missing value, at `2025-10-01`.

**Why:** the gap is real data history — a federal data-release interruption — not
file damage. See `data/README.md`. The lab handles it explicitly by truncating at
the gap so the monthly `ts` index stays aligned.

**A failure usually means:** someone "cleaned" the file. If a well-meaning tool
(or tutor) dropped the `NA` row or interpolated over it, this check fires. Don't
patch the check — restore the file. Silently filling a hole in real data is
exactly the habit this course is trying to train out of you, and the missing
month is a small, safe place to learn that.

If the column names changed, you probably re-downloaded from FRED, which has
altered its CSV header format before. Either rename the columns to match or
update the check and this file together.

---

## If a check fails and you can't work out why

Read the check. It's six lines of base R and it prints the numbers it computed
alongside the target, so the gap between "what we expected" and "what we got" is
right there in the output.

If you're working with an AI tutor, show it the failing line *and* the relevant
source file. "Check 4 fails with ratio 1.0" plus `R/ar1_simulator.R` is a
solvable problem; "my checks fail" is not.
