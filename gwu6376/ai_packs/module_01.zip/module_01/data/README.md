# data/ — Cached data for the Module 1 lab

This folder holds a cached FRED pull so the lab runs **without an API key and
without an internet connection**. That is a binding constraint on all course
materials, not a convenience: everything in this pack must work offline.

The lab shows you the live `fredr` pull too (in `R/fetch_fred.R` and Exploration 5),
so you can see how the data is actually obtained — but nothing requires you to
run it.

| File | FRED series | Description | Coverage |
|---|---|---|---|
| `UNRATE.csv` | `UNRATE` | U.S. civilian unemployment rate, monthly, seasonally adjusted, percent | 1948-01 through 2026-04 |

Copied from the course repository's shared `data/UNRATE.csv` on 2026-08-14.

## Column layout

Two columns, following the FRED CSV export format:

```
observation_date,UNRATE
1948-01-01,3.4
1948-02-01,3.8
```

`observation_date` is the first day of the month the observation refers to. It is
read in as text and converted with `as.Date()` in the lab.

## The one missing value — leave it alone

**`2025-10-01` has a blank `UNRATE` value.** This is a federal data-release gap,
not a corrupted file and not a mistake. The observation genuinely does not exist.

The lab handles it explicitly: a monthly `ts` object cannot carry a hole without
its date index silently going wrong, so the lab keeps the complete run from
1948-01 up to the month before the gap (933 observations, ending 2025-09) and
says so in a comment.

`R/checks.R` asserts that the gap is still there. If a tool or a well-meaning AI
tutor "cleans" the file by dropping the row or interpolating across it, that
check fails on purpose. **Restore the file rather than patching the check.**

Quietly filling holes in real data is a habit worth not developing, and one
missing month in a series you don't have a stake in is a cheap place to practice
noticing.

## Refreshing the cache

Re-run the module's `fredr` pull with a valid `FRED_KEY` in your environment,
write the result here, and update the coverage column above.

## The key rule

**Never commit an API key, or any file containing one, to this folder.** Keys
live in your environment — in `.Renviron` or via `Sys.setenv()` — and are read
with `Sys.getenv("FRED_KEY")`. They never appear in a course file. This pack is
intended to be publishable.

Get a free FRED key at <https://fred.stlouisfed.org/docs/api/api_key.html>.
