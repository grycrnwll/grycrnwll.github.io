# Using AI Well in This Course

**Econ 6376 — Module 1**

This is written for you, not for the assistant. It's about getting real value out
of an AI tutor instead of the appearance of value.

---

## The short version

AI is extraordinarily good at the things that used to waste your time in a course
like this — debugging R, explaining notation, generating variations of a
simulation, answering the question you were embarrassed to ask in class. Use it
for all of that, freely.

It is much less good at the thing this course actually grades: *judgment about
ambiguous evidence*. Whether $\hat\phi = 0.97$ means "persistent but stationary"
or "unit root" is not a fact to be retrieved. It's a call you make and defend.

Use AI to build the judgment. Don't use it to skip the judgment.

---

## Productive uses

- **Debugging.** "This chunk errors, here's the message." Get the fix, move on. Don't romanticize struggling with a missing comma.
- **Explaining notation.** "Why is $\Phi(L)$ written with minus signs when $\Theta(L)$ uses plus signs?" This is exactly the kind of thing a textbook assumes you'll absorb by osmosis and you won't.
- **Generating variations.** "Show me the same simulation with $\phi = -0.7$." Cheap, fast, and the fastest route to intuition about a parameter.
- **Being challenged.** "I think a slowly decaying ACF proves there's a unit root. Push back on me." Asking to be argued with is the single highest-value prompt in this course.
- **Rubber-ducking.** Explain your reasoning to the AI and let it find the hole. You'll often find it yourself mid-sentence.
- **Chasing tangents.** "Does this break if the shocks aren't normal?" Turn it into a simulation and find out. Your tutor is instructed to help you do this rather than steer you back to the syllabus.
- **Translating textbooks.** Paste a confusing passage from Enders and ask it to reconcile the notation with the course's. See `TEXTBOOK_MAP.md`.

## Unproductive uses

- **Asking for the interpretation before you've formed one.** "What does this ACF mean?" gets you a fluent paragraph you'll forget. Form a view first, then ask it to critique yours. The order matters more than it sounds like it should.
- **Accepting numbers you didn't verify.** LLMs produce confident, plausible, wrong arithmetic. Especially on things like "what's $0.9^{24}$" or "what's the variance of this process."
- **Letting it write your log.** See below.
- **Using it as a search engine for the answer to a graded question.** Permitted, but see the section on assessed work — it doesn't work as well as it feels like it should.
- **Never disagreeing with it.** If you've gone ten sessions without once finding the AI wrong, you aren't checking. It is wrong regularly on this material.

---

## Verification habits

The pack is built so you never have to take anyone's word for anything — mine, or
your tutor's.

**Test claims in R.** Almost every claim in Module 1 is checkable in five lines.
"Shocks decay as $\phi^k$" — simulate it. "The variance of a random walk grows
with $t$" — simulate 500 of them and measure. If your tutor asserts something
about this material and you can't immediately see how to test it, ask it to write
the test.

**Use `R/checks.R` as a referee.** It holds six assertions about things this
module claims are true, in readable base R. Run `Rscript R/checks.R` any time. If
something you were told contradicts a passing check, the check wins.

**Watch for these specific failure modes.** In my experience they're the common
ones on this material:

- Confusing $\epsilon_t$ and $e_t$, or dropping hats off estimates.
- Using the characteristic-root-*inside* convention without saying so (Enders' framing, not ours) — the answer is right, the framing collides with your notes.
- Claiming a random walk "has an ACF of 1." It has no stationary theoretical ACF at all. The *sample* correlogram starts high and decays slowly, which is a different statement.
- Overstating what a plot proves. If the answer sounds more certain than the evidence, it probably is.
- Arithmetic on powers and variances. Check it.

**A good habit:** when the AI tells you something surprising, ask "how would I
check that in R?" before asking anything else. If it can't propose a check, be
suspicious of the claim.

---

## Graded work

**AI assistance is permitted on every graded deliverable in this course** —
problem sets, the take-home midterm, and the final — **with disclosure.**

Disclosure is a brief, free-form statement of how you used it. No form, no
template, no penalty. It just has to be honest and specific enough to be
meaningful. Two sentences is plenty:

> *I used Claude to debug my `ggplot` code in Question 2 and to check my
> algebra deriving the AR(1) variance in Question 3. The interpretation of the
> UNRATE correlogram in Question 4 is my own, though I asked Claude to argue
> against my first answer before I settled on it.*

That's a complete disclosure. Notice it says what was done *where* — "I used AI"
alone doesn't tell me anything.

Your `LEARNING_LOG.md` is **not** the disclosure vehicle. The log is private and
I never see it. Disclosure goes with the submitted work.

### Why pasting through answers won't carry you

I want to be straightforward about this rather than issue a warning.

The assessments in this course are built to be AI-resilient, and they draw
**only** on the Core tier of the module notes. They ask you to interpret
ambiguous output, reconcile two results that disagree, explain why a method
failed, and defend a judgment call. Those questions don't have retrievable
answers — the evidence is genuinely ambiguous, which is the point, and what gets
graded is the quality of your reasoning about the ambiguity.

An answer you didn't build, you can't defend. That shows up immediately in the
follow-up parts of a question, and it shows up badly on a take-home where you had
plenty of time.

So the policy isn't a trap. Using AI heavily and understanding the material are
completely compatible — that's the intended outcome, and it's how you'll work
professionally. Using AI heavily *instead of* understanding the material is a
strategy that fails at the assessment, and more importantly fails in the job
where nobody tells you which model to fit.

---

## About the contract

`AI_TUTOR_CONTRACT.md` asks your tutor to do things like request a prediction
before running a simulation, and to ask for your own words before writing the
last two fields of your learning log.

The prediction ask pauses for one turn — it will hand you two or three options
and wait once. Answer it, or say "just run it" and it runs immediately and drops
the question. It will not ask you twice, and you can tell it to skip predictions
entirely for the whole session. It's your session.

I'd just say plainly: the contract is there for your benefit, not as a rule
you're being held to. The prediction step exists because being surprised is how
things stick, and skipping it feels efficient in the moment and costs you in
November. Overriding it is a choice you're making about your own learning, and
you're an adult — I only want you making the choice knowingly rather than by
accident.

That's the last I'll say about it.

---

## Intellectual ownership

The point of this course is that you become someone who can take an unfamiliar
series, work out what it is, and defend a modeling decision to a skeptical room.

That capability is built by making predictions, being wrong, and figuring out
why. It is not transferable from a model, and it is not something you can borrow
under deadline. An AI can accelerate every step of building it — and it can also
let you produce work that looks like the finished product without any of the
building having happened.

Both paths are available to you here, and honestly, the second one is easier.
The difference shows up when you're the one in the room who has to say what the
data means.
