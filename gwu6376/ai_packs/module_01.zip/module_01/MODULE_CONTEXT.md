# Module 1 Context — Memory, Noise, and Why Time Order Matters

**Econ 6376 — Applied Time Series Econometrics, George Washington University (Applied Economics MA).**

This file is self-contained. You can paste or upload it on its own into any AI
assistant and it will have everything it needs to help with Module 1.

<!-- BEGIN COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

## Course-wide conventions

These apply to every module of Econ 6376, not just this one.

### The master equation

Every model in this course is the following equation with some terms switched off:

$$y_t = \alpha + \delta t + \sum_{j=1}^{p} \phi_j y_{t-j} + \sum_{l=1}^{q} \theta_l \epsilon_{t-l} + \epsilon_t$$

The course analogy is a **mixing board**: each term is a slider, and each module
turns on new ones. A student should always be able to say where the model in
front of them sits on that board. If they can't, the framing has failed — help
them locate it.

### The cardinal notation rule: DGP vs. estimation

A data-generating process and an estimating equation look different, and the
course is strict about this.

- **DGP (the truth, unobservable):** unhatted parameters $\alpha, \delta, \phi_j, \theta_l, \beta$ and $\epsilon_t$, the **innovation**.
- **Estimating equation (your model, observable):** hatted parameters $\hat\alpha, \hat\phi_j, \hat\theta_l, \hat\beta$ and $e_t$, the **residual**, where $e_t = y_t - \hat y_t$.

Never write $\epsilon_t$ when you mean $e_t$. Never drop a hat from an estimate.
A well-specified model leaves residuals that behave like the innovations that
model assumes — that is the entire basis of diagnostic testing later in the course.

### Other standing conventions

- **Lag polynomials:** AR takes minus signs, $\Phi(L) = 1 - \phi_1 L - \cdots - \phi_p L^p$. MA takes plus signs, $\Theta(L) = 1 + \theta_1 L + \cdots + \theta_q L^q$.
- **Stationarity framing:** all roots of $\Phi(L) = 0$ lie strictly **outside** the unit circle. Enders and the older course slides use the equivalent characteristic-root-**inside** framing (related by $r = 1/L$). Both are correct; flag the difference whenever a student is cross-referencing a textbook.
- **Symbols:** $\phi$ = AR coefficients, $\theta$ = MA, $\beta$ = covariates, $\alpha$ = intercept, $\delta$ = trend. $\gamma_k$ = autocovariance at lag $k$, $\rho_k$ = autocorrelation, $\gamma_0 = \operatorname{Var}(y_t)$. $L$ = lag operator, $\Delta = (1-L)$. $t = 1,\ldots,T$.
- **"Stationary"** means weakly (covariance) stationary unless stated otherwise.
- **Language:** the course is taught in R. Students may submit graded work in another language if they can reproduce the workflow, but help and debugging are R-first. Plots use `ggplot2`.
- **Credentials:** FRED keys come from `Sys.getenv("FRED_KEY")`, never hardcoded, never committed.

### Working rules

- Concept before math, always. Intuition first, then notation.
- Simulation is the center of gravity, and a simulation that only confirms the textbook is half an exercise. Breaking an assumption is where understanding happens.
- The four-step rhythm for any major topic: **Concept → Math → Simulate (break something) → Real Data.**
- The student-facing learning protocol: **Predict → Commit → Ask AI → Test in R → Reconcile.**
- **Core is the assessable surface.** Course notes are tiered (Core / Deeper Dive / Technical Note / Looking Ahead). Problem sets and exams draw **only** on Core. Optional tiers are genuinely optional — never imply otherwise.

<!-- END COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

---

## What Module 1 is about

Module 1 answers one plain-language question: **how much does the past matter?**

Students arrive knowing OLS on cross-sectional data, where row order is
meaningless. This module establishes that when the index becomes time, ordering
carries information, and that ignoring it produces confident nonsense. It ends
by handing an unanswerable question to Module 2 — which is the point.

**On the mixing board, Module 1 turns on exactly two sliders: $\alpha$ and $\phi_1$.**
Everything else ($\delta$, higher AR lags, all MA terms) is off:

$$y_t = \alpha + \phi y_{t-1} + \epsilon_t$$

### Core learning objectives

By the end of the module a student should be able to:

1. Distinguish time-series from cross-sectional and panel data, and explain why time ordering matters.
2. Locate the AR(1) on the master equation.
3. Distinguish an innovation $\epsilon_t$ from a fitted residual $e_t$.
4. Explain "memory" in an AR(1) and connect it to $\phi$.
5. Build and interpret an AR(1) simulator in R.
6. State the three conditions for weak stationarity.
7. Define and interpret autocovariance, autocorrelation, and a correlogram.
8. Explain why a random walk is nonstationary.
9. Use simulation to demonstrate the danger of spurious regression.

---

## Core concepts

**Three data structures.** Cross-sectional $\{y_i, \mathbf{x}_i\}$, $i = 1,\ldots,N$ —
row order usually meaningless. Time series $\{y_t, \mathbf{x}_t\}$, $t = 1,\ldots,T$ —
order is meaningful, shuffling destroys information. Panel $\{y_{it}, \mathbf{x}_{it}\}$ —
both dimensions; not this course's focus. Important nuance: time-series data need
*not* be dependent. White noise is a perfectly valid time series. What defines the
structure is the index, not the dependence.

**The AR(1) and memory.** $y_t = \alpha + \phi y_{t-1} + \epsilon_t$ with
$\epsilon_t \sim WN(0,\sigma^2)$ (simulations use the stronger iid normal
assumption). A unit shock at time $t$ is worth $\phi^k$ at time $t+k$ — that is
the operational meaning of memory.

| $\phi$ | Behavior |
|---|---|
| $0$ | No linear memory; iid around $\alpha$ |
| $0 < \phi < 1$ | Positive persistence; shocks fade without changing sign |
| $-1 < \phi < 0$ | Alternating persistence; effects flip sign as they fade |
| $1$ | Unit root; shocks never decay (random walk) |
| $-1$ | Nondecaying, alternating |
| $|\phi| > 1$ | Explosive |

Concretely: $0.5^{10} \approx 0.001$, $0.9^{10} \approx 0.35$, $0.99^{10} \approx 0.90$,
$1^{10} = 1$.

**$\alpha$ sets level, $\phi$ sets memory.** For a stationary AR(1) the long-run
mean is $\mu = \alpha/(1-\phi)$. Changing $\alpha$ moves the series up or down;
it leaves the theoretical ACF untouched.

**Weak stationarity — three conditions.** (1) $\mathbb{E}[Y_t] = \mu$ for all $t$;
(2) $\operatorname{Var}(Y_t) = \sigma_Y^2 < \infty$ for all $t$;
(3) $\operatorname{Cov}(Y_t, Y_{t-k}) = \gamma_k$ depends on $k$ only, not on $t$.
Stationarity does *not* mean the series is flat — it means the probabilistic rules
generating the fluctuations don't change with calendar time.

**Stationary AR(1) moments** (for $|\phi| < 1$): $\mu = \alpha/(1-\phi)$,
$\gamma_0 = \sigma^2/(1-\phi^2)$, $\gamma_k = \phi^k \gamma_0$.

**Autocovariance and the ACF.** $\gamma_k = \mathbb{E}[(Y_t - \mu)(Y_{t-k} - \mu)]$;
$\rho_k = \gamma_k/\gamma_0$, so $\rho_0 = 1$ and $|\rho_k| \le 1$. The headline
Module 1 result:

$$\rho_k = \phi^k \quad \text{for a stationary AR(1).}$$

A correlogram plots $\hat\rho_k$ against $k$. Its dashed bands sit at
$\pm 1.96/\sqrt{T}$ — approximate, individual-lag reference lines under an iid
white-noise null. They are not a confidence band for a persistent process and
carry no multiple-comparison correction; one crossing among 24 lags is unremarkable.

**The random walk.** $\phi = 1$, so $Y_t = Y_0 + \sum_{i=1}^t \epsilon_i$. With
fixed $Y_0$, $\mathbb{E}[Y_t] = Y_0$ and $\operatorname{Var}(Y_t) = t\sigma^2$ —
finite at every date but time-varying and unbounded. Conditions 1 and 2 fail, so
there is no stationary theoretical ACF. Adding an intercept gives a random walk
with drift, $Y_t = Y_0 + \alpha t + \sum \epsilon_i$.

**Spurious regression.** Regress one random walk on an independent one and
conventional OLS output reports a large $R^2$ and a tiny $p$-value roughly 75% of
the time at a nominal 5% level (Granger and Newbold, 1974). The reason is not
"they both trend": the regressor and disturbance are integrated, sample
cross-products accumulate rather than average out shocks, and the normalization
behind the conventional $t$ statistic no longer applies — the statistic diverges
instead of converging to a standard normal. So **more data makes it worse**.
Phillips (1986) is the formal treatment. The critical exception is
**cointegration**: if a linear combination of nonstationary series is stationary,
the levels relationship can be genuine. Never let a student walk away with "always
difference everything."

**The Module 1 → Module 2 handoff.** Real unemployment data has $\hat\phi \approx 0.97$.
A plot and an ACF cannot distinguish a highly persistent stationary process from a
unit root, from structural breaks, from nonlinear mean reversion. That ambiguity
is deliberate and unresolved — it is exactly why formal unit-root testing exists.
If the student asks for later-module machinery (a unit-root test, an ARMA fit),
build it on request and flag it as a preview of the module it belongs to — do not
deflect them back to Module 1.

---

## Vocabulary

Innovation ($\epsilon_t$) · residual ($e_t$) · white noise · weak/covariance
stationarity · strict stationarity · realization (sample path) · stochastic
process · memory · persistence · autocovariance ($\gamma_k$) · autocorrelation
($\rho_k$) · correlogram / ACF · lag operator ($L$) · difference operator ($\Delta$)
· burn-in · unit root · random walk (with and without drift) · spurious regression
· cointegration (preview) · MA($\infty$) representation · order of integration (preview).

---

## Common misconceptions

Correct these when they appear, but correct them by asking a question or running
something, not by lecturing.

1. **"Stationary means the series doesn't move."** It means the probabilistic properties are stable. A stationary series can swing wildly.
2. **"All time series are dependent."** No — white noise is a time series. Dependence is common and usually why we care, but it isn't part of the definition.
3. **"A persistent outcome means every regression on it has serially correlated errors."** Different claims. Persistence in $Y_t$ and serial correlation in a particular model's error are not the same thing.
4. **"The intercept controls memory."** No: $\alpha$ sets $\mu = \alpha/(1-\phi)$; $\phi$ alone controls the ACF and shock propagation. Three series with the same $\phi$ and different $\alpha$ share an ACF.
5. **"$\epsilon_t$ and $e_t$ are interchangeable."** Never. DGP innovation vs. fitted residual. The residual is a sample-dependent approximation whose quality depends on the model.
6. **"$\phi = 0.99$ and $\phi = 1$ are basically the same."** They look alike in short samples and are qualitatively different: at 0.99 shocks eventually decay and a stationary distribution exists; at 1 neither is true.
7. **"A slowly decaying sample ACF proves a unit root."** It is evidence of persistence, not a verdict. That is what Module 2's tests are for.
8. **"A random walk has infinite variance."** With fixed $Y_0$ its variance is $t\sigma^2$: finite at each date, time-varying, unbounded as $t$ grows. The *stationary* variance formula simply doesn't apply at $\phi = 1$.
9. **"High $R^2$ means the relationship is real."** Not with persistent series — that is the whole spurious-regression lesson.
10. **"Any regression involving nonstationary variables is spurious."** Cointegration is the principal exception; deterministic components and full specification matter too.
11. **"Stationary variables make ordinary `lm()` p-values automatically valid."** No. Stationary serial correlation still calls for a dynamic model or dependence-robust standard errors.
12. **"Burn-in fixes a random walk."** It cannot. There is no stationary distribution to settle into; discarding a prefix just relabels which stretch of the same wandering path you're looking at.

## Two subtleties worth getting right

- **Uncorrelated is not independent.** Weak white noise only requires zero autocovariance. A series can be serially uncorrelated and still dependent through higher moments — conditional heteroskedasticity is the standard example, and the course returns to it with ARCH/GARCH.
- **Stationarity alone doesn't justify inference.** Consistency of sample moments generally also needs an ergodicity or weak-dependence condition. Stationarity is part of the standard toolkit, not a spell that makes one realization equivalent to many independent samples.
