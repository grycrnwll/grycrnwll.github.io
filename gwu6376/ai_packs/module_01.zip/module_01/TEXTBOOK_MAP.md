# Textbook Map — Module 1

Where Module 1's concepts live in the three books students most often read
alongside this course, and how to translate the notation when you get there.

**This file contains pointers and translations only — no textbook text.** If you
want to know what Enders *says*, read Enders. What this file does is get you to
the right pages and stop the notation from tripping you.

**How to read the pointers.** Page ranges are the ones used elsewhere in this
course's own notes, for the editions listed below. Where this course has never
pinned a page down, the pointer is at chapter level and says so. Nothing here is
guessed at the page level — if you find a discrepancy with your copy, trust your
copy and tell me.

**Editions assumed:** Enders, *Applied Econometric Time Series*, 4th ed.
Hamilton, *Time Series Analysis* (1994). Hyndman & Athanasopoulos, *Forecasting:
Principles and Practice*, 3rd ed., free online at <https://otexts.com/fpp3/>.

---

## Part A — Concept pointers

### Time-series data, and why ordering matters

| Book | Where |
|---|---|
| Enders | Ch. 1 — difference equations, pp. 1–46. The framing is mathematical rather than data-structural; Enders assumes you already accept that time order matters and gets on with the algebra. |
| Hamilton | Ch. 3 — the formal treatment of stochastic processes. |
| fpp3 | The "Time series graphics" chapter. Closest to this module's plain-language framing of what a time series *is*. |

### The AR(1), memory, and $\phi$

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 47–52 (stochastic difference equations) and pp. 48–60 (AR(p) processes and stationarity conditions). This is the main landing site for Module 1. |
| Hamilton | Ch. 3 — stationary processes, including the AR(1) as a special case. Considerably more formal than you need. |
| fpp3 | The "ARIMA models" chapter (Ch. 9) covers autoregressive models from the forecasting-workflow angle. |

### Weak stationarity

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 48–60, alongside the AR(p) stationarity conditions. |
| Hamilton | Ch. 3 — the authoritative statement of covariance stationarity for this course's purposes. |
| fpp3 | The "ARIMA models" chapter (Ch. 9), in its stationarity-and-differencing material. **Caution:** fpp3 states stationarity in the *strict* form, which is stronger than the weak/covariance definition this course uses. The practical guidance is compatible; the definitions are not identical. |

### Autocovariance, the ACF, and the correlogram

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 60–66 — the ACF of AR(p) processes. (This is where the Yule-Walker algebra lives, which Module 3 will need and Module 1 does not.) |
| Hamilton | Ch. 3, extending into Ch. 4 for the fuller ACF/PACF treatment. |
| fpp3 | The "Time series graphics" chapter, in its autocorrelation and white-noise sections — the most practical treatment of reading a correlogram of the three. |

### The random walk and nonstationarity

| Book | Where |
|---|---|
| Enders | Ch. 4, pp. 181–189 (order of integration and trends) and pp. 189–200 (trend-stationary versus difference-stationary). Both are formally Module 2 territory, but they are where the random walk is developed properly. |
| Hamilton | Ch. 17 — univariate processes with unit roots. This is the rigorous asymptotic reference and it is genuinely hard; Module 2 is the right time for it, not Module 1. |
| fpp3 | The "ARIMA models" chapter (Ch. 9), differencing and unit-root testing sections. |

### Spurious regression

| Book | Where |
|---|---|
| Enders | Ch. 4 — chapter level only. The Module 1 notes cite "the discussion of spurious regression" without a page number, and this course's planning documents place the topic in Ch. 4 alongside unit roots. Find it via the index entry for *spurious regression*. |
| Hamilton | Ch. 17–18 — chapter level only, and well beyond Module 1's requirements. |
| Primary sources | Granger, C. W. J. and Newbold, P. (1974), "Spurious Regressions in Econometrics," *Journal of Econometrics* 2: 111–120. Phillips, P. C. B. (1986), "Understanding Spurious Regressions in Econometrics," *Journal of Econometrics* 33: 311–340. The Granger and Newbold paper is short and very readable — worth an hour. |

### The lag operator and difference operator

| Book | Where |
|---|---|
| Enders | Ch. 1, pp. 1–46 — difference operators and difference equations. |
| Hamilton | Ch. 2 — chapter level; Hamilton devotes a full chapter to lag operators and it is the cleanest treatment of the three. |
| fpp3 | Treated informally within the "ARIMA models" chapter rather than developed on its own. |

### Optional-tier topics, if you went there

- **MA($\infty$) representation and the Wold decomposition:** Enders Ch. 1, Appendix 1.1, and Ch. 2, pp. 51–55.
- **Strict vs. weak stationarity:** Hamilton Ch. 3.
- **Also useful:** Cryer, J. D. and Chan, K.-S., *Time Series Analysis: With Applications in R*, Chapters 1–2 — the gentlest of the R-based treatments of this material. Shumway & Stoffer, *Time Series Analysis and Its Applications with R* (3rd ed.), is a further R-oriented reference.

---

## Part B — Notation translation

Same mathematics, different alphabets. This is where most cross-referencing
confusion comes from.

Cells marked **(verify)** are conventions this course has not documented
explicitly — they match the common usage in those texts, but check your copy
before relying on one. Unmarked cells are conventions stated in this course's own
materials.

| Concept | This course | Enders | Hamilton |
|---|---|---|---|
| Series | $y_t$ | $y_t$ | $y_t$ |
| Intercept | $\alpha$ | $a_0$ | $c$ (verify) |
| AR coefficient, lag $j$ | $\phi_j$ | $a_j$ | $\phi_j$ |
| MA coefficient, lag $l$ | $\theta_l$ | $\beta_l$ (verify) | $\theta_l$ |
| Innovation | $\epsilon_t$ | $\epsilon_t$ | $\epsilon_t$ |
| Residual | $e_t$ | not systematically distinguished (verify) | not systematically distinguished (verify) |
| Autocovariance at lag $k$ | $\gamma_k$ | $\gamma_s$ (verify) | $\gamma_j$ (verify) |
| Autocorrelation at lag $k$ | $\rho_k$ | $\rho_s$ (verify) | $\rho_j$ (verify) |
| AR polynomial | $\Phi(L) = 1 - \phi_1 L - \cdots$ | writes the characteristic equation instead | same minus-sign convention |
| MA polynomial | $\Theta(L) = 1 + \theta_1 L + \cdots$ | same plus-sign convention | same plus-sign convention |
| Stationarity condition | roots of $\Phi(L) = 0$ **outside** the unit circle | characteristic roots **inside** the unit circle | roots **outside** the unit circle (same as this course) |

### The three that actually cause problems

**1. Enders writes $a_1$ where we write $\phi_1$.** He states the AR(1) as
$y_t = a_0 + a_1 y_{t-1} + \epsilon_t$. His $a_0$ is our $\alpha$ and his $a_1$
is our $\phi$. Purely cosmetic, but it derails people mid-derivation.

**2. Enders uses the characteristic-root-*inside* framing.** This course says
stationarity requires the roots of $\Phi(L) = 0$ to lie **outside** the unit
circle; Enders says the characteristic roots must lie **inside** it. These are
the *same condition* — the roots are reciprocals, related by $r = 1/L$. For the
AR(1) both reduce to $|\phi| < 1$. Neither book is wrong, and mixing the two
framings mid-problem produces an answer that is exactly backwards. Hamilton uses
our framing.

**3. Nobody but this course is strict about $\epsilon_t$ versus $e_t$.** Most
texts use $\epsilon_t$ (or $e_t$, or $u_t$) for both the DGP innovation and the
fitted residual and rely on context. This course separates them deliberately,
because the entire logic of diagnostic testing is "does $e_t$ behave the way the
model's assumed $\epsilon_t$ should?" — a question you cannot even phrase if the
two share a symbol. When reading any of these books, work out from context which
object is meant.

**One more, for when you get to Module 3:** Box, Jenkins and Reinsel write the MA
polynomial with *minus* signs, so their $\theta$ is the negative of ours. Enders
and Hamilton agree with us. Not a Module 1 issue, but worth knowing before you
pick up a fourth book.
