# Stamped copy of ar1_simulator() from helpers/simulators.R in the Econ 6376 course repo — behavior unchanged; edits belong in the canonical file.

ar1_simulator <- function(
    n = 100, alpha = 0, phi = 0,
    init = 0, mu = 0, sigma = 1,
    start_date = c(1955, 11), frequency = 12,
    burn_in = 100) {
  # Simulate an AR(1) process: y_t = alpha + phi * y_{t-1} + eps_t
  #
  # Arguments:
  #   n          : number of observations to return
  #   alpha      : intercept
  #   phi        : AR(1) coefficient
  #   init       : initial value (washed out by burn-in)
  #   mu         : mean of innovations
  #   sigma      : standard deviation of innovations
  #   start_date : c(year, month) for the ts object
  #   frequency  : ts frequency (12 = monthly, 4 = quarterly)
  #   burn_in    : observations to simulate and discard
  #
  # Returns:
  #   A ts object of length n.

  data <- rep(0, (burn_in + n))
  data[1] <- init
  for (t in 2:(burn_in + n)) {
    data[t] <- alpha + phi * data[t - 1] + rnorm(1, mu, sigma)
  }
  data <- ts(data[-c(1:burn_in)],
             start = start_date, frequency = frequency)
  return(data)
}
