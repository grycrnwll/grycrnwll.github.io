# =============================================================================
# checks.R — the referee for the Module 1 AI Learning Pack (Econ 6376)
#
# Six assertions about things Module 1 claims are true. Base R only.
# Run it from the pack root:   Rscript R/checks.R
# Each check prints one PASS/FAIL line. Any FAIL exits with a nonzero status.
#
# This file is deliberately readable. If your AI tutor tells you something that
# contradicts one of these checks, the check wins — or one of you has found a
# real bug, which is more interesting. Either way, read the code, don't guess.
# CHECKS.md explains what each check means and what a failure usually points to.
# =============================================================================

source("R/ar1_simulator.R")

# ---- tiny test harness ------------------------------------------------------
# Results accumulate here so one failure doesn't hide the checks after it.
results <- logical(0)

check <- function(label, passed, detail = "") {
  passed <- isTRUE(passed)
  results[[length(results) + 1L]] <<- passed
  cat(sprintf("%-4s %s%s\n",
              if (passed) "PASS" else "FAIL",
              label,
              if (nzchar(detail)) paste0("  [", detail, "]") else ""))
  invisible(passed)
}

lag1_acf <- function(x) stats::acf(x, lag.max = 1, plot = FALSE)$acf[2]

cat("Module 1 checks\n---------------\n")


# ---- 1. phi is the lag-1 autocorrelation ------------------------------------
# Module 1's headline result is rho_k = phi^k for a stationary AR(1).
# At k = 1 that says: the lag-1 sample ACF of a long phi = 0.5 run lands near 0.5.
set.seed(6376)
y_half <- ar1_simulator(n = 20000, alpha = 0, phi = 0.5, sigma = 1, burn_in = 500)
acf1 <- lag1_acf(y_half)
check("rho_1 of a phi = 0.5 AR(1) is close to 0.5",
      abs(acf1 - 0.5) < 0.05,
      sprintf("sample rho_1 = %.4f, target 0.500, tol 0.05", acf1))


# ---- 2. the simulator honors its contract -----------------------------------
# ar1_simulator() promises a ts object of length n with no missing values.
# Everything downstream assumes this, so it is worth asserting once out loud.
set.seed(6376)
y_contract <- ar1_simulator(n = 500, alpha = 0, phi = 0.9, sigma = 1, burn_in = 200)
contract_ok <- is.ts(y_contract) &&
  length(y_contract) == 500 &&
  !anyNA(y_contract) &&
  all(is.finite(y_contract))
check("ar1_simulator(n = 500, burn_in = 200) returns 500 finite values as a ts",
      contract_ok,
      sprintf("class = %s, length = %d, NAs = %d",
              paste(class(y_contract), collapse = "/"),
              length(y_contract), sum(is.na(y_contract))))


# ---- 3. alpha sets the level, phi sets the memory ---------------------------
# For a stationary AR(1) the long-run mean is mu = alpha / (1 - phi).
# With alpha = 2 and phi = 0.5 that is 4, and the sample mean should find it.
set.seed(6376)
y_level <- ar1_simulator(n = 20000, alpha = 2, phi = 0.5, sigma = 1, burn_in = 500)
mu_target <- 2 / (1 - 0.5)
check("a phi = 0.5, alpha = 2 AR(1) has sample mean near alpha/(1 - phi) = 4",
      abs(mean(y_level) - mu_target) < 0.15,
      sprintf("sample mean = %.4f, target %.3f, tol 0.15", mean(y_level), mu_target))


# ---- 4. a random walk's variance grows with t -------------------------------
# Var(Y_t) = t * sigma^2 is the reason a random walk is not stationary, and it
# is a statement about the PROCESS, not about one path. So we simulate many
# paths and measure the spread ACROSS them at an early date and a late date.
# Note: with burn_in = 0 the simulator returns n - 1 values, so n = 201 gives
# 200 rows — one row per date t = 1, ..., 200.
set.seed(6376)
n_paths <- 500
rw_paths <- replicate(
  n_paths,
  as.numeric(ar1_simulator(n = 201, alpha = 0, phi = 1, init = 0,
                           sigma = 1, burn_in = 0))
)
var_early <- var(rw_paths[10, ])   # theory: 10
var_late  <- var(rw_paths[200, ])  # theory: 200
check("random walk spread at t = 200 is far wider than at t = 10",
      var_late > 8 * var_early,
      sprintf("var(y_10) = %.1f, var(y_200) = %.1f, ratio = %.1f (theory 20)",
              var_early, var_late, var_late / var_early))


# ---- 5. spurious regression rejects far too often ---------------------------
# Two INDEPENDENT random walks. The true slope is zero, so a well-calibrated
# 5% test should reject about 5% of the time. It does not come close.
set.seed(42)
n_sims <- 500
n_obs  <- 100
reject_rate <- mean(replicate(n_sims, {
  x <- cumsum(rnorm(n_obs))
  y <- cumsum(rnorm(n_obs))
  coef(summary(lm(y ~ x)))["x", "Pr(>|t|)"] < 0.05
}))
check("independent random walks reject at 5% far more than 5% of the time",
      reject_rate > 0.50,
      sprintf("rejection rate = %.3f, nominal 0.05, floor for this check 0.50",
              reject_rate))


# ---- 6. the cached UNRATE file is the one we documented ---------------------
# Including the single missing month. The gap is real data history, not damage:
# see data/README.md. If it disappears, someone "cleaned" the file.
unrate_raw <- read.csv("data/UNRATE.csv", stringsAsFactors = FALSE)
na_rows <- which(is.na(unrate_raw$UNRATE))
cache_ok <- identical(names(unrate_raw), c("observation_date", "UNRATE")) &&
  nrow(unrate_raw) > 900 &&
  length(na_rows) == 1L &&
  identical(unrate_raw$observation_date[na_rows], "2025-10-01")
check("data/UNRATE.csv has the expected columns and its one 2025-10 gap",
      cache_ok,
      sprintf("columns = %s, rows = %d, NAs = %d at %s",
              paste(names(unrate_raw), collapse = "+"),
              nrow(unrate_raw), length(na_rows),
              if (length(na_rows) == 1L) unrate_raw$observation_date[na_rows] else "-"))


# ---- verdict ----------------------------------------------------------------
n_pass <- sum(results)
n_all  <- length(results)
cat(sprintf("---------------\n%d/%d checks passed.\n", n_pass, n_all))

# Exit nonzero on failure when run from the command line. Inside a Quarto
# render, knitr sets knitr.in.progress, and we only print — killing the R
# session mid-render would be a very rude way to report a failing check.
if (n_pass < n_all && !isTRUE(getOption("knitr.in.progress"))) {
  quit(status = 1, save = "no")
}
