# What the Checks Check

`R/checks.R` holds seven assertions about things Module 6 claims are true. Run it
from the pack root at any time:

```
Rscript R/checks.R
```

Each check prints one `PASS` or `FAIL` line with the numbers it computed. Any
failure makes the script exit with a nonzero status, so it works in a script as
well as by hand. The last chunk of the lab runs it too — inside a Quarto render
it prints its results without killing the render.

**This is not an answer key.** The checks confirm that the *code and data* behave
the way the module says they do. They cannot tell you whether your reading of a
scoreboard is any good, and they don't try. They exist so that when you and an
AI tutor disagree about a fact, there's a referee neither of you controls.

The file is plain base R: it fits with `stats::arima()` and builds the
Dickey-Fuller regression with `lm()`, so it needs none of `forecast`, `urca` or
`ggplot2`, even though the lab uses all three. If a check confuses you, read
it — each one is a short block, and the whole script takes a couple of seconds.

---

## Check 1 — the data are the data

**Asserts:** `A939RX0Q048SBEA.csv` has its two columns, 318 quarterly rows from
1947 Q1 to 2026 Q2 with no gaps, and the last value 71,212 that marks the
September 30, 2026 vintage; the training window 1990 Q1 to 2006 Q4 has 68
quarters, with growth averaging 1.871% a year (within 0.005) and a standard
deviation of 0.5357% a quarter (within 0.001). `UNRATE.csv` keeps its two
columns and its single known blank at 2025-10-01, and 1960–2019 is 720 months.

**Why:** every number in the lab descends from these two files, and national
accounts get revised. A refreshed GDP file would quietly change the fits, the
test-set scores and the band; the last-value test is how the change announces
itself.

**A failure usually means:** a data file was refreshed or edited. Refreshing is
fine; update `data/README.md` and the lab's numbers with it rather than loosening
the check.

## Check 2 — the ADF statistic is the full-sample one

**Asserts:** the Dickey-Fuller regression built by hand with `lm()` — $\Delta y_t$
on $y_{t-1}$, $k$ lagged differences, a constant and (for the trend version) a
time trend — gives $\tau = -3.113$ (within 0.005) on the log level with $k = 2$
and a trend, using all 65 usable rows; and $\tau = -3.833$ on the growth rate
with $k = 1$ and a drift.

**Why:** these are the two numbers section 2's verdict rests on, and the
statistic is sensitive to *which rows* the regression uses. `urca`'s
`selectlags` option trims the sample to the longest lag it considered, and with
68 quarters that moves the same two-lag statistic from $-3.11$ to about $-1.9$.
The check pins the full-sample convention the course uses.

**A failure usually means:** the window moved, or the regression lost or gained
rows (a common edit: building the lagged differences off by one).

## Check 3 — the recursion is the closed form

**Asserts:** for an AR(1) with $\phi = 0.7$, $\mu = 0$ and $y_T = 1$, the point
recursion run as a loop equals $\phi^h$ for $h = 1, \ldots, 8$ to $10^{-12}$;
the variance recursion equals $(1 - \phi^{2h})/(1 - \phi^2)$; and the explained
shares $\phi^{2h}$ at $h = 1, 2, 4, 8$ are 0.49, 0.2401, 0.0576 and 0.0033.

**Why:** section 4's two replacement rules and section 5's variance formula are
the whole mechanism behind `forecast()`. Seeing the loop match the formula once
is what lets you trust the package every other time.

**A failure usually means:** the loop was edited (a common one: forgetting that
the variance sum starts at $\psi_0 = 1$).

## Check 4 — the finalists are pinned

**Asserts:** `stats::arima()` fitted to the growth rate gives a log-likelihood
within 0.01 of 260.816 for AR(2) with a mean and 258.998 for AR(1) with a mean,
with $\hat\phi$ within 0.005 of $(0.232, 0.233)$ and $0.301$.

**Why:** the lab fits `forecast::Arima(y, order = c(p, 1, 0), include.drift =
TRUE)` on the log level. That is the same model as an AR($p$) with a mean on
the growth rate, and the two routes agree on the coefficients to $10^{-5}$ and
on the log-likelihood to about 0.002. One convention differs and is worth
knowing: `forecast` reports a $\hat\sigma^2$ corrected for degrees of freedom
and including the first, diffuse residual (0.521% a quarter for the ARIMA(2,1,0)),
where `stats::arima()` reports the maximum-likelihood value (0.493%). The
test-set coverage count in check 5 is the same under either.

**A failure usually means:** the window changed, or the model orders were
edited.

## Check 5 — the test-set score is pinned

**Asserts:** one-step forecasts of growth for 2007 Q1 to 2011 Q4 from the AR(2)
recursion with the coefficients frozen at the training fit have an RMSE within
0.005 of 0.767 (percent per quarter); the random walk with drift, which forecasts
the training mean every quarter, has an RMSE within 0.005 of 0.932; and the
AR(2)'s 95% band, $\pm 1.96\hat\sigma$, catches 18 of the 20 realised quarters.

**Why:** this is the scoreboard the module's one real-data test rests on. The lab
computes it through `forecast()`'s Kalman filter; the check recomputes it from
the hand recursion of section 4, so the two routes have to agree.

**A failure usually means:** the data file was refreshed (every 2007–2011 value
is subject to revision), or the recursion was edited so that it no longer
starts from the last two *observed* growth rates.

## Check 6 — the loss functions behave

**Asserts:** `huber()` from `R/forecast_utils.R` equals $\tfrac12 e^2$ for
$|e| \le \delta$ and $\delta(|e| - \tfrac12\delta)$ beyond, to $10^{-12}$;
`asym_loss()` at $\alpha = 0.5$ is exactly half the MAE; and on a fixed skewed
sample a grid search finds the constant that minimises mean squared error at the
sample mean and the one that minimises mean absolute error at the sample median.

**Why:** section 9's claim that "the loss picks the target" is only as good as
the loss functions you score with. The grid search is the finite-sample version
of the theorem: MSE optimises the mean, MAE the median.

**A failure usually means:** a loss function in `R/forecast_utils.R` was edited
(the sign convention in `asym_loss()` — $e > 0$ is under-prediction — is the
usual casualty).

## Check 7 — Gaussian coverage is Gaussian

**Asserts:** over 2,000 one-step draws from a known AR(1) with Gaussian shocks,
the band $\hat y_{T+1|T} \pm 1.96\sigma$ contains $y_{T+1}$ between 93% and 97%
of the time.

**Why:** section 8 breaks the Gaussian assumption and watches the band fail. A
band you have never seen *succeed* on data that meet its assumptions is a band
you are taking on faith; this is the control.

**A failure usually means:** the seed or the draw was changed. With 2,000 draws
the coverage has a standard error of half a point, so landing outside a
two-point window is almost never bad luck.

---

## If a check fails and you can't work out why

Read the check. It's a few lines of base R and it prints the numbers it computed
alongside the target, so the gap between "what we expected" and "what we got" is
right there in the output.

If you're working with an AI tutor, show it the failing line, your R version,
*and* the relevant file. "Check 5 fails — RMSE is 0.81" plus
`data/A939RX0Q048SBEA.csv`'s last few rows is a solvable problem; "my checks
fail" is not.
