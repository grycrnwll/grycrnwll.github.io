# Textbook Map — Module 6

Where Module 6's ideas live in the books you are most likely to read alongside
this course, and how to translate the notation when you get there.

**This file contains pointers and translations only — no textbook text.** If you
want to know what Enders *says*, read Enders. What this file does is get you to
the right pages and stop the notation from tripping you.

**How to read the pointers.** Page ranges are the ones this course's own notes
use (this module's "Connection to Enders" section, and the Module 2, 3 and 4
notes for the parts of the lab that revisit those modules), for the editions
listed below. Where the notes only name a chapter, the pointer stays at chapter
level. Nothing is guessed at the page level — if your copy disagrees, trust
your copy and tell me. Cells marked **(verify)** are locations the course's
notes nowhere pin down; check your copy before relying on one.

**Editions assumed:** Enders, *Applied Econometric Time Series*, 4th ed.
Hamilton, *Time Series Analysis* (1994). Hyndman & Athanasopoulos, *Forecasting:
Principles and Practice*, 3rd ed. (fpp3), free online at <https://otexts.com/fpp3/>.

---

## Part A — Concept pointers

### Forecasting with ARMA models: the recursion and the conditional mean

Why the point forecast is a conditional expectation, and how to compute it
step by step.

| Book | Where |
|---|---|
| Enders | Ch. 2, §9 ("Properties of Forecasts"), pp. 79–83. The main landing site for sections 3–4 of the lab. |
| Hamilton | Ch. 4, §4.1: the conditional mean as the MSE-optimal forecast, including the restriction to linear forecasts. The rigorous version of the lab's one-line "why". |
| fpp3 | Ch. 9 (ARIMA models), the forecasting material — chapter level. |

### Forecast errors, forecast-error variance, and Gaussian prediction intervals

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 80–81. |
| Hamilton | Ch. 4, §4.3: the forecast-error variance with the full matrix algebra. |
| fpp3 | Ch. 9, the ARIMA forecasting material; prediction intervals in general in Ch. 5 **(verify section)**. |

### The Wold decomposition and the $\psi$-weights

The MA($\infty$) representation the variance formula rests on.

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 51–55 (this module's pointer); pp. 77–78 for the applied invertible-MA-to-AR($\infty$) direction (Module 3's pointer). |
| Hamilton | Ch. 4, §4.8, pp. 108–109 — Wold's theorem in its precise form, deterministic component included (Module 3's pointer). |
| fpp3 | Not developed as such; applied ARIMA representations in Ch. 9 **(verify)**. |

### Train/test splits, rolling-origin evaluation, and accuracy measures

Loss functions, why random splits are wrong, and the `forecast` workflow.

| Book | Where |
|---|---|
| fpp3 | Ch. 5 (evaluating forecast accuracy, including MASE) — the course's main reference here; time-series cross-validation lives in the same chapter **(verify section)**. |
| Enders | Ch. 2, pp. 82–87 (Module 4's out-of-sample pointer). Loss functions beyond squared error are not an Enders topic **(verify)**. |
| Hamilton | Not a source for applied forecast evaluation **(verify)**. |
| Original | Hyndman & Koehler (2006) for MASE, the scale-free benchmark ratio previewed in the notes for Module 7. |

### Coverage under non-Gaussian innovations; bootstrap prediction intervals

| Book | Where |
|---|---|
| fpp3 | Bootstrapped prediction intervals are in Ch. 5 **(verify section)**; the course does not develop them beyond one line. |
| Enders, Hamilton | No location pinned by the course notes **(verify)**. The coverage Monte Carlo is the course's own. |

### Unit-root testing, revisited on the GDP example (lab section 2a–2b)

Module 2's material, pointed to as Module 2's map does.

| Book | Where |
|---|---|
| Enders | Ch. 4, pp. 181–200 (order of integration; trend-stationary versus difference-stationary), pp. 206–209 (the DF/ADF test, specifications, critical values), p. 214 (KPSS, briefly). |
| Hamilton | Ch. 15 **(verify)** and Ch. 17 — chapter level; the asymptotics, not the workflow. |
| fpp3 | Ch. 9, the stationarity-and-differencing section; fpp3's workflow leads with KPSS, the reverse of this course's ADF-first habit. |

### Identification and information criteria, revisited (lab section 2c)

Module 3's and Module 4's material.

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 71–80 (sample ACF/PACF identification), pp. 72–79 (AIC/SBC in ARMA selection). Enders' SBC is this course's BIC. |
| Hamilton | Ch. 5, pp. 125–145 (ARMA likelihood and estimation); the information-criterion location is **(verify)**. |
| fpp3 | Ch. 9: AICc-based selection and the `auto.arima()` workflow, chapter level. |

### What is not in any textbook here

The GDP-per-capita worked example (the data card, the 1990–2006 window, the
frozen-parameter test on 2007–2011), the lab's own AR(1) draw, and the
scoreboard under four losses are the course's own. Diebold-Mariano and forecast
combinations are Module 7; no pointer is given for them in this module's notes.

---

## Part B — Notation translation

Same mathematics, different alphabets. This is where most cross-referencing
confusion comes from.

| Concept | This course | Enders | Hamilton / fpp3 |
|---|---|---|---|
| $h$-step forecast made at $t$ | $\hat y_{t+h\mid t} = \mathbb{E}[y_{t+h} \mid \mathcal{F}_t]$ | $E_t y_{t+h}$, the conditional expectation with the origin as a subscript | Hamilton $\hat Y_{t+h\mid t}$; fpp3 $\hat y_{T+h\mid T}$ (same as the course, with $T$ for the origin) |
| Forecast error | $e_{t+h\mid t} = y_{t+h} - \hat y_{t+h\mid t}$ (an $e$: observable after the fact) | $e_t(h)$, horizon in parentheses **(verify)** | fpp3 $e_{T+h}$ **(verify)**; Hamilton **(verify)** |
| Information set | $\mathcal{F}_t$ | The $t$ subscript on $E_t$ carries it | Hamilton: the conditioning variables written out **(verify)**; fpp3: "all observations up to time $T$" |
| MA($\infty$) weights | $\psi_i$, $\Psi(L) = \Theta(L)/\Phi(L)$, $\psi_0 = 1$ | $\psi_i$ **(verify local index)** | Hamilton $\psi_j$ (indexed by $j$, our $i$) |
| AR coefficient | $\phi_j$ | $a_i$ | $\phi_j$ |
| Intercept versus mean | $\alpha$ and $\mu = \alpha/(1-\sum\phi_j)$; R's `intercept` is $\hat\mu$ | $a_0$ is the intercept | fpp3 works from R objects: the printed `intercept`/`mean` is $\hat\mu$ |
| MA polynomial sign | $\Theta(L) = 1 + \theta_1 L + \cdots$ (plus) | Plus signs (same as the course) | Hamilton: plus; fpp3 and R: plus. Box–Jenkins-tradition texts write minus, flipping every reported $\theta$ |
| Stationarity roots | Roots of $\Phi(L) = 0$ outside the unit circle | Characteristic roots inside (reciprocal, same condition) | Hamilton: lag-polynomial roots outside |
| Loss function | $g(e)$ ($L$ is the lag operator) | Usually just "squared forecast error" without a symbol **(verify)** | fpp3 names the measures (MSE, MAE, MAPE, MASE) rather than a loss symbol |
| Test-set size | $N$ (never $T$, the sample size) | — | fpp3: the "test set" length, no fixed symbol |
| Train/test | train/test, `ts_split()` | — | fpp3: "training set" / "test set" |
| Prediction interval | $\hat y_{t+h\mid t} \pm z_{\alpha/2}\sqrt{\operatorname{Var}(e_{t+h\mid t})}$ | Same construction, pp. 80–81 | fpp3: "prediction interval", 80% and 95% by default, same $z$ |
| Stationarity | Weak (covariance) stationarity | Weak | fpp3 states a strict definition; the forecasting material is compatible regardless |

### The four that actually cause problems

1. **$E_t y_{t+h}$ is $\hat y_{t+h\mid t}$.** Enders carries the origin as a
   subscript on the expectation; the course carries it after the bar. Same
   object.
2. **Check the MA sign before copying a coefficient.** Enders, Hamilton and R
   agree with this course (plus signs). A text in the Box–Jenkins tradition
   reports $\theta$ with the opposite sign, and then the over-differencing flag
   $\hat\theta \approx -1$ reads as $+1$.
3. **R's `intercept` is $\hat\mu$.** No textbook will warn you, because none of
   them wrote `stats::arima()`. Recover $\hat\alpha = \hat\mu(1 - \sum_j
   \hat\phi_j)$ before any hand recursion.
4. **Hyndman's $m$ is this course's $s$, and his "training/test" is our
   "train/test".** Same split, same rule: the split is a date, never a draw.
