# data/ — The data behind the Module 6 lab

Everything the lab needs is in this folder, so it runs with no FRED key and no
internet connection. That holds for every pack in this course: nothing should
need a network call to work.

If you want to see how the data are actually pulled, `R/fetch_fred.R` shows the
live `fredr` call — but nothing requires you to run it.

| File | What it is | Coverage |
|---|---|---|
| `A939RX0Q048SBEA.csv` | U.S. real gross domestic product per capita, quarterly, seasonally adjusted at annual rates, chained (2017) dollars per person (FRED `A939RX0Q048SBEA`; Bureau of Economic Analysis, NIPA Table 7.1, line 10). The lab works on its natural log: fits on 1990 Q1 to 2006 Q4, forecasts 2007 Q1 to 2011 Q4. | 1947 Q1 to 2026 Q2, 318 rows, no gaps |
| `UNRATE.csv` | U.S. civilian unemployment rate, monthly, **seasonally adjusted**, percent (FRED `UNRATE`). The series you have used since Module 2; section 11 forecasts its last two years. | 1948-01 to 2026-04, 940 rows, one blank month |

Columns in both files follow the FRED CSV export:

```text
observation_date,A939RX0Q048SBEA
1947-01-01,15248
```

## The one vintage you should know about

The GDP file is the series **as published by BEA on September 30, 2026**: the
Q2 2026 third estimate, released together with the 2026 annual update, which
revised 2021 Q1 through 2026 Q1. Its last value (2026 Q2) is 71,212; the
previous day's vintage had 70,809. National accounts get revised — three
estimates per quarter, an annual update each September, a comprehensive
revision about every five years, and a population denominator that revises on
its own calendar — so the series you download next year will not be this
series.

Two consequences for the lab. First, check 1 in `R/checks.R` tests the last
value on purpose: a refreshed file changes numbers in the lab without
announcing itself, and the check is how it announces itself. Second, the
2007–2011 test set is the **revised** history, not what a forecaster saw at the
time. That is an honest limitation, said once: the lab scores a 2006 model
against today's numbers for 2008, and real-time data are a Module 7 topic.

## The one gap you should know about

`UNRATE.csv` has exactly one blank: **October 2025**, a federal data-release
gap. The lab uses January 1960 through December 2019, the same window Modules 4
and 5 used, so the gap never touches it. Do not interpolate or silently "clean"
the file; check 1 looks for that blank on purpose.

The window stops at 2019 because April 2020's jump (from 4.4 to 14.8) dominates
every autocorrelation it touches, and the course's models have no outlier or
break treatment. Forecasting past 2019 is a fine exploration, as long as you
label it a sensitivity analysis and know what is coming.

## Refreshing the data

Re-run the `fredr` pull with a valid `FRED_KEY` in your environment
(`R/fetch_fred.R`; the GDP series is quarterly, so pass `frequency = 4`), write
the result here, and update the coverage column above. If you refresh anything,
the lab's printed numbers and `R/checks.R` will notice; update them together
rather than loosening a check.

## The key rule

**Never commit an API key, or any file containing one, to this folder.** Keys
live in your environment — in `.Renviron` or via `Sys.setenv()` — and are read
with `Sys.getenv("FRED_KEY")`. They never appear in a course file. This pack is
meant to be shareable.

Get a free FRED key at <https://fred.stlouisfed.org/docs/api/api_key.html>.
