# Module 6 Context — Forecasting Fundamentals

**Econ 6376 — Applied Time Series Econometrics, George Washington University (Applied Economics MA).**

This file is self-contained. Paste or upload it on its own into any AI
assistant and it will have everything it needs to help with Module 6.

<!-- BEGIN COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

## Course-wide conventions

These apply to every module of Econ 6376, not just this one.

### The master equation

Every model in this course is the following equation with some terms switched off:

$$y_t = \alpha + \delta t + \sum_{j=1}^{p} \phi_j y_{t-j} + \sum_{l=1}^{q} \theta_l \epsilon_{t-l} + \epsilon_t$$

The course analogy is a **mixing board**: each term is a slider, and each module
turns on new ones. A student should always be able to say where the model in
front of them sits on that board. If they can't, the framing has failed — help
them locate it.

### The cardinal notation rule: DGP vs. estimation

A data-generating process and an estimating equation look different, and the
course is strict about this.

- **DGP (the truth, unobservable):** unhatted parameters $\alpha, \delta, \phi_j, \theta_l, \beta$ and $\epsilon_t$, the **innovation**.
- **Estimating equation (your model, observable):** hatted parameters $\hat\alpha, \hat\phi_j, \hat\theta_l, \hat\beta$ and $e_t$, the **residual**, where $e_t = y_t - \hat y_t$.

Never write $\epsilon_t$ when you mean $e_t$. Never drop a hat from an estimate.
A well-specified model leaves residuals that behave like the innovations that
model assumes — that is the entire basis of diagnostic testing later in the course.

### Other standing conventions

- **Lag polynomials:** AR takes minus signs, $\Phi(L) = 1 - \phi_1 L - \cdots - \phi_p L^p$. MA takes plus signs, $\Theta(L) = 1 + \theta_1 L + \cdots + \theta_q L^q$.
- **Stationarity framing:** all roots of $\Phi(L) = 0$ lie strictly **outside** the unit circle. Enders and the older course slides use the equivalent characteristic-root-**inside** framing (related by $r = 1/L$). Both are correct; flag the difference whenever a student is cross-referencing a textbook.
- **Symbols:** $\phi$ = AR coefficients, $\theta$ = MA, $\beta$ = covariates, $\alpha$ = intercept, $\delta$ = trend. $\gamma_k$ = autocovariance at lag $k$, $\rho_k$ = autocorrelation, $\gamma_0 = \operatorname{Var}(y_t)$. $L$ = lag operator, $\Delta = (1-L)$. $t = 1,\ldots,T$.
- **"Stationary"** means weakly (covariance) stationary unless stated otherwise.
- **Language:** the course is taught in R. Students may submit graded work in another language if they can reproduce the workflow, but help and debugging are R-first. Plots use `ggplot2`.
- **Credentials:** FRED keys come from `Sys.getenv("FRED_KEY")`, never hardcoded, never committed.

### Working rules

- Concept before math, always. Intuition first, then notation.
- Simulation is the center of gravity, and a simulation that only confirms the textbook is half an exercise. Breaking an assumption is where understanding happens.
- The four-step rhythm for any major topic: **Concept → Math → Simulate (break something) → Real Data.**
- The student-facing learning protocol: **Predict → Commit → Ask AI → Test in R → Reconcile.**
- **Core is the assessable surface.** Course notes are tiered (Core / Deeper Dive / Technical Note / Looking Ahead). Problem sets and exams draw **only** on Core. Optional tiers are genuinely optional — never imply otherwise.

<!-- END COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

---

## What Module 5 established

Four facts this pack relies on, so it stands alone:

1. The Modules 2–5 chain: test for stationarity (ADF against KPSS, the rule of thumb, difference under doubt); read the ACF and PACF for the class; score candidates with AIC, AICc, BIC, HQIC; check residuals with Ljung-Box, fitdf $= p + q$.
2. Serial correlation is a property of the fitted model, not the data.
3. Over-differencing leaves a fingerprint: an MA coefficient pinned near $-1$. `auto.arima()` is a very good intern; read its work.
4. Module 5 handed over a diagnostic-clean ARIMA$(1,1,2)(1,0,1)_{12}$ on published UNRATE (1960–2019) and asked: what does it say about next month?

## What Module 6 is about

Until now the course built models. Today it *uses* one. Three questions: what
is the best guess (the point forecast), how uncertain is it (the interval and
the fan chart), and how do you keep score when you are wrong every time (the
loss function). The lab's worked example is the one from class: log real GDP
per capita, modeled on 1990 Q1–2006 Q4 and forecast into 2007–2011, the Great
Recession, parameters frozen at 2006 Q4. It closes with the Module 5 handoff
model on UNRATE.

**On the mixing board, Module 6 turns on nothing new.** Every slider of the
univariate mean equation is already on; today the fitted equation is pushed
forward in time. Module 8 adds $x_t$; Module 14 models the variance.

Lab map: 2 the Modules 2–5 chain on GDP · 3 what a forecast is · 4 recursion ·
5 interval · 6 short-run versus long-run · 7 test set · 8 coverage break · 9
loss functions · 10 scoreboard under each loss · 11 UNRATE.

### Core learning objectives

1. Distinguish point, interval and density forecasts, and say which question each answers.
2. Define $\hat y_{t+h|t} = \mathbb{E}[y_{t+h} \mid \mathcal{F}_t]$ and explain why the conditional mean minimizes expected squared error.
3. Compute the recursive $h$-step forecast by hand for an AR(1) and an AR(2), recovering $\hat\alpha$ from the mean R reports.
4. Explain why random train/test splits are wrong, split with `ts_split()`, and distinguish expanding-window from fixed-width rolling-window evaluation.
5. Derive the AR(1) forecast-error variance and state $\operatorname{Var}(e_{t+h|t}) = \sigma^2\sum_{i=0}^{h-1}\psi_i^2$.
6. Build a Gaussian prediction interval $\hat y_{t+h|t} \pm z_{\alpha/2}\sqrt{\operatorname{Var}(e_{t+h|t})}$ and explain why it widens with $h$.
7. Run a Monte Carlo of empirical coverage at 80/95/99% under Gaussian innovations, repeat under standardized $t_3$, and explain the middle-versus-tail pattern.
8. Write and interpret MSE, MAE, MAPE, Huber and asymmetric loss; name the target each optimizes; give a concrete case for asymmetric loss.
9. Use `forecast::forecast()` for point forecasts, intervals and fan charts, and read the fan chart.
10. Execute the full workflow on UNRATE — split, fit on training, forecast, overlay, score, compare with a naive baseline — and interpret it honestly, including when the baseline is hard to beat.


---

## Core concepts

**You are always wrong; the question is how wrong.** A forecast is a
distribution: the headline number is its mean under squared-error loss, the
interval is where the honesty lives. "Between 3% and 12%" is right and useless;
"4.1%, give or take 0.3" is wrong in the third decimal and useful. **Origin**
$t$, **horizon** $h$, **information set** $\mathcal{F}_t$. The forecast error
$e_{t+h|t} = y_{t+h} - \hat y_{t+h|t}$ is an $e$, not an $\epsilon$.

**The recursion.** $\hat y_{t+1|t} = \alpha + \phi y_t$ because
$\mathbb{E}[\epsilon_{t+1} \mid \mathcal{F}_t] = 0$; $\hat y_{t+h|t} = \alpha +
\phi\,\hat y_{t+h-1|t}$. Two rules: future innovations become zero; future
$y$'s become their forecasts. AR(1) closed form: $\hat y_{t+h|t} - \mu =
\phi^h (y_t - \mu)$: the forecast forgets its origin at rate $\phi^h$ and
converges to $\mu = \alpha/(1-\phi)$, not zero. AR(2): the second lag is
observed at $h = 2$, a forecast from $h = 3$. ARMA(1,1): the last residual
$e_T$ enters explicitly at $h = 1$ only, then rides forward through the AR
recursion, shrinking by $\phi$ each step. **R's `intercept` is the mean
$\hat\mu$, not $\hat\alpha$**: recover $\hat\alpha = \hat\mu(1 - \sum_j
\hat\phi_j)$ before any hand recursion.

**The interval.** $e_{t+h|t} = \sum_{i=0}^{h-1}\psi_i\epsilon_{t+h-i}$ with
Module 3's MA($\infty$) weights, $\Psi(L) = \Theta(L)/\Phi(L)$ (`ARMAtoMA()`),
so $\operatorname{Var}(e_{t+h|t}) = \sigma^2\sum_{i<h}\psi_i^2$. AR(1):
$\psi_i = \phi^i$, variance $\sigma^2(1-\phi^{2h})/(1-\phi^2)$: $\sigma^2$ at
$h = 1$, $\gamma_0$ in the limit, as uncertain as knowing nothing. Gaussian
innovations make the error Gaussian, so the interval is $\hat y_{t+h|t} \pm
z\,\sigma\sqrt{\sum\psi_i^2}$, $z = 1.96$ for 95%, $1.28$ for 80%:
`forecast()`'s default, drawn as the fan chart. For a $d = 1$ model the sum
does not converge and the fan never stops opening. **The key assumption:** the
95% rests on $\epsilon_t \sim N(0,\sigma^2)$, the right model, and the plug-in
treatment of estimated parameters; break any and the coverage is nominal, not
delivered.

**Short-run versus long-run.** The share of $\operatorname{Var}(y_{t+h})$ the
forecast explains is $\phi^{2h}$: at $\phi = 0.7$, 49%, 24%, 5.8%, 0.3% at
$h = 1, 2, 4, 8$; half is still explained at $h = \ln 0.5/(2\ln\phi)$, one step
at $0.7$, seven at $0.95$. A stationary model forecasts a few steps, then the
mean. **Frozen coefficients:** `Arima(y, model = fit)` re-applies the
training coefficients to a longer series without re-estimating; `fitted()` is
then the one-step forecast at every $t$ from information through $t-1$.

**Splits and evaluation designs.** Never a random split: the split is a date.
`ts_split(y, test_periods)` returns `$train` and `$test`. *Fixed-origin*: fit
once, forecast the whole horizon (UNRATE). *Rolling-origin*: advance the origin
one step at a time; *expanding* if each new observation joins the training set,
*fixed-width* if the oldest is dropped; coefficients re-estimated or frozen.
The GDP test is expanding with frozen coefficients; Module 7 re-estimates.

**The worked example (lab sections 2 and 7).** Log real GDP per capita, 1990
Q1–2006 Q4, $T = 68$. Level: neither ADF nor KPSS clearly rejects, and 68
quarters cannot separate a trend from a unit root. *A choice, not a finding*:
difference under doubt and check the fit for over-differencing. Growth: a unit
root is rejected, stationarity is not, $\hat\rho_1 = +0.30$, ACF and PACF both
tail off, so start at ARIMA(2,1,2) with drift. Candidates (all with drift,
$T = 67$): AIC, AICc and HQIC pick ARIMA(2,1,0); BIC picks ARIMA(1,1,0);
ARIMA(2,1,2) is last everywhere with an MA root at modulus 1.000, the
over-differencing light; all five pass Ljung-Box. Both finalists go to the
test set: 2007 Q1–2011 Q4, one and two steps ahead, coefficients frozen at
2006 Q4, against a random walk with drift (the training mean growth every
quarter), scored in percent per quarter on the 2026-09-30 vintage. **The
scoreboard is the lab's prediction target and sits in the tutor block.**

**The coverage assumption-break (section 8).** Simulate an AR(1), fit the
correct model, build one-step 80/95/99% bands, count hits: Gaussian shocks
first (coverage near nominal), then standardized $t_3$ shocks with the same
variance; with parameters known the true coverage under $t_3$ is
$1 - 2F_{t_3}(-z\sqrt{3})$. The teaching point is the middle-versus-tail
pattern: a standardized $t_3$ has more mass near the center *and* in the far
tails than a Gaussian of the same variance. Module 5's rule in forecasting
clothes: the interval's shape is a property of your distributional assumption
relative to the data. Real-data beat: the GDP training residuals' kurtosis, and
how many standard deviations 2008 Q4 missed by.

**Loss functions (section 9).** $g(e)$, the cost of being wrong ($g$, not $L$);
zero at a perfect forecast, larger as the miss grows; chosen to reflect *your*
cost function, before the results. Marginal cost picks the shape: explosive
per-unit cost → **MSE** $\frac1N\sum(y_t-\hat y_t)^2$, target the conditional
mean; constant → **MAE** $\frac1N\sum|y_t-\hat y_t|$, target the median;
quadratic then linear beyond $\delta$ → **Huber** $g_\delta(e)$; one direction
costlier → **asymmetric linear**, $\alpha|e|$ for $e > 0$ (under-prediction)
and $(1-\alpha)|e|$ otherwise, target the $\alpha$-quantile ($\alpha = 0.5$ is
MAE). $N$ counts test-set observations. **MAPE** is scale-free, undefined at
zero, and meaningless on a growth rate near zero. The Texas grid: under-forecast
and people freeze, over-forecast and you wasted fuel; the same 500 MW is not the
same error. **The loss picks the target:** on skewed (centered-exponential)
shocks, the mean track wins MSE and the median-shifted track wins MAE.
**Compare within a loss, never between**: same loss, same series, same $N$. Any
function with the two properties is a loss (the notes' call-center example;
its code costs under-staffing by five at \$3,750). Helpers: `mse()`, `mae()`,
`rmse()`, `mape()`, `huber()`, `asym_loss()`. **Section 10**
scores the three GDP tracks under MSE, MAE, Huber ($\delta = 2$) and asymmetric
loss at $\alpha \in \{0.5, 0.7, 0.8\}$; whether the ranking survives is the
prediction (tutor block).

**The UNRATE workflow (section 11).** `ts_split(unrate, 24)` (training ends
2017-12); re-fit ARIMA$(1,1,2)(1,0,1)_{12}$ on training (still passes
Ljung-Box, fitdf 5); `forecast(h = 24)` with 80/95% bands; overlay the actuals;
MSE, MAE, RMSE against `naive()`. The notes' honest readings: the naive
benchmark is genuinely hard to beat on a persistent series in a calm stretch;
diagnostics and forecast accuracy answer different questions; one window is one
draw, and whether a margin means anything is Module 7's question.

---

## Vocabulary

Beyond the terms defined above: fan chart · $\psi_i$ · nominal versus delivered
coverage · train/test split (Hyndman: training/test) · fixed-origin,
rolling-origin, expanding, fixed-width · frozen versus re-estimated
coefficients · $g(e)$, $\delta$, $\alpha$ · under-prediction ($e > 0$) · naive
and random-walk-with-drift benchmarks · MASE (Module 7 preview).

---

## Two subtleties

1. **The conditional mean is optimal *under squared error*.** Change the loss
   and the target moves: the median under MAE, a quantile under asymmetric loss.
   Not a contradiction of objective 2; the point of section 9. `forecast()`'s
   `$mean` is the MSE target.
2. **Selection and evaluation are different questions on different samples.**
   Winning the IC table on 1990–2006 does not make a model the best forecaster
   of 2007–2011; losing to the naive on one window does not make it pointless.
   Rank on training, score on the test set, test the margin.

---

## Common misconceptions

Correct these by asking a question or running something, not by lecturing.

1. **"A forecast is a number."** It is a distribution; the number is its mean under squared error. Ask for the band.
2. **"The 95% band is where the series will be."** It is where the model says 95% of futures land *if the model and its Gaussian errors are right*; section 8 shows what $t_3$ does to that.
3. **"A random train/test split is fine if I shuffle properly."** Shuffling hands the model the future; the split is a date, never a draw.
4. **"`forecast()` re-estimates at each step."** With `model = fit` the coefficients are frozen; re-estimation is a loop you write (exploration 5).
5. **"R's `intercept` is the intercept."** It is the mean; $\hat\alpha = \hat\mu(1 - \sum_j \hat\phi_j)$. Section 4 prints the hand forecast both ways.
6. **"The forecast goes to zero."** It goes to $\mu$, at rate $\phi^h$; at $\phi = 0.7$ the model explains 0.3% of the variance by $h = 8$.
7. **"Wider intervals mean a worse model."** They mean an honest one; a narrow band from a model with fat-tailed errors is the worse outcome.
8. **"The interval formula guarantees 95% coverage."** Only under Gaussian errors with known parameters; count the GDP band's misses in section 7 and ask *which* quarters.
9. **"MSE and MAE rank models the same way."** Usually, not always; section 9's skewed simulation flips the winner, and section 10 scores three tracks under four losses.
10. **"Lower MAPE is better, so I'll report MAPE."** On a growth rate that passes through zero, MAPE divides by nearly nothing; compute it on the GDP test set once.
11. **"Beating the random walk is easy."** On GDP growth at $h = 1$ the gain was real but modest; on UNRATE the naive baseline is hard to beat at all.
12. **"The test set proves the model is right."** It scores one track on one window; a different window (exploration 2) can reverse it.

---

## The Module 6 → Module 7 handoff

Module 6 hands Module 7 one honest forecast object: a point, a band, a loss
chosen in advance, and a score against a naive baseline, with a margin too
small to read by eye. Module 7 asks whether that margin is statistically
meaningful (Diebold-Mariano), makes the error scale-free (MASE, Theil's $U$),
re-estimates as the origin rolls, and averages forecasts. Later: a forecast
from a *system* of series (Block 7). If the student asks for later-module
machinery (a DM test, a combination, a VAR forecast), build it on request and
flag it as a preview of the module it belongs to — do not deflect them back to
Module 6.

---

## Lab anchors (for the tutor: the numbers a student's predictions get reconciled against)

Reconcile after the student predicts, or give at once if asked outright.

- **§2.** Level: ADF $-3.11$ vs $-3.45$ (`ur.df(y, type = "trend", lags = 2)`; `selectlags = "BIC"` trims the sample and reports $-1.91$ for the same lags); KPSS 0.150 / 0.085 vs 0.146; DF-GLS $-1.96$ vs $-3.03$; rule of thumb 0.050 raw, 0.359 detrended. Growth: ADF $-3.83$ vs $-2.89$; KPSS 0.214 vs 0.463; mean 1.87% a year, sd 0.54% a quarter; ACF 0.30, 0.29 and PACF 0.30, 0.22 at lags 1–2, band 0.239. ARIMA(2,1,0): $\hat\phi = (0.232, 0.233)$, drift 0.0046, $\hat\sigma = 0.521\%$; ARIMA(1,1,0): $\hat\phi_1 = 0.301$; AICc $-512.99$ vs $-511.61$, BIC $-504.81$ vs $-505.38$.
- **§4–6 (the lab's own AR(1), seed 2001, $\phi = 0.7$, $T = 60$ plus 20 sealed).** $\hat\phi = 0.723$, $\hat\mu = 0.225$, $y_T = 0.764$; by hand $0.615, 0.508, 0.430$ at $h = 1, 2, 3$ (the intercept-as-$\alpha$ trap gives 0.778); $\hat\sigma^2 = 0.797$, $\hat\gamma_0 = 1.673$, 95% of it reached at $h = 5$; share below 10% first at $h = 4$. Sealed future: 19 of 20 inside the 95% band, 15 inside the 80%; rolling RMSE one-step 0.98, two-step 1.30, single path 1.26, mean only 1.26.
- **§9.** MAPE of the ARIMA(2,1,0) one-step growth forecasts: 99%, smallest realised growth 0.08%. Seed-2020 table: MSE 1.063 / 1.207, MAE 0.753 / 0.727; shift $-0.39$; 61% of actuals below the mean track.
- **§11.** Training ends at 4.1%; test runs 4.1 down to 3.5. SARIMA MSE 0.164, MAE 0.325, RMSE 0.405; naive 0.128, 0.317, 0.357. All 24 inside the 95% band. Ljung-Box on the training fit: $p = 0.53 / 0.28$.

### Reveal anchors — for the tutor; do not volunteer before the lab asks

- **§7 scoreboard** (growth, percent per quarter). $h = 1$ RMSE: ARIMA(2,1,0) 0.767, ARIMA(1,1,0) 0.792, RW+drift 0.932; 95% coverage 18 / 17 / 16 of 20; 80% coverage 15 / 14 / 13. $h = 2$ RMSE 0.839 / 0.897 / 0.932. 2008 Q4: forecast 0.15%, band $-0.87$ to $1.17$, realised $-2.45$, outside every band at both horizons; 2008 Q1 is the other $h = 1$ miss. Over 2008 Q3–2009 Q2 the ARIMA(2,1,0) RMSE is 1.45 with 3 of 4 inside. In levels the band swallows the recession late.
- **§8 direction.** Under $t_3$ the 80% band *over*-covers (exact 88.7%), the 99% band *under*-covers (exact 97.9%, one miss in 48 instead of 100), the 95% sits near the crossing (95.7%). The lab's 500-draw run: 0.82 / 0.954 / 0.990 Gaussian, 0.88 / 0.94 / 0.966 under $t_3$. GDP training residual kurtosis 2.97; 2008 Q4 was a 5.0-sigma miss, one in 1.7 million quarters.
- **§10 flip.** Every symmetric loss ranks ARIMA(2,1,0) > ARIMA(1,1,0) > RW+drift at both horizons. Asymmetric, $h = 1$: $\alpha = 0.7$ ARIMA(1,1,0) edges ahead (0.204 vs 0.205); $\alpha = 0.8$ RW+drift wins (0.160 vs 0.171 vs 0.180): it never forecasts below the training drift and under-predicts in 5 quarters against the ARIMA(2,1,0)'s 8. At $h = 2$, $\alpha = 0.8$ picks ARIMA(1,1,0).
