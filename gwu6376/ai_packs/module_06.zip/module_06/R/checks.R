# =============================================================================
# checks.R — the referee for the Module 6 AI Learning Pack (Econ 6376)
#
# Seven assertions about the numerical claims and shipped data in Module 6.
# Run from the pack root:   Rscript R/checks.R
# Each check prints one PASS/FAIL line. Any FAIL exits with a nonzero status.
#
# Base R and stats only: no forecast, no urca, no ggplot2. The lab fits with
# forecast::Arima(..., include.drift = TRUE) on the log level; the same model is
# stats::arima() with a mean on the growth rate, and the two agree on the
# log-likelihood and coefficients to the tolerances below (CHECKS.md explains
# the one convention that differs, the reported sigma^2). This is readable
# evidence, not an answer key.
# =============================================================================

source("R/forecast_utils.R")    # mse(), mae(), huber(), asym_loss(): plain base R

# ---- tiny test harness ------------------------------------------------------
# A failed assertion does not hide later checks.
results <- logical(0)

check <- function(label, passed, detail = "") {
  passed <- isTRUE(passed)
  results[[length(results) + 1L]] <<- passed
  cat(sprintf("%-4s %s%s\n",
              if (passed) "PASS" else "FAIL",
              label,
              if (nzchar(detail)) paste0("  [", detail, "]") else ""))
  invisible(passed)
}

cat("Module 6 checks\n---------------\n")


# ---- 1. the data are the data ------------------------------------------------
# The GDP file is the 2026-09-30 vintage (last value 71,212); the training window
# 1990 Q1 to 2006 Q4 has 68 quarters with the growth mean and sd the lab quotes.
# UNRATE keeps its single known blank, and the 1960-2019 window is 720 months.
gdp <- read.csv("data/A939RX0Q048SBEA.csv", stringsAsFactors = FALSE)
gdp_ok <- identical(names(gdp), c("observation_date", "A939RX0Q048SBEA")) &&
  nrow(gdp) == 318L && !anyNA(gdp$A939RX0Q048SBEA) &&
  identical(gdp$observation_date[c(1, 318)], c("1947-01-01", "2026-04-01")) &&
  gdp$A939RX0Q048SBEA[318] == 71212
lev_all <- ts(gdp$A939RX0Q048SBEA, start = c(1947, 1), frequency = 4)
y  <- log(window(lev_all, start = c(1990, 1), end = c(2006, 4)))
dy <- diff(y)
growth_mean_pct_yr  <- 400 * mean(dy)
growth_sd_pct_qtr   <- 100 * sd(dy)

unr <- read.csv("data/UNRATE.csv", stringsAsFactors = FALSE)
unr_ok <- identical(names(unr), c("observation_date", "UNRATE")) &&
  sum(is.na(unr$UNRATE)) == 1L &&
  identical(unr$observation_date[is.na(unr$UNRATE)], "2025-10-01") &&
  sum(unr$observation_date >= "1960-01-01" & unr$observation_date <= "2019-12-01") == 720L
check("GDP cache is the 2026-09-30 vintage; 68-quarter window has the quoted growth mean and sd; UNRATE intact",
      gdp_ok && length(y) == 68L && abs(growth_mean_pct_yr - 1.871) < 0.005 &&
        abs(growth_sd_pct_qtr - 0.5357) < 0.001 && unr_ok,
      sprintf("rows = %d, last = %s; T = %d, mean growth = %.3f %%/yr, sd = %.4f %%/qtr; UNRATE window = %d",
              nrow(gdp), format(gdp$A939RX0Q048SBEA[318]), length(y), growth_mean_pct_yr, growth_sd_pct_qtr,
              sum(unr$observation_date >= "1960-01-01" & unr$observation_date <= "2019-12-01")))


# ---- 2. the ADF statistic is the full-sample one ----------------------------
# The Dickey-Fuller regression built by hand with lm() on every usable
# observation: delta y_t on y_{t-1}, k lagged differences, a constant and (for the
# trend specification) a time trend. tau is the t-statistic on y_{t-1}. This is
# what ur.df(y, type, lags = k) prints; urca's selectlags option trims the sample
# to the longest lag it tried and reports a different number for the same k.
adf_by_hand <- function(y, k, spec = c("trend", "drift")) {
  spec <- match.arg(spec)
  y <- as.numeric(y); dy <- diff(y); n <- length(dy)
  idx  <- (k + 1):n                      # rows with k lagged differences available
  d    <- data.frame(dy_t = dy[idx], y_lag1 = y[idx], tt = idx)
  if (k > 0) for (j in seq_len(k)) d[[paste0("dy_lag", j)]] <- dy[idx - j]
  rhs  <- c("y_lag1", if (k > 0) paste0("dy_lag", seq_len(k)), if (spec == "trend") "tt")
  fit  <- lm(reformulate(rhs, response = "dy_t"), data = d)
  c(tau = unname(summary(fit)$coefficients["y_lag1", "t value"]), n_used = length(idx))
}
adf_level  <- adf_by_hand(y,  k = 2, spec = "trend")
adf_growth <- adf_by_hand(dy, k = 1, spec = "drift")
check("Hand-built ADF: trend, k = 2 on 65 rows gives tau = -3.113; growth, drift, k = 1 gives -3.833",
      abs(adf_level[["tau"]] + 3.113) < 0.005 && adf_level[["n_used"]] == 65 &&
        abs(adf_growth[["tau"]] + 3.833) < 0.005,
      sprintf("level tau = %.4f (n = %d); growth tau = %.4f (n = %d)",
              adf_level[["tau"]], adf_level[["n_used"]], adf_growth[["tau"]], adf_growth[["n_used"]]))


# ---- 3. the recursion is the closed form ------------------------------------
# AR(1), phi = 0.7, mu = 0, y_T = 1. The point recursion equals phi^h; the
# variance recursion equals (1 - phi^(2h)) / (1 - phi^2); the explained shares
# phi^(2h) at h = 1, 2, 4, 8 are the lab's table.
phi <- 0.7; h_max <- 8
f_loop <- numeric(h_max); v_loop <- numeric(h_max)
f_prev <- 1; v_prev <- 0
for (h in seq_len(h_max)) {
  f_loop[h] <- phi * f_prev;            f_prev <- f_loop[h]       # future innovations -> 0
  v_loop[h] <- v_prev + phi^(2 * (h - 1)); v_prev <- v_loop[h]    # sigma^2 sum psi_i^2, sigma = 1
}
f_closed <- phi^(1:h_max)
v_closed <- (1 - phi^(2 * (1:h_max))) / (1 - phi^2)
shares   <- phi^(2 * c(1, 2, 4, 8))
check("AR(1) recursion equals phi^h; variance loop equals the closed form; shares 0.49/0.2401/0.0576/0.0033",
      max(abs(f_loop - f_closed)) < 1e-12 && max(abs(v_loop - v_closed)) < 1e-12 &&
        max(abs(shares - c(0.49, 0.2401, 0.05764801, 0.0033232931))) < 1e-9,
      sprintf("max point gap = %.1e, max variance gap = %.1e, shares = %s",
              max(abs(f_loop - f_closed)), max(abs(v_loop - v_closed)),
              paste(signif(shares, 4), collapse = "/")))


# ---- 4. the finalists are pinned --------------------------------------------
# ARIMA(2,1,0) with drift on the log level is AR(2) with a mean on the growth
# rate; ARIMA(1,1,0) with drift is AR(1) with a mean. stats::arima() reproduces
# forecast::Arima()'s log-likelihoods and coefficients.
fit_ar2 <- stats::arima(dy, order = c(2, 0, 0))
fit_ar1 <- stats::arima(dy, order = c(1, 0, 0))
check("stats::arima on growth: AR(2)+mean logLik = 260.816, AR(1)+mean logLik = 258.998; phi-hats 0.232/0.233 and 0.301",
      abs(fit_ar2$loglik - 260.816) < 0.01 && abs(fit_ar1$loglik - 258.998) < 0.01 &&
        abs(coef(fit_ar2)[["ar1"]] - 0.232) < 0.005 && abs(coef(fit_ar2)[["ar2"]] - 0.233) < 0.005 &&
        abs(coef(fit_ar1)[["ar1"]] - 0.301) < 0.005,
      sprintf("logLik = %.4f / %.4f; AR(2) phi = %.4f, %.4f, mean = %.5f; AR(1) phi = %.4f",
              fit_ar2$loglik, fit_ar1$loglik, coef(fit_ar2)[["ar1"]], coef(fit_ar2)[["ar2"]],
              coef(fit_ar2)[["intercept"]], coef(fit_ar1)[["ar1"]]))


# ---- 5. the test-set score is pinned ----------------------------------------
# One-step forecasts of growth for 2007 Q1 to 2011 Q4 from the AR recursion with
# the coefficients frozen at the training fit: growth-hat_{t+1|t} =
# mu + phi_1 (g_t - mu) + phi_2 (g_{t-1} - mu). The random walk with drift
# forecasts the training mean every quarter. The 95% band is +/- 1.96 sigma-hat.
y_long   <- log(window(lev_all, start = c(1990, 1), end = c(2011, 4)))
g_all    <- 100 * diff(as.numeric(y_long))            # growth, percent, 1990 Q2 .. 2011 Q4
n_train  <- length(dy)                                # 67 training growth rates
targets  <- (n_train + 1):(n_train + 20)              # indices of 2007 Q1 .. 2011 Q4 in g_all
mu_hat   <- 100 * coef(fit_ar2)[["intercept"]]; ph <- coef(fit_ar2)[c("ar1", "ar2")]
g_hat    <- mu_hat + ph[[1]] * (g_all[targets - 1] - mu_hat) + ph[[2]] * (g_all[targets - 2] - mu_hat)
g_real   <- g_all[targets]
rmse_ar2 <- sqrt(mean((g_real - g_hat)^2))
rmse_rw  <- sqrt(mean((g_real - 100 * mean(dy))^2))
sigma_pct <- 100 * sqrt(fit_ar2$sigma2)
inside95 <- sum(abs(g_real - g_hat) <= qnorm(0.975) * sigma_pct)
check("Test set 2007-2011, coefficients frozen: AR(2) one-step RMSE = 0.767, RW+drift = 0.932, AR(2) band catches 18 of 20",
      length(g_real) == 20L && abs(rmse_ar2 - 0.767) < 0.005 && abs(rmse_rw - 0.932) < 0.005 && inside95 == 18L,
      sprintf("RMSE = %.4f / %.4f; inside the 95%% band = %d of 20 (sigma-hat = %.3f %%/qtr)",
              rmse_ar2, rmse_rw, inside95, sigma_pct))


# ---- 6. the loss functions behave -------------------------------------------
# huber() is the quadratic for |e| <= delta and the linear branch beyond;
# asym_loss() at alpha = 0.5 is half the MAE; on a fixed skewed sample, a grid
# search finds the MSE-minimising constant at the mean and the MAE-minimising
# constant at the median.
e_grid <- seq(-5, 5, by = 0.01); delta <- 2
hub    <- huber(e_grid, 0, delta)
hub_by_hand <- ifelse(abs(e_grid) <= delta, 0.5 * e_grid^2, delta * (abs(e_grid) - 0.5 * delta))
set.seed(6376)
x_fixed <- rexp(201) - 1                              # odd n: a unique median
f_fixed <- rep(0, 201)
asym_ok <- abs(asym_loss(x_fixed, f_fixed, 0.5) - 0.5 * mae(x_fixed, f_fixed)) < 1e-12
c_grid  <- seq(min(x_fixed), max(x_fixed), length.out = 40001)
c_mse   <- c_grid[which.min(vapply(c_grid, function(cc) mean((x_fixed - cc)^2), 0))]
c_mae   <- c_grid[which.min(vapply(c_grid, function(cc) mean(abs(x_fixed - cc)), 0))]
spacing <- c_grid[2] - c_grid[1]
check("huber() is quadratic-then-linear; asym_loss(alpha = 0.5) is MAE/2; MSE picks the mean, MAE the median",
      max(abs(hub - hub_by_hand)) < 1e-12 && asym_ok &&
        abs(c_mse - mean(x_fixed)) <= spacing && abs(c_mae - median(x_fixed)) <= spacing,
      sprintf("huber gap = %.1e; MSE argmin %.4f vs mean %.4f; MAE argmin %.4f vs median %.4f",
              max(abs(hub - hub_by_hand)), c_mse, mean(x_fixed), c_mae, median(x_fixed)))


# ---- 7. Gaussian coverage is Gaussian ---------------------------------------
# 2,000 one-step draws from a known AR(1) with Gaussian innovations: the band
# y-hat +/- 1.96 sigma contains y_{T+1} about 95% of the time.
set.seed(6376)
phi <- 0.7; n_draws <- 2000
y_T    <- rnorm(n_draws, 0, sqrt(1 / (1 - phi^2)))   # origins drawn from the stationary distribution
y_next <- phi * y_T + rnorm(n_draws)                  # the truth, one step on
covered <- mean(abs(y_next - phi * y_T) <= qnorm(0.975))
check("Known AR(1), Gaussian shocks: the 95% one-step band covers within 2 points of 95% over 2,000 draws",
      abs(covered - 0.95) < 0.02,
      sprintf("coverage = %.3f", covered))


# ---- verdict ----------------------------------------------------------------
n_pass <- sum(results)
n_all <- length(results)
cat(sprintf("---------------\n%d/%d checks passed.\n", n_pass, n_all))

# Inside a Quarto render, print failures without terminating knitr mid-document.
if (n_pass < n_all && !isTRUE(getOption("knitr.in.progress"))) {
  quit(status = 1, save = "no")
}
