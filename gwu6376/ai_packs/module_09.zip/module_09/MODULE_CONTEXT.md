# Module 9 Context — Granger Causality in Dynamic Regression

**Econ 6376 — Applied Time Series Econometrics, George Washington University (Applied Economics MA).**

This file is self-contained. Paste or upload it on its own into any AI
assistant and it will have everything it needs to help with Module 9.

<!-- BEGIN COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

## Course-wide conventions

These apply to every module of Econ 6376, not just this one.

### The master equation

Every model in this course is the following equation with some terms switched off:

$$y_t = \alpha + \delta t + \sum_{j=1}^{p} \phi_j y_{t-j} + \sum_{l=1}^{q} \theta_l \epsilon_{t-l} + \epsilon_t$$

The course analogy is a **mixing board**: each term is a slider, and each module
turns on new ones. A student should always be able to say where the model in
front of them sits on that board. If they can't, the framing has failed — help
them locate it.

### The cardinal notation rule: DGP vs. estimation

A data-generating process and an estimating equation look different, and the
course is strict about this.

- **DGP (the truth, unobservable):** unhatted parameters $\alpha, \delta, \phi_j, \theta_l, \beta$ and $\epsilon_t$, the **innovation**.
- **Estimating equation (your model, observable):** hatted parameters $\hat\alpha, \hat\phi_j, \hat\theta_l, \hat\beta$ and $e_t$, the **residual**, where $e_t = y_t - \hat y_t$.

Never write $\epsilon_t$ when you mean $e_t$. Never drop a hat from an estimate.
A well-specified model leaves residuals that behave like the innovations that
model assumes — that is the entire basis of diagnostic testing later in the course.

### Other standing conventions

- **Lag polynomials:** AR takes minus signs, $\Phi(L) = 1 - \phi_1 L - \cdots - \phi_p L^p$. MA takes plus signs, $\Theta(L) = 1 + \theta_1 L + \cdots + \theta_q L^q$.
- **Stationarity framing:** all roots of $\Phi(L) = 0$ lie strictly **outside** the unit circle. Enders and the older course slides use the equivalent characteristic-root-**inside** framing (related by $r = 1/L$). Both are correct; flag the difference whenever a student is cross-referencing a textbook.
- **Symbols:** $\phi$ = AR coefficients, $\theta$ = MA, $\beta$ = covariates, $\alpha$ = intercept, $\delta$ = trend. $\gamma_k$ = autocovariance at lag $k$, $\rho_k$ = autocorrelation, $\gamma_0 = \operatorname{Var}(y_t)$. $L$ = lag operator, $\Delta = (1-L)$. $t = 1,\ldots,T$.
- **"Stationary"** means weakly (covariance) stationary unless stated otherwise.
- **Language:** the course is taught in R. Students may submit graded work in another language if they can reproduce the workflow, but help and debugging are R-first. Plots use `ggplot2`.
- **Credentials:** FRED keys come from `Sys.getenv("FRED_KEY")`, never hardcoded, never committed.

### Working rules

- Concept before math, always. Intuition first, then notation.
- Simulation is the center of gravity, and a simulation that only confirms the textbook is half an exercise. Breaking an assumption is where understanding happens.
- The four-step rhythm for any major topic: **Concept → Math → Simulate (break something) → Real Data.**
- The student-facing learning protocol: **Predict → Commit → Ask AI → Test in R → Reconcile.**
- **Core is the assessable surface.** Course notes are tiered (Core / Deeper Dive / Technical Note / Looking Ahead). Problem sets and exams draw **only** on Core. Optional tiers are genuinely optional — never imply otherwise.

<!-- END COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

---

## What Module 8 established

ARDL adds current and lagged observed $x$ to outcome lags:
$y_t=\alpha+\sum_{j=1}^{p}\phi_jy_{t-j}+\sum_{\ell=0}^{q}\beta_\ell x_{t-\ell}+\epsilon_t$.
Exogeneity is a conditional-mean restriction on a stated information set; clean
residuals do not certify it. Specifications are compared on common rows.
Forecasts use a tilde, $\tilde y_{t+h\mid t}$; hats mark estimates and fitted
values. The claims/unemployment application reached a lag-only ARDL with
$(p,q)=(6,3)$ in exploratory training work, with residual dependence remaining.

## What Module 9 is about

**Does the past of $x$ add information for predicting $y$ beyond what is
already used — and what does an answer *not* tell us?** Scalar ARDL regressions
only: one outcome equation at a time; the reverse direction is a second
regression, not a system. No VAR machinery.

Mixing board: **no new slider.** Module 8's ARDL board (outcome lags on,
observed-predictor lags on, explicit MA block and trend off). The Granger test
asks what is lost by switching the **lagged-$x$ block** off. The current-$x$
term $\beta_0x_t$ is excluded from both regressions in the past-only comparison.

Lab map: 2 predictive question and within-period effects · 3 joint F test ·
4 one-way simulation and unequal-rows break · 5 common driver and a false
rejection · 6 claims/unemployment · 7 uses and limits · 8 optional ECM algebra ·
9 optional explorations · 10 checks.

### Core learning objectives

1. Explain Granger causality as incremental, directional, conditional predictive information.
2. Distinguish it from an intervention effect, contemporaneous (instantaneous) dependence, and a claim that variables are unrelated; explain how data timing can change the answer.
3. Recognize uses in economics (money–income, Phillips-curve questions) and in brain-signal analysis.
4. Write a joint lag-exclusion null, fit restricted and unrestricted ARDLs on the same observations, and calculate their F.
5. Test both directions separately, inspect diagnostics, explain why lag choices and conditioning information matter.
6. Distinguish a restriction-test result from held-out forecast performance; write a conclusion that respects the evidence.
7. Recognize why integrated levels and possible cointegration need more analysis before routine stationary-regression inference.

## 1. The definition

**The past of $x$ Granger-causes $y$ if it contains information useful for
predicting $y$ beyond the past of $y$ and the other information specified in
the comparison.** Main examples: next observation, conditional mean.

- **Incremental:** forecast with versus without $x$'s history. Correlation is not enough.
- **Directional:** $x\to y$ and $y\to x$ are separate questions; both, one, or neither may hold.
- **Conditional:** state what else is known. A signal can be useful when another variable is missing and redundant once it is included.

Shorthand: $H_0: x\not\rightarrow y$, $H_1: x\rightarrow y$. The arrows stand for
the joint restriction on the **whole included lag block**, conditional on the
specified own lags, lag lengths, and other information.

The practical test uses a **finite linear lag model**; conclusions should name
lags and conditioning variables. Nonrejection does not rule out nonlinear,
other-horizon, or distributional effects. In a population, extra information
cannot worsen the best forecast; in a sample, extra estimated coefficients can.

## 2. What it does not establish

Hamilton's thesis (§11.2) is the module's thesis: these are tests of whether one
series **helps forecast** another, not of whether it **causes** it; they bear on
causation only together with further assumptions. (His oil-price example: a
causal reading is supported only because it is combined with a stated
assumption about where oil shocks come from.) Paraphrase it.

- **Signal versus lever.** Claims can signal a labor-demand deterioration
  without being a policy lever. With an omitted common driver, past $x$ may
  genuinely help forecast $y$; the mistaken step is declaring that $x$ directly
  changes $y$.
- **Expectations reverse the story.** In Hamilton's present-value example,
  prices are set by expected dividends and do not affect dividends, yet past
  prices predict dividends and not the reverse.
- **Within-period effects.** The working DGP with a same-period term:

$$y_t=\alpha+\sum_{j=1}^{p}\phi_jy_{t-j}+\beta_0x_t+\sum_{\ell=1}^{q}\beta_\ell x_{t-\ell}+\epsilon_t.$$

  $\beta_0x_t$ ($\ell=0$) is the contemporaneous channel; **the Granger null
  concerns $\beta_1,\ldots,\beta_q$ only.** The past-only comparison leaves
  $x_t$ out of both regressions and does not test $\beta_0$. A same-period link
  is **instantaneous causality** (Granger, 1969); software such as
  `vars::causality` reports a test of it. Same-period dependence (e.g.,
  correlated current innovations) is symmetric and cannot by itself order the
  variables. With iid $x_t$ and $y_t=\beta_0x_t+\epsilon_t$, a past-only test
  misses a real within-period effect. Putting $x_t$ in **both** regressions
  asks a different question (earlier $x$ given current $x$); putting it
  **inside the tested block** makes a joint instantaneous-plus-lagged test.
- **Data timing.** Results describe observations as dated and published.
  (i) *Frequency and temporal aggregation* can push a one-week response into
  the same month (instantaneous), or create or remove apparent lagged content.
  (ii) *Seasonal adjustment* filters, applied separately to each series, can
  distort lag relations; two-sided historical adjustment uses later data.
  (iii) *Release timing*: the observation label is not the publication date.
  State frequency, aggregation, adjustment, and information timing.

| Finding | Defensible reading | Overstatement |
|---|---|---|
| Reject | Evidence against those linear exclusions, given an adequate model and valid inference | “Changing $x$ will change $y$” |
| Do not reject | Insufficient evidence against the restrictions with these data and lags | “No relationship” |
| Larger model wins a holdout | Better realized prediction under stated sample, timing, loss | “Mechanism identified” |
| Both directions | Predictive feedback under the stated histories | “Two structural effects” |

## 3. The test

Unrestricted: $y_t=\alpha+\sum_{j=1}^{p}\phi_jy_{t-j}+\sum_{\ell=1}^{q}\beta_\ell x_{t-\ell}+\epsilon_t$;
restricted drops the $x$ block and **re-estimates** everything else.
$H_0:\beta_1=\cdots=\beta_q=0$; $H_1$: at least one $\beta_\ell\ne0$.
**ARDL $q$ here is the number of predictor lags, not an MA order.** The null is
not one insignificant lag, and not $\sum\beta_\ell=0$.

Hold fixed: dependent observations, own lags, deterministic terms, retained
controls. Build the complete lagged sample **before** fitting either model; if
one model loses twelve rows and the other three, restrict both to common rows.
Adding a control changes the information-set question.

$$F=\frac{(RSS_R-RSS_U)/q}{RSS_U/(n-k_U)},$$

$n$ = common usable observations; $k_U$ = all unrestricted coefficients
**including the intercept**. On common rows $RSS_U\le RSS_R$; a negative
reduction signals an error. The $F(q,n-k_U)$ reference is an **approximation
under maintained time-series assumptions** with lagged dependent variables
(stable adequate conditional mean, regular innovations, variance assumptions),
not an exact law. Worked example: $n=120$, intercept + 2 own + 3 $x$ lags,
$RSS_R=108$, $RSS_U=90$ → $k_U=6$, $q=3$, $F=(18/3)/(90/114)=7.6$.

In R: `anova(restricted, unrestricted, test = "F")` on a data frame of dated lag
columns with `na.action = na.fail`. Course helpers in `R/granger_utils.R`:
`granger_nested_test()` returns $n$, $q$, $k_U$, both RSS, $F$, df and p, and
**refuses** mismatched outcomes, rows, or non-nested designs;
`granger_bg_test(fit, order = 12)` is the Breusch–Godfrey auxiliary regression
($n_aR_a^2$ vs. asymptotic $\chi^2(12)$, first `order` rows dropped). BG is a
residual-dynamics warning, not an exogeneity test. `lmtest::grangertest()` forces
equal own and predictor lag orders in a bivariate model — do not substitute it
silently for a different specification.

**Reverse direction:** make $x_t$ the outcome with its own lags and test the
$y$-lag block. New regression, new null. Conditional heteroskedasticity may call
for a robust Wald test of the same restrictions; that changes inference, not the
question, and does not repair a missing conditional-mean dynamic.

## 4. Simulations with a known mechanism

**A (one-way):** $x_t=0.55x_{t-1}+\epsilon_{x,t}$, $y_t=0.4y_{t-1}+0.6x_{t-1}+\epsilon_t$,
seed 6376091, 600 rows after 200 burn-in. $x\to y$ rejects decisively; the
reverse does not (p ≈ 0.30); $\hat\beta_1\approx0.600$, agreement after rounding,
not exact recovery. Any finite sample can falsely reject or miss.

**B (common driver):** news $z_t$ iid; $x_t=z_t+\eta_t$;
$y_t=0.4y_{t-1}+0.8z_{t-1}+\epsilon_t$; seed 6376092. No $x$ in the $y$
equation. Own history only: $x_{t-1}$ helps (population coefficient
$0.8\cdot\tfrac12=0.4$, since $E(z_{t-1}\mid x_{t-1})=x_{t-1}/2$) — **genuine
predictive information, not a false positive.** Own history plus $z_{t-1}$:
population cross-lag coefficient zero, yet this kept draw gives p ≈ 0.0157 —
**a false rejection of a true null in this sample**, deliberately retained. A
seeded 200-sample repeat rejects ≈ 4.5% of the time, as the size promises.
Intervening on recorded $x$ (holding $z$, initial $y$, innovations) leaves $y$
unchanged.

## 5. Application: claims and unemployment

$y_t=\Delta U_t$ (percentage points); $x_t=100\Delta\log C_t$, where $C_t$ is the
**mean** of weekly initial claims whose week-ending Saturdays fall in month $t$
(not a monthly total). Both seasonally adjusted (by different agencies, BLS and
DOL, and revised). Training 1990-01–2017-12 (**336 rows**); evaluation
2018-01–2019-12 (**24 rows**); 1989 pads differences and lags. Cached revised
data: revised-data pseudo-out-of-sample, not real-time vintages.

Timing: $U_t$ refers to the CPS reference week (containing the 12th), released
early in $t+1$. $C_t$ averages weeks on both sides of that week, so $x_{t-1}$
is not a clean calendar lead. Claims are released Thursdays; by $U_t$'s release,
claims for month $t$'s reference week have been public about two weeks. The
past-only design omits them deliberately, so it **understates** claims'
practical nowcasting value. Origin: after both previous-month releases, before
the target unemployment release — usually a nowcast, information
$\mathcal I_t^{\mathrm{release}}$.

Specification: $p=6$ own lags, $q=3$ other-variable lags, each direction,
inherited from Module 8's exploratory work — **not a fresh prespecified test**;
the reverse reuses lags for comparability. Results: forward
$F\approx21.06$ on (3, 326), nominal p ≈ $1.7\times10^{-12}$, **BG(12) p ≈ 0.0031
— fails.** The application **stops** there: report the nominal arithmetic plus
the limitation; no validated verdict; do not add lags until both tests look
good. Reverse: p ≈ 0.146 (BG passes): “not detected with these lags.”

Fixed sensitivity menu $(p,q)=(3,1),(6,1),(6,3)$ on the same 336 rows: the
forward direction rejects in every row, but its shorter rows fail BG far more
decisively. **The reverse direction rejects at (3,1) and (6,1) but not at
(6,3)** — the verdict depends on lags. Hamilton notes this lag-length
sensitivity in the money–income literature; Enders frames the too-few/too-many
trade-off and recommends fixing lags in advance by a stated rule on a common
sample. Never report the preferred row.

Held-out one-step predictions (frozen coefficients, observed lags roll
forward; level $=U_{t-1}+\tilde y$): RMSE own history 0.1129, add claims 0.1057,
no change 0.1099 — a modest descriptive gain on 24 months. No ordinary
Diebold–Mariano p-value for these nested estimated models.

## 6. In-sample versus out-of-sample

The F-test judges a predictive idea by **in-sample** fit. Ashley, Granger and
Schmalensee (1980) argued for relying on out-of-sample forecasting. Trade-off:
in-sample tests can reward overfitting (Clark, 2004); a prechosen holdout costs
power (Inoue and Kilian, 2005). **Ashley and Tsang (2014) cross-sample
validation:** split at $\tau$, fit each side and predict the other, sum squared
prediction errors into a pseudo-F (not F-distributed, can be negative; bootstrap
inference; summarized over all $\tau$). **Cornwall, Mills, Sauley and Weng
(2019)** hold out blocks (dropping the following $p$ rows), compare restricted
and unrestricted held-out losses by posterior simulation; their Phillips-curve
application finds in-sample rejections alongside weak held-out evidence. (Their
methods' details are optional, not Core.) A lower in-sample RSS is mechanical;
a lower held-out loss is an empirical result.

## 7. Limits and reporting

Integrated levels can give lag-exclusion statistics nonstandard distributions;
“difference everything” can discard a long-run relationship's predictive
content. Recognizing this is Core; the machinery is Module 10. Report: outcome
and units, frequency, dates, lags and information, the excluded block, $n$, F
and df, nominal p, diagnostics, a bounded conclusion, any separate holdout
result, and that no intervention effect is identified. “We computed the test
but cannot give it the usual interpretation” is a legitimate finding.

## Vocabulary and common traps

**Granger causality:** incremental directional conditional predictive
information. **Instantaneous causality:** same-period dependence ($\beta_0$).
**Restricted/unrestricted:** nested fits differing only by the tested block.
**$k_U$:** all unrestricted coefficients incl. intercept. **BG:** residual
serial-correlation diagnostic. **Cross-sample validation:** Ashley–Tsang
out-of-sample comparison. **Nowcast:** predicting a current period before its release.

Misconceptions: Granger causality is causation; a rejection means intervening on
$x$ changes $y$; nonrejection means unrelated; testing one lag (or the sum)
tests the block; different row counts are fine; $k_U$ excludes the intercept;
the F reference is exact with lagged $y$; the common-driver bivariate finding is
a false positive; a true null cannot be rejected; a past-only test detects
same-period effects; same-period correlation reveals ordering; monthly labels
are calendar leads; tiny p means a large forecast gain; BG failure can be fixed
by adding lags until it passes; robust SEs repair a misspecified mean; in-sample
improvement guarantees held-out improvement; a textbook's “exogenous” in the
sense of no predictive feedback is the same as Module 8's conditional-mean and
intervention assumptions; routine p-values hold in integrated levels.

## Handoffs — optional previews, outside Module 9 Core

Module 10: for two $I(1)$ series, a stationary $y_t-c-\kappa x_t$ is a
cointegrating relationship. The ARDL(1,1) with current $x_t$ rearranges to
$\Delta y_t=\lambda(y_{t-1}-c-\kappa x_{t-1})+\beta_0\Delta x_t+\epsilon_t$,
$\lambda=\phi_1-1$, $c=\alpha/(1-\phi_1)$, $\kappa=(\beta_0+\beta_1)/(1-\phi_1)$
— algebra, not proof of cointegration ($\kappa$ keeps $\theta$ for MA). Later
VAR modules give both series equations.

**Preview license:** if a student asks for cointegration/ECM, VARs,
`vars::causality`, instantaneous-causality tests, or later machinery, build it
on request, label it a preview, and connect it back to Core — never deflect
the question merely because it comes later.
