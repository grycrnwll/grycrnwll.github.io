# Module 9 cached data

The lab runs offline. These files are content-identical to the course caches in
`data/` when stamped on 2026-10-29 (line endings can differ by checkout; the
values do not). They are the same series Module 8 used. They are revised
historical data, not a shared real-time vintage.

| File | Source and units | Coverage and provenance |
|---|---|---|
| `UNRATE.csv` | [FRED UNRATE](https://fred.stlouisfed.org/series/UNRATE), U.S. BLS, monthly seasonally adjusted unemployment rate, percent | 1948-01–2026-04. Course cache copied from the original slide cache on 2026-08-12. One known blank, 2025-10, lies outside the lab window. The original extraction date is not recorded. |
| `ICSA.csv` | [FRED ICSA](https://fred.stlouisfed.org/series/ICSA), U.S. Employment and Training Administration, weekly seasonally adjusted initial claims, number | 1989-01-07–2019-12-28: 1,617 consecutive week-ending Saturdays, no missing observations. Retrieved with the FRED connector on 2026-10-19. |

The unemployment input is 1988-12–2019-12, giving the December 1988 level
needed for January 1989's change. Claims are averaged over the Saturdays within
each month: a **mean of weekly counts**, not a monthly total. A week straddling
two months belongs to the month of its ending Saturday. The lab checks the
complete weekly sequence before aggregation; a missing week is an error, not
permission to average the remaining weeks.

The modeled variables are unemployment-rate changes (percentage points) and
100 times log changes in mean weekly claims (approximately percent growth).
1989 is padding for differences and up to six lags. Training is
1990-01–2017-12 (336 rows), evaluation 2018-01–2019-12 (24 rows). No missing
value is replaced by zero.

**Timing caveats.** The unemployment rate refers to the CPS reference week (the
week containing the 12th) and is released early the following month; claims are
released each Thursday for the week ending the previous Saturday. Each series is
seasonally adjusted separately by a different agency, and historical adjusted
values have been revised. The observation date in a CSV row is not its release
date, so these caches support a revised-data pseudo-out-of-sample exercise, not
a real-time vintage study.

To refresh intentionally, retrieve the same date ranges from the source FRED
series with `fredr` and a key read using `Sys.getenv("FRED_KEY")`, or download
the source CSVs. Preserve `observation_date` and the series-ID column; check
calendar completeness, record retrieval dates, and rebuild the lab and checks
(checks 5 and 6 pin numbers from these vintages). Do not silently replace a
frozen cache. Never commit a key or credentials.
