# Start Here — Module 9 AI Learning Pack

**Econ 6376: Applied Time Series Econometrics — Module 9, "Granger Causality in Dynamic Regression"**

This folder is a self-contained study environment. Point an AI assistant at it,
or upload pieces of it to a chat tool, and you get a tutor that knows this
course's notation, conventions, and the specific things students get wrong in
Module 9 — plus a lab you can actually run to check whether it's telling you the
truth.

Everything here runs with **no API key and no internet connection**.

This pack stands alone — you do not need the Module 8 pack to use it. If you
*did* work through the Module 8 pack, bring your `LEARNING_LOG.md` from it: your
last entry there (especially the remaining-uncertainty field) is the fastest way
to start your first Module 9 session.

---

## What's in the folder

| File | What it is |
|---|---|
| `START_HERE.md` | This map. |
| `MODULE_CONTEXT.md` | The module distilled: objectives, concepts, notation, vocabulary, misconceptions. Self-contained — this is the file you upload to a chat tool. |
| `AI_TUTOR_CONTRACT.md` | Instructions to the assistant about how to help you. Worth reading yourself so you know what to expect. |
| `AI_USE_GUIDE.md` | For you: what AI is good and bad at here, how to verify claims, and how disclosure works on graded work. |
| `module_09_lab.qmd` | The lab. Runnable Quarto/R, start to finish, as shipped. |
| `R/granger_utils.R` | Stamped canonical `granger_nested_test()` and `granger_bg_test()`. The lab builds the F statistic by hand first. |
| `R/checks.R` | Six assertions that referee the shipped data, F mechanics, simulations, and application. |
| `CHECKS.md` | What each check means and what a failure usually points to. |
| `data/UNRATE.csv`, `data/ICSA.csv` | Cached monthly unemployment and weekly initial claims, the same series Module 8 used. |
| `data/README.md` | Where the data came from, including the one gap you should know about. |
| `reference/module_09_notes.qmd` | **The full chapter** — your AI tutor can read and cite this. It's a copy for reading and citing, not for rendering in place. |
| `TEXTBOOK_MAP.md` | Where Module 9 topics live in Enders, Hamilton, and Hyndman & Athanasopoulos, plus a notation translation table. |
| `LEARNING_LOG.md` | Your private log. Never collected, never graded. |
| `CLAUDE.md`, `AGENTS.md` | Auto-loaded briefings for folder-aware AI tools. You don't need to read these. |

---

## Recommended order

1. **`MODULE_CONTEXT.md`**: read "What Module 8 established" and "What Module 9 is about", then stop at "Core learning objectives" if you want to predict before seeing the simulation's interpretation. Read the full context after the lab as a review sheet.
2. **`AI_USE_GUIDE.md`** — 5 minutes. Read this before you start asking an AI anything, not after.
3. **`module_09_lab.qmd`** — the main event. Open it in RStudio (or any Quarto-capable editor) and work through it section by section, running chunks as you go. Write each prediction down before you run its chunk — the gap between the two is the payoff.
4. **`reference/module_09_notes.qmd`** — when you want the full treatment of something the lab touched briefly. This is the course's chapter; the lab is the sandbox.
5. **`LEARNING_LOG.md`** — as you go, not at the end.

`TEXTBOOK_MAP.md` and `CHECKS.md` are references. Reach for them when you need them.

---

## Starting a session with an agentic CLI tool

If you're using Claude Code, Codex, or anything else that can read a folder:

1. Open a terminal in **this folder** (`ai_packs/module_09/`).
2. Start the tool. It will pick up `CLAUDE.md` or `AGENTS.md` automatically and read the contract.
3. Just say what you want to do. For example:
   - "I'm starting Module 9. Walk me through the lab section by section."
   - "Run section 5 and help me see why a signal can predict without being a lever."
   - "I think a Granger rejection proves causation. Challenge me."
   - "Show me why the F-test needs the same rows in both regressions."
   - "Help me design the temporal-aggregation experiment in exploration 3."

You don't need a special prompt. The folder is the prompt.

## Starting a session with a chat tool

If you're using a web chat interface (ChatGPT, Claude, Gemini, a local model):

1. Upload or paste **`MODULE_CONTEXT.md`** and **`AI_TUTOR_CONTRACT.md`**. These two are designed to work standalone and together fit inside a small context window — a local model on your laptop gets the same tutor as anyone else.
2. Add whichever lab section you're working on, if the tool can take it.
3. Then ask your question normally.

If the tool has a persistent "custom instructions" or "project" feature, put the
contract there once and you won't have to re-upload it every session.

---

## Picking up where you left off

Sessions end. Context windows reset. AI tools forget everything between
conversations, and they will not tell you they've forgotten.

**`LEARNING_LOG.md` is your thread of continuity.** It's the only thing in this
folder that accumulates *your* thinking rather than the course's. Two habits make
it work:

- Write in it *during* a session, not from memory afterward.
- Start a new session by pasting or pointing at your last entry: *"Here's where I got to last time — I predicted X, found Y, and I'm still unsure about Z. Let's pick up from Z."*

That single sentence rebuilds more useful context than a long re-explanation,
because it tells the tutor what you already know and — more usefully — what you
don't.

The log is private. It is never collected and never graded. It only works if you
write what you actually thought, including the parts that turned out to be wrong.

---

## If something breaks

Run this from the folder root:

```
Rscript R/checks.R
```

Six check lines come back, each PASS or FAIL, followed by a verdict. Passing
means these six documented assertions passed; it does not validate every
student modification or identify a causal effect. If one fails, `CHECKS.md`
explains what it asserts and what usually causes it to fail.

The lab needs R with `ggplot2` and `urca` installed. Rendering also
needs `knitr`, `rmarkdown`, and Quarto (bundled with recent RStudio). The standalone
checks use base R only. Once installed, no package or data download is needed.

In RStudio, open the lab and choose **Session → Set Working Directory → To
Source File Location** before running individual chunks. Check that `getwd()`
ends in `ai_packs/module_09` and `dir.exists("data")` is `TRUE`.

From this folder, render only the lab:

```text
quarto render module_09_lab.qmd
```

The stamped notes source under `reference/` is for reading and citing. Its
original relative paths belong to the full course repository; do not render
the folder recursively or render that reference copy in place.
