# The six checks — Module 9

Run `Rscript R/checks.R` from the pack root. Each check prints PASS or FAIL,
followed by a verdict. A failure returns a nonzero command-line exit status.
During a lab render, failures print without terminating the document. A runtime
error inside one check becomes a FAIL line and later checks still run; missing
or corrupt shared input files are setup failures and stop the script directly.

These checks cover the shipped data, test mechanics, simulations and
application. Passing does not validate every possible student edit, establish a
causal effect, or turn the application's nominal F-test into a validated
Granger-causality verdict. The script loads its stamped helper copy in a private
environment when sourced by the lab; it does not touch your objects.

| Check | What it asserts | What a failure usually means |
|---|---|---|
| 1. Data and calendar | 1,617 consecutive week-ending Saturdays; every month has 4 or 5 of them; the monthly claims value is the **mean** of those weeks; 372 merged months; lag columns are shifted copies built before slicing; 336 training rows and 24 evaluation rows; the known UNRATE blank (2025-10) lies outside the window. | A cache changed, a week was dropped or averaged away, months were summed rather than averaged, or lags were created after cutting the sample (losing pre-sample padding). |
| 2. F mechanics | On the forward (6,3) application regressions: the F computed by hand from the two RSS values equals `anova()`'s F and the helper's F; $q=3$, $k_U=10$ (intercept included), $n=336$, denominator df 326; the two fits share identical rows and outcomes; $RSS_U\le RSS_R$ in all six sensitivity pairs; the helper **refuses** a comparison whose two fits use different rows. | The two regressions were fitted on different rows, $k_U$ was counted without the intercept, the restricted model was not nested in the unrestricted one, or the helper's safety checks were edited out. |
| 3. Known one-way DGP | With the lab's seed (6376091), the cross-lag estimate rounds to 0.600 and the $x\to y$ test rejects decisively; a separate 20,000-observation draw gives an estimate within 0.02 of the DGP value 0.6. | The loop's timing changed (current instead of lagged $x$), the seed or burn-in changed, or lag columns were misaligned. The tolerance allows ordinary sampling error; this is not an exact-recovery claim. |
| 4. Common driver | With the lab's seed (6376092), the bivariate comparison rejects; the comparison that conditions on the actual news gives p between 0.015 and 0.0165 — the deliberately kept false rejection; large-draw cross-lag estimates sit near their population values, 0.4 without the news and 0 with it. | The seed, DGP or information set changed. If the large-draw conditional estimate is far from zero, the news variable is mis-dated. The pinned p-value reproduces one draw; it does not mean the test is miscalibrated (the lab's 200-sample repeat shows the size). |
| 5. Application | Forward F ≈ 21.058 with a tiny nominal p-value; the helper's BG(12) p-value (≈ 0.0031, a failure at 5%) matches an independent `lm()` auxiliary regression; reverse p ≈ 0.146; in the fixed sensitivity menu the reverse direction rejects at (3,1) and (6,1) but not (6,3), and the forward direction rejects in every row. | Data vintage, training endpoint, lag columns, BG row handling or the specification menu changed. A deliberate change needs a documented experiment, not edits that force this check to pass. |
| 6. Forecast information | Frozen-coefficient predictions are unchanged when current-period $y$, $x$, $U$ and $C$ in the evaluation rows are perturbed (only lagged columns enter); change errors equal reconstructed-level errors; the 2018–2019 RMSEs reproduce (own history 0.1129, add claims 0.1057, no change 0.1099). | Target-period information leaked into the predictors, the level was accumulated recursively instead of from observed $U_{t-1}$, or the models were refitted on the evaluation rows. |

The BG number uses the conventional asymptotic chi-squared reference under
maintained regression and homoskedasticity conditions. Because the lag lengths
were carried over from exploratory work, it is a diagnostic warning, not an
untouched confirmatory test. Matching it checks reproducibility, not validity of
every assumption.

## Helper behavior to keep in mind

`granger_nested_test(restricted, unrestricted)` takes two unweighted, full-rank
`lm` fits. It checks that their model-frame **row names** and outcomes match and
that every restricted design column appears, with identical values, in the
unrestricted design. Row names are not dates: two data frames with matching
default row names but different dates would pass this check, so build both fits
from the same data frame. Column matching is by name, so write the restricted
regressors the same way in both formulas. The nesting check uses an absolute
tolerance (`1e-10`) on the RSS difference, which is very tight for data on a
large scale.

`granger_bg_test(fit, order = 12)` requires an intercept and lags the residuals
in the order the fit stores them. It assumes the fit's rows are consecutive in
time. If `lm()` silently dropped rows in the middle of the sample (the default
`na.omit`), the lagged residuals would be misaligned without any error — another
reason to use `na.action = na.fail` on a complete common sample.

The stamped helper body is identical to the canonical course helper. These are
documented behaviors, not local corrections; nothing was changed in this pack.
