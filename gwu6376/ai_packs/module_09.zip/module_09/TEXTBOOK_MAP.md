# Textbook map — Module 9

Pointers and notation translations only; no textbook passages are reproduced.
Every precise location below is grounded in the instructor-authored text of
`reference/module_09_notes.qmd` (§§9.3, 9.4, 9.6, 9.8 and "Connection to the
Textbooks and Sources"). A pointer locates optional reading; it does not enlarge
the assessable Core boundary. **(verify)** means the course notes do not
document a precise edition-specific location; confirm it before citing.

| Concept | Enders, Applied Econometric Time Series, 4th ed. | Hamilton, Time Series Analysis (1994) | Hyndman / Hyndman and Athanasopoulos |
|---|---|---|---|
| Definition: prediction-based Granger causality; origins with Granger (1969) and Sims (1972) | Ch. 5 §8, pp. 303–309 | §11.2, pp. 302–309 (origin noted p. 302) | Not covered in the course notes **(verify)** |
| "Helps forecast" versus "causes"; oil-price example | **(verify)** | §11.2, pp. 307–308 | **(verify)** |
| Expectations reversing the predictive direction (stock prices and dividends) | — | §11.2, pp. 306–307 | — |
| Instantaneous (same-period) causality | Exact page **(verify)**; the course grounds the term in Granger (1969) | **(verify)** | **(verify)** |
| Restricted/unrestricted regressions and the joint F test | Ch. 5 §8, pp. 303–309 | §11.2, pp. 302–309; why the dynamic-regression reference is asymptotic | **(verify)** |
| Lag-length choice and its trade-off; fixing lags in advance on a common sample | Ch. 5 §8, p. 303 (trade-off) and p. 305 (choosing lags) | §11.2, p. 305 (sensitivity of money–income results to lag length and nonstationarity treatment) | **(verify)** |
| Money–income evidence across sample periods (Friedman and Kuttner) | Ch. 5 §8, p. 307 | — | — |
| Granger tests with nonstationary variables | Ch. 5 §8, pp. 307–309 | §18.2, p. 554 | **(verify)** |
| Granger causality in a cointegrated system; no standard F test there; cost of differencing | Ch. 6, pp. 358–359 and pp. 383–384 | §18.2, p. 554 | **(verify)** |
| Out-of-sample / cross-sample validation of predictive claims | Not covered by the course's textbook pointers; see Ashley and Tsang (2014) and Cornwall et al. (2019) in the notes | — | Time-series cross-validation background; exact section **(verify)** |

A dash means the course notes cite no location there and none is needed for this
module. These pointers do not certify that every paragraph in the cited section
uses exactly the course's maintained assumptions; read the surrounding
definition before importing a statement or formula.

## Translate before using a formula

| Textbook feature | Course translation |
|---|---|
| Enders's $a_j$ (or other letters) for autoregressive coefficients | Course $\phi_j$; observed-predictor lag coefficients are $\beta_\ell$. For other symbols, map each term by its role in the equation. |
| Lag orders counted differently (some texts count coefficients, or include current $x$ in the order) | Course $p$ = outcome's own lags; Granger $q$ = number of tested predictor lags $x_{t-1},\ldots,x_{t-q}$, not an MA order. Current $x_t$ is in neither regression of the past-only comparison. |
| Parameter counts in the F denominator | Course $k_U$ counts every unrestricted regression coefficient **including the intercept**; denominator df $=n-k_U$ on the common sample. Recount before comparing a textbook's degrees of freedom. |
| Systems written in vector or matrix form | Module 9 uses one scalar outcome equation at a time; the reverse direction is a second regression. VAR notation starts in Module 11. |
| "Exogenous" used to mean absence of predictive feedback | Not the same as Module 8's conditional-mean restriction or an intervention assumption. Say which meaning is in play. |
| Characteristic roots inside one | Equivalent to course lag-polynomial roots outside one. State which polynomial supplies the roots. |
| Residuals and innovations sharing one symbol | Course DGP parameters unhatted with $\epsilon_t$; estimates hatted, residuals $e_t$. |
| Forecasts written with hats | From Module 7 on, forecasts use $\tilde y_{t+h\mid t}$; $\hat y_t$ is an in-sample fitted value. |
| Error-correction adjustment written $\alpha$ | The Module 9 preview writes $\lambda=\phi_1-1$ and the long-run slope $\kappa$, keeping $\alpha$ for the intercept and $\theta$ for MA coefficients. |

For textbook symbols not translated here, ask the student for the actual
equation and map its terms by role. Do not guess a notation table from an
edition you have not inspected.
