# Module 9 referee: run Rscript R/checks.R from the pack root. Base R only.
# local=TRUE keeps the lab's objects intact when this script is sourced into a
# private environment. Passing these checks does not identify causality.
Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1")
source("R/granger_utils.R", local = TRUE)
results <- logical(0)
check <- function(label, passed, detail = "") {
  passed <- isTRUE(passed)
  results[[length(results) + 1L]] <<- passed
  cat(sprintf("%-4s %s%s\n", if (passed) "PASS" else "FAIL", label,
              if (nzchar(detail)) paste0("  [", detail, "]") else ""))
  invisible(passed)
}
run <- function(label, expr) {
  tryCatch(expr, error = function(e)
    check(paste(label, "could not run"), FALSE, conditionMessage(e)))
}

# Shared setup outside the individual guards prevents one failed check from
# removing another check's inputs. Missing/corrupt files stop setup directly.
unr <- read.csv("data/UNRATE.csv", stringsAsFactors = FALSE)
claims <- read.csv("data/ICSA.csv", stringsAsFactors = FALSE)
unr$observation_date <- as.Date(unr$observation_date)
claims$observation_date <- as.Date(claims$observation_date)
u <- unr[unr$observation_date >= as.Date("1988-12-01") &
           unr$observation_date <= as.Date("2019-12-01"), ]
u$y <- c(NA_real_, diff(u$UNRATE))
u$U_previous <- c(NA_real_, head(u$UNRATE, -1))
u <- u[u$observation_date >= as.Date("1989-01-01"), ]
claims$month <- as.Date(format(claims$observation_date, "%Y-%m-01"))
cm <- aggregate(ICSA ~ month, data = claims, FUN = mean)
d <- merge(u, cm, by.x = "observation_date", by.y = "month", all = TRUE)
merged_rows <- nrow(d)
names(d)[match(c("observation_date", "UNRATE", "ICSA"), names(d))] <- c("date", "U", "C")
d$x <- c(NA_real_, 100 * diff(log(d$C)))
for (j in 1:6) {
  d[[paste0("y_l", j)]] <- c(rep(NA_real_, j), head(d$y, -j))
  d[[paste0("x_l", j)]] <- c(rep(NA_real_, j), head(d$x, -j))
}
d <- d[d$date >= as.Date("1990-01-01"), ]
train <- d[d$date <= as.Date("2017-12-01"), ]
hold <- d[d$date >= as.Date("2018-01-01"), ]
fit_pair <- function(outcome, p, q) {
  other <- if (outcome == "y") "x" else "y"
  own <- paste0(outcome, "_l", seq_len(p))
  list(r = lm(reformulate(own, response = outcome), data = train, na.action = na.fail),
       u = lm(reformulate(c(own, paste0(other, "_l", seq_len(q))), response = outcome),
              data = train, na.action = na.fail))
}
fwd <- fit_pair("y", 6, 3)
cat("Module 9 checks\n---------------\n")

run("Check 1", {
  week_dates <- seq(as.Date("1989-01-07"), as.Date("2019-12-28"), by = "week")
  month_dates <- seq(as.Date("1990-01-01"), as.Date("2019-12-01"), by = "month")
  january_mean <- mean(claims$ICSA[claims$month == as.Date("1989-01-01")])
  lag_ok <- all(d$x_l1[-1] == head(d$x, -1)) && all(d$y_l1[-1] == head(d$y, -1)) &&
    all(d$x_l6[-(1:6)] == head(d$x, -6))
  data_ok <- identical(names(unr), c("observation_date", "UNRATE")) &&
    identical(names(claims)[1:2], c("observation_date", "ICSA")) &&
    identical(claims$observation_date, week_dates) && !anyNA(claims) &&
    all(as.POSIXlt(claims$observation_date)$wday == 6) &&
    all(claims$ICSA > 0) && all(table(claims$month) %in% c(4, 5)) &&
    merged_rows == 372 && identical(d$date, month_dates) && !anyNA(d) && lag_ok &&
    nrow(train) == 336 && nrow(hold) == 24 && sum(is.na(unr$UNRATE)) == 1 &&
    identical(unr$observation_date[is.na(unr$UNRATE)], as.Date("2025-10-01")) &&
    isTRUE(all.equal(cm$ICSA[1], january_mean))
  check("1. Complete Saturday calendar, 4-5 weeks per month, mean weekly aggregation, dated lags, 336 training and 24 evaluation rows",
        data_ok, sprintf("weeks=%d; months merged=%d; training=%d; evaluation=%d",
                         nrow(claims), merged_rows, nrow(train), nrow(hold)))
})

run("Check 2", {
  rss_r <- sum(residuals(fwd$r)^2); rss_u <- sum(residuals(fwd$u)^2)
  manual_F <- ((rss_r - rss_u) / 3) / (rss_u / (336 - 10))
  anova_F <- anova(fwd$r, fwd$u)[2, "F"]
  helper <- granger_nested_test(fwd$r, fwd$u)
  same_rows <- identical(rownames(model.frame(fwd$r)), rownames(model.frame(fwd$u))) &&
    isTRUE(all.equal(model.response(model.frame(fwd$r)), model.response(model.frame(fwd$u))))
  nested <- all(sapply(list(c("y", 3, 1), c("y", 6, 1), c("y", 6, 3),
                            c("x", 3, 1), c("x", 6, 1), c("x", 6, 3)), function(s) {
    f <- fit_pair(s[1], as.integer(s[2]), as.integer(s[3]))
    sum(residuals(f$u)^2) <= sum(residuals(f$r)^2)
  }))
  # Unequal rows: one-lag restricted fit keeps rows the three-lag fit drops.
  short <- data.frame(y = train$y, y_l1 = train$y_l1, x_l3 = c(NA, NA, NA, train$x_l1[-(1:3)]))
  refused <- inherits(tryCatch(granger_nested_test(lm(y ~ y_l1, data = short),
                                                   lm(y ~ y_l1 + x_l3, data = short)),
                               error = function(e) e), "error")
  check("2. Manual F = anova F = helper F on common rows; q=3, k_U=10, df=326; RSS_U <= RSS_R; unequal rows refused",
        same_rows && nested && refused &&
          abs(manual_F - anova_F) < 1e-8 && abs(manual_F - helper$F) < 1e-8 &&
          helper$q == 3 && helper$k_U == 10 && helper$df2 == 326 && helper$n == 336,
        sprintf("manual=%.6f; anova=%.6f; helper=%.6f", manual_F, anova_F, helper$F))
})

run("Check 3", {
  one_way <- function(n, burn, seed) {
    set.seed(seed)
    total <- n + burn + 1L
    ex <- rnorm(total); e <- rnorm(total)
    x <- y <- numeric(total)
    for (t in 2:total) {
      x[t] <- 0.55 * x[t - 1] + ex[t]
      y[t] <- 0.4 * y[t - 1] + 0.6 * x[t - 1] + e[t]
    }
    keep <- (burn + 2L):total
    data.frame(y = y[keep], x = x[keep], y_l1 = y[keep - 1L], x_l1 = x[keep - 1L])
  }
  lab <- one_way(600, 200, 6376091)
  lab_u <- lm(y ~ y_l1 + x_l1, data = lab)
  lab_p <- granger_nested_test(lm(y ~ y_l1, data = lab), lab_u)$p_value
  big <- one_way(20000, 200, 6376191)
  big_b <- unname(coef(lm(y ~ y_l1 + x_l1, data = big))["x_l1"])
  lab_b <- unname(coef(lab_u)["x_l1"])
  check("3. Known one-way DGP: lab draw's cross-lag estimate rounds to 0.600 and rejects; large sample near 0.6",
        abs(lab_b - 0.6) < 0.0005 && lab_p < 1e-6 && abs(big_b - 0.6) < 0.02,
        sprintf("lab estimate=%.4f; large-n estimate=%.4f", lab_b, big_b))
})

run("Check 4", {
  driver <- function(n, burn, seed) {
    set.seed(seed)
    total <- n + burn + 1L
    z <- rnorm(total); eta <- rnorm(total); e <- rnorm(total)
    x <- z + eta; y <- numeric(total)
    for (t in 2:total) y[t] <- 0.4 * y[t - 1] + 0.8 * z[t - 1] + e[t]
    keep <- (burn + 2L):total
    data.frame(y = y[keep], y_l1 = y[keep - 1L], x_l1 = x[keep - 1L], z_l1 = z[keep - 1L])
  }
  lab <- driver(600, 200, 6376092)
  pair_p <- granger_nested_test(lm(y ~ y_l1, data = lab), lm(y ~ y_l1 + x_l1, data = lab))$p_value
  cond_p <- granger_nested_test(lm(y ~ y_l1 + z_l1, data = lab),
                                lm(y ~ y_l1 + z_l1 + x_l1, data = lab))$p_value
  big <- driver(20000, 200, 6376192)
  pair_b <- unname(coef(lm(y ~ y_l1 + x_l1, data = big))["x_l1"])
  cond_b <- unname(coef(lm(y ~ y_l1 + z_l1 + x_l1, data = big))["x_l1"])
  check("4. Common driver: pairwise signal rejects; kept conditional draw is a false rejection (p near 0.0157); population targets 0.4 and 0",
        pair_p < 1e-6 && cond_p > 0.015 && cond_p < 0.0165 &&
          abs(pair_b - 0.4) < 0.03 && abs(cond_b) < 0.03,
        sprintf("conditional p=%.5f; large-n pairwise=%.4f; conditional=%.4f", cond_p, pair_b, cond_b))
})

run("Check 5", {
  rev <- fit_pair("x", 6, 3)
  fwd_test <- granger_nested_test(fwd$r, fwd$u)
  rev_test <- granger_nested_test(rev$r, rev$u)
  bg <- granger_bg_test(fwd$u, order = 12)
  # Independent BG calculation with lm() on the same auxiliary rows.
  e <- residuals(fwd$u)
  aux <- data.frame(e = e, model.matrix(fwd$u)[, -1, drop = FALSE])
  for (j in 1:12) aux[[paste0("e_l", j)]] <- c(rep(NA_real_, j), head(e, -j))
  aux <- aux[13:nrow(aux), ]
  aux_fit <- lm(e ~ ., data = aux)
  bg_lm_p <- pchisq(nobs(aux_fit) * summary(aux_fit)$r.squared, 12, lower.tail = FALSE)
  sens_p <- function(o, p, q) { f <- fit_pair(o, p, q); granger_nested_test(f$r, f$u)$p_value }
  reverse_pattern <- c(sens_p("x", 3, 1), sens_p("x", 6, 1), sens_p("x", 6, 3)) < 0.05
  forward_pattern <- c(sens_p("y", 3, 1), sens_p("y", 6, 1), sens_p("y", 6, 3)) < 0.05
  check("5. Application: forward F and BG(12) failure, reverse nonrejection, reverse decision depends on lags",
        abs(fwd_test$F - 21.05813) < 1e-4 && fwd_test$p_value < 1e-10 &&
          bg$p_value > 0.0025 && bg$p_value < 0.0035 && abs(bg$p_value - bg_lm_p) < 1e-10 &&
          abs(rev_test$p_value - 0.14626) < 1e-4 &&
          identical(reverse_pattern, c(TRUE, TRUE, FALSE)) && all(forward_pattern),
        sprintf("forward F=%.4f; BG p=%.5f; reverse p=%.4f", fwd_test$F, bg$p_value, rev_test$p_value))
})

run("Check 6", {
  pred_r <- as.numeric(predict(fwd$r, newdata = hold))
  pred_u <- as.numeric(predict(fwd$u, newdata = hold))
  perturbed <- hold
  perturbed$y <- perturbed$y + 1000; perturbed$x <- perturbed$x - 1000
  perturbed$U <- perturbed$U + 1000; perturbed$C <- perturbed$C * 2
  no_leak <- isTRUE(all.equal(pred_u, as.numeric(predict(fwd$u, newdata = perturbed)))) &&
    isTRUE(all.equal(pred_r, as.numeric(predict(fwd$r, newdata = perturbed))))
  error_change <- hold$y - pred_u
  error_level <- hold$U - (hold$U_previous + pred_u)
  scores <- c(Own_history = sqrt(mean((hold$y - pred_r)^2)),
              Add_claims = sqrt(mean(error_change^2)), No_change = sqrt(mean(hold$y^2)))
  check("6. Frozen one-step predictions use only lagged inputs; change and level errors match; holdout RMSEs reproduce",
        no_leak && max(abs(error_change - error_level)) < 1e-12 &&
          max(abs(scores - c(0.1129422765, 0.1057472186, 0.1099242163))) < 1e-8,
        sprintf("RMSE=%.6f/%.6f/%.6f", scores[1], scores[2], scores[3]))
})

n_pass <- sum(results); n_all <- length(results)
cat(sprintf("---------------\n%d/%d checks passed.\n", n_pass, n_all))
if (n_pass < n_all && !isTRUE(getOption("knitr.in.progress"))) quit(status = 1, save = "no")
