# Start Here — Module 4 AI Learning Pack

**Econ 6376: Applied Time Series Econometrics — Module 4, "ARMA Modeling, Estimation, and Model Selection"**

This folder is a self-contained study environment. Point an AI assistant at it,
or upload pieces of it to a chat tool, and you get a tutor that knows this
course's notation, conventions, and the specific things students get wrong in
Module 4 — plus a lab you can actually run to check whether it's telling you the
truth.

Everything here runs with **no API key and no internet connection**.

This pack stands alone — you do not need the Module 3 pack to use it. If you
*did* work through the Module 3 pack, bring your `LEARNING_LOG.md` from it: your
last entry there (especially the remaining-uncertainty field) is the fastest way
to start your first Module 4 session.

---

## What's in the folder

| File | What it is |
|---|---|
| `START_HERE.md` | This map. |
| `MODULE_CONTEXT.md` | Objectives, framework, notation, numerical anchors, and misconceptions. The standalone context upload. |
| `AI_TUTOR_CONTRACT.md` | How the assistant should collaborate, execute, verify, and recap. |
| `AI_USE_GUIDE.md` | How to use AI productively, verify it, and disclose it on take-home work. |
| `module_04_lab.qmd` | The offline executable lab: compression → selection → IC → likelihood → Box-Jenkins → Monte Carlo → UNRATE. |
| `R/arma_simulator.R` | Stamped Module 3 simulator used to generate known ARMA data. |
| `R/model_selection.R` | Stamped `safe_fit()` and `fit_is_valid()` screening helpers. |
| `R/fetch_fred.R` | Optional live FRED pull. Needs a free API key. Nothing in the lab requires it. |
| `R/checks.R` | Seven legible assertions that referee the pack. |
| `CHECKS.md` | What each check means and what a failure usually indicates. |
| `data/UNRATE.csv` | Cached FRED unemployment data for the declared 1960–2019 application. |
| `data/ic_mc_summary.csv` | Verified summary of the full seed-1999, 500×9 Monte Carlo. |
| `data/README.md` | Data and Monte Carlo provenance, integrity details, and timing decision. |
| `reference/module_04_notes.qmd` | Fresh stamped copy of the canonical Module 4 chapter; read and cite, do not render here. |
| `TEXTBOOK_MAP.md` | Citation-only pointers and notation translations; no textbook text. |
| `LEARNING_LOG.md` | Your private, never-collected, never-graded study log. |
| `CLAUDE.md`, `AGENTS.md` | Byte-identical auto-loaded briefings for folder-aware tools. |

---

## Recommended order

1. **`MODULE_CONTEXT.md`** — 10 minutes. Gives you the shape of the module and the notation.
2. **`AI_USE_GUIDE.md`** — 5 minutes. Read this before you start asking an AI anything, not after.
3. **`module_04_lab.qmd`** — the main event. Open it in RStudio (or any Quarto-capable editor) and work through it section by section, running chunks as you go. Write each prediction down before you run its chunk — the gap between the two is the payoff.
4. **`reference/module_04_notes.qmd`** — when you want the full treatment of something the lab touched briefly. This is the canonical chapter; the lab is the sandbox.
5. **`LEARNING_LOG.md`** — as you go, not at the end.

`TEXTBOOK_MAP.md` and `CHECKS.md` are references. Reach for them when you need them.

---

## Starting a session with an agentic CLI tool

If you're using Claude Code, Codex, or anything else that can read a folder:

1. Open a terminal in **this folder** (`ai_packs/module_04/`).
2. Start the tool. It will pick up `CLAUDE.md` or `AGENTS.md` automatically and read the contract.
3. Just say what you want to do. For example:
   - "Walk me through the lab section by section."
   - "Before we score anything, help me choose a primary criterion for a forecasting goal."
   - "Run the 50-replication experiment and reconcile it with the cached 500-replication table."
   - "The UNRATE AIC and BIC rankings agree. Argue why that still does not validate the model."

You don't need a special prompt. The folder is the prompt.

## Starting a session with a chat tool

If you're using a web chat interface (ChatGPT, Claude, Gemini, a local model):

1. Upload or paste **`MODULE_CONTEXT.md`** and **`AI_TUTOR_CONTRACT.md`**. These two are designed to work standalone and together fit inside a small context window — a local model on your laptop gets the same tutor as anyone else.
2. Add whichever lab section you're working on, if the tool can take it.
3. Then ask your question normally.

If the tool has a persistent "custom instructions" or "project" feature, put the
contract there once and you won't have to re-upload it every session.

---

## Picking up where you left off

Sessions end. Context windows reset. AI tools forget everything between
conversations, and they will not tell you they've forgotten.

**`LEARNING_LOG.md` is your thread of continuity.** It's the only thing in this
folder that accumulates *your* thinking rather than the course's. Two habits make
it work:

- Write in it *during* a session, not from memory afterward.
- Start a new session by pasting or pointing at your last entry: *"Here's where I got to last time — I predicted X, found Y, and I'm still unsure about Z. Let's pick up from Z."*

That single sentence rebuilds more useful context than a long re-explanation,
because it tells the tutor what you already know and — more usefully — what you
don't.

The log is private. It is never collected and never graded. It only works if you
write what you actually thought, including the parts that turned out to be wrong.

---

## If something breaks

Run this from the folder root:

```
Rscript R/checks.R
```

Seven lines come back, each PASS or FAIL. If they all pass, the pack is intact and
the problem is in something you changed — which is fine, that's what the lab is
for. If one fails, `CHECKS.md` explains what that check asserts and what usually
causes it to fail.

The lab needs R with `ggplot2` and `forecast` installed. Those are the only package
requirements.
