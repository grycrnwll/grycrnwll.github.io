# Textbook Map — Module 4

Where Module 4's concepts live in the three books students most often read
alongside this course, and how to translate the notation when you get there.

**This file contains pointers and translations only — no textbook text.** If you
want to know what Enders *says*, read Enders. What this file does is get you to
the right pages and stop the notation from tripping you.

**How to read the pointers.** Page ranges are the ones used elsewhere in this
course's own notes, for the editions listed below. Where this course has never
pinned a page down, the pointer is at chapter level and says so. Nothing here is
guessed at the page level — if you find a discrepancy with your copy, trust your
copy and tell me. Cells marked **(verify)** are conventions or locations this
course has not documented explicitly; check your copy before relying on one.

**Editions assumed:** Enders, *Applied Econometric Time Series*, 4th ed.
Hamilton, *Time Series Analysis* (1994). Hyndman & Athanasopoulos, *Forecasting:
Principles and Practice*, 3rd ed., free online at <https://otexts.com/fpp3/>.

---

## Part A — Concept pointers

### Tentative identification and ARMA candidate fitting

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 72–75: sample ACF/PACF, tentative ARMA fits, and AIC/SBC comparisons. |
| Hamilton | Ch. 5, pp. 125–145: Gaussian ARMA likelihood and estimation; use for formal depth rather than the visual workflow. |
| fpp3 | Ch. 9: ARIMA modeling and estimation workflow; chapter-level pointer. |

### Box-Jenkins model selection, parsimony, and checking

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 76–79. |
| Hamilton | Ch. 5, pp. 125–145 for estimation; the applied Box-Jenkins checklist location is **(verify)**. |
| fpp3 | Ch. 9: ARIMA modeling; includes automated order selection and residual checking at chapter level. |

### Exact and conditional Gaussian likelihood

| Book | Where |
|---|---|
| Enders | Ch. 2, likelihood discussion near the ARMA estimation material **(verify page)**. |
| Hamilton | Ch. 5, especially pp. 125–145. This is the rigorous reference for exact and conditional likelihood. |
| fpp3 | Ch. 9: estimation section, chapter-level pointer. |

### AIC, AICc, and BIC/SBC

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 72–79 for AIC/SBC in ARMA selection. |
| Hamilton | Ch. 5 for likelihood; the book's information-criterion location is **(verify)**. |
| fpp3 | Ch. 9: AICc-based ARIMA selection and `auto.arima()` workflow, chapter-level pointer. |

### Forecast evaluation—the reason criterion goals matter

| Book | Where |
|---|---|
| Enders | Ch. 2, pp. 82–87. |
| Hamilton | Forecast-evaluation location **(verify)**. |
| fpp3 | Time-series cross-validation and forecast-accuracy chapters **(verify exact sections)**. |

### Primary sources named in the notes

- Box, G.E.P. and Jenkins, G.M. (1970), *Time Series Analysis: Forecasting and Control*—Box-Jenkins workflow.
- Akaike, H. (1974), “A New Look at the Statistical Model Identification,” *IEEE Transactions on Automatic Control*, 19, 716–723—AIC.
- Schwarz, G. (1978), “Estimating the Dimension of a Model,” *Annals of Statistics*, 6, 461–464—BIC/SBC.
- Hurvich, C.M. and Tsai, C.-L. (1989), “Regression and Time Series Model Selection in Small Samples,” *Biometrika*, 76, 297–307—AICc.
- Hyndman, R.J. and Khandakar, Y. (2008), “Automatic Time Series Forecasting: The forecast Package for R,” *Journal of Statistical Software*, 27(3)—`auto.arima()` search.

---

## Part B — Notation translation

Same mathematics, different alphabets. This is where most cross-referencing
confusion comes from.

Cells marked **(verify)** are conventions this course has not documented
explicitly — they match the common usage in those texts, but check your copy
before relying on one. Unmarked cells are conventions stated in this course's own
materials.

| Concept | This course | Enders | Hamilton / fpp3 |
|---|---|---|---|
| AR coefficient | $\phi_j$ | $a_i$ | $\phi_j$ **(verify local context)** |
| MA coefficient | $\theta_l$; $\Theta(L)=1+\sum\theta_lL^l$ | Check the local sign convention before translating **(verify)** | fpp3 software follows R's printed coefficient convention; Hamilton **(verify)** |
| Innovation / residual | $\epsilon_t$ / $e_t$ | Distinction not systematic **(verify)** | Distinction not systematic **(verify)** |
| ARMA order | $(p,q)$, or $(p,d,q)$ with differencing | Same order labels | Same order labels |
| Log-likelihood | $\ell(\boldsymbol\vartheta)$ | Local notation **(verify)** | Often $\mathcal L$ or $\ell$ **(verify)** |
| Parameter count in IC | $k$, including $\sigma^2$ and any process mean | Confirm the text's count in each displayed formula **(verify)** | Confirm the software/text count **(verify)** |
| Bayesian criterion | BIC | **SBC**—same formula | BIC |
| R printed `intercept` | Process mean $\hat\mu$ for stationary ARMA; $\hat\alpha=\hat\mu(1-\sum\hat\phi_j)$ | Translate from the text's intercept convention **(verify)** | fpp3 uses R objects; verify the local parameterization |
| Stationarity roots | Roots of $\Phi(L)=0$ outside unit circle | Characteristic roots inside | Hamilton uses lag-polynomial roots outside; fpp3 location **(verify)** |

### The four that actually cause problems

1. **Enders' SBC is this course's BIC.** The label differs; the $k\log T$ penalty does not.
2. **Check what $k$ counts.** The course's IC count includes innovation variance and any estimated mean. A table using only AR/MA coefficients is not on the same scale until reconciled.
3. **Check the MA sign before copying a coefficient.** A reversed polynomial convention reverses the reported $\theta$ while leaving the process unchanged.
4. **R's `intercept` is not automatically the course's $\alpha$.** For an undifferenced stationary fit, report it as $\hat\mu$ and translate before writing the recursion.
