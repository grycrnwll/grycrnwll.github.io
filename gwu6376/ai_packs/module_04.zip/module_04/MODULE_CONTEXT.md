# Module 4 Context — ARMA Modeling, Estimation, and Model Selection

**Econ 6376 — Applied Time Series Econometrics, George Washington University (Applied Economics MA).**

This file is self-contained. You can paste or upload it on its own into any AI
assistant and it will have everything it needs to help with Module 4.

<!-- BEGIN COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

## Course-wide conventions

These apply to every module of Econ 6376, not just this one.

### The master equation

Every model in this course is the following equation with some terms switched off:

$$y_t = \alpha + \delta t + \sum_{j=1}^{p} \phi_j y_{t-j} + \sum_{l=1}^{q} \theta_l \epsilon_{t-l} + \epsilon_t$$

The course analogy is a **mixing board**: each term is a slider, and each module
turns on new ones. A student should always be able to say where the model in
front of them sits on that board. If they can't, the framing has failed — help
them locate it.

### The cardinal notation rule: DGP vs. estimation

A data-generating process and an estimating equation look different, and the
course is strict about this.

- **DGP (the truth, unobservable):** unhatted parameters $\alpha, \delta, \phi_j, \theta_l, \beta$ and $\epsilon_t$, the **innovation**.
- **Estimating equation (your model, observable):** hatted parameters $\hat\alpha, \hat\phi_j, \hat\theta_l, \hat\beta$ and $e_t$, the **residual**, where $e_t = y_t - \hat y_t$.

Never write $\epsilon_t$ when you mean $e_t$. Never drop a hat from an estimate.
A well-specified model leaves residuals that behave like the innovations that
model assumes — that is the entire basis of diagnostic testing later in the course.

### Other standing conventions

- **Lag polynomials:** AR takes minus signs, $\Phi(L) = 1 - \phi_1 L - \cdots - \phi_p L^p$. MA takes plus signs, $\Theta(L) = 1 + \theta_1 L + \cdots + \theta_q L^q$.
- **Stationarity framing:** all roots of $\Phi(L) = 0$ lie strictly **outside** the unit circle. Enders and the older course slides use the equivalent characteristic-root-**inside** framing (related by $r = 1/L$). Both are correct; flag the difference whenever a student is cross-referencing a textbook.
- **Symbols:** $\phi$ = AR coefficients, $\theta$ = MA, $\beta$ = covariates, $\alpha$ = intercept, $\delta$ = trend. $\gamma_k$ = autocovariance at lag $k$, $\rho_k$ = autocorrelation, $\gamma_0 = \operatorname{Var}(y_t)$. $L$ = lag operator, $\Delta = (1-L)$. $t = 1,\ldots,T$.
- **"Stationary"** means weakly (covariance) stationary unless stated otherwise.
- **Language:** the course is taught in R. Students may submit graded work in another language if they can reproduce the workflow, but help and debugging are R-first. Plots use `ggplot2`.
- **Credentials:** FRED keys come from `Sys.getenv("FRED_KEY")`, never hardcoded, never committed.

### Working rules

- Concept before math, always. Intuition first, then notation.
- Simulation is the center of gravity, and a simulation that only confirms the textbook is half an exercise. Breaking an assumption is where understanding happens.
- The four-step rhythm for any major topic: **Concept → Math → Simulate (break something) → Real Data.**
- The student-facing learning protocol: **Predict → Commit → Ask AI → Test in R → Reconcile.**
- **Core is the assessable surface.** Course notes are tiered (Core / Deeper Dive / Technical Note / Looking Ahead). Problem sets and exams draw **only** on Core. Optional tiers are genuinely optional — never imply otherwise.

<!-- END COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

---

## What Modules 2 and 3 established

Six facts this pack relies on, so it stands alone without the earlier packs:

1. Module 2 uses ADF, KPSS, plots, and the rule of thumb $\sigma_{\Delta y}/\sigma_y$ to decide how many differences $d$ a series needs. Its working decision is to model the unemployment rate in first differences.
2. An AR($p$) has a PACF that cuts off at $p$ and an ACF that tails off; an MA($q$) reverses that pattern.
3. An ARMA($p,q$) has an ACF and PACF that both tail off. The fingerprints identify the class but not the two orders.
4. Stationary AR processes have MA($\infty$) representations; invertible MA processes have AR($\infty$) representations. A finite ARMA can therefore compress long dynamics into a few coefficients.
5. `arma_simulator()` writes the DGP literally as the master equation and uses the course's MA-plus sign convention.
6. Module 3 ends on a known zero-mean ARMA(1,1), $\phi=0.6$, $\theta=0.4$, whose sample correlograms still do not announce $(1,1)$. That unresolved row is Module 4's starting point.

## What Module 4 is about

Module 4 asks how to choose and estimate an ARMA model once the correlograms
stop identifying its order. The answer is a workflow, not an oracle: declare a
candidate set and modeling goal, fit comparable candidates, rank them with
likelihood-based information criteria, then send the provisional winner to
Module 5 for residual diagnostics.

**On the mixing board, Module 4 adds no new non-seasonal slider.** The AR and MA
terms are already available. Module 4 chooses which are active and estimates
their settings. Seasonal terms remain off until Module 5.

### Core learning objectives

By the end of the module a student should be able to:

1. Explain the ARMA correlogram trap and connect it to the compression payoff of AR/MA isomorphism.
2. Explain why raw and adjusted $R^2$ are not the course's ARMA selection workflow.
3. Compute AIC, AICc, and BIC from a common log-likelihood, sample size, and parameter count.
4. Choose a primary criterion *before fitting*: BIC for explanation/parsimony, AIC or AICc for prediction.
5. Define likelihood correctly as density at the fixed observed data, viewed as a function of parameters.
6. Verify that conditional/CSS fitting of a zero-mean pure AR is OLS-like and explain why MA terms break the shortcut.
7. Fit a declared candidate grid with `forecast::Arima()`, screen failed fits, and compare a manual search with `forecast::auto.arima()` under matched policies.
8. Interpret both the verified 500-replication experiment and a smaller live Monte Carlo without treating either realized percentage as universal.
9. Apply the zero-mean candidate workflow to first-differenced pre-COVID UNRATE and hand a fitted, unchecked model to Module 5.

## Core concepts

### Isomorphism makes model selection necessary—and useful

For ARMA processes, both ACF and PACF tail off. This is not a defect in the
fingerprints. A stationary AR can be written as an MA($\infty$), and an
invertible MA as an AR($\infty$), so no finite cutoff need reveal the true
finite representation. A compact ARMA can represent dynamics that need many
terms in a pure AR or MA form. That compression is the benefit; non-unique
visual identification is the price.

On the seed-1985, $T=500$ ARMA(1,1), the two-coefficient ARMA has a maximized
log-likelihood 5.37 points above AR(2). AR(4) comes within 0.16, while AR(10),
with five times the AR/MA coefficients, improves on the ARMA by only 2.58.
Because nested likelihood weakly rises as terms are added, fit alone cannot
tell us when to stop.

Raw $R^2$ cannot solve this: it weakly rises whenever a regressor is added.
Adjusted $R^2$ applies a regression degrees-of-freedom correction, but it is
not the likelihood-based ARMA score the course uses and lacks AIC's predictive
risk or BIC's selection motivation. The Core takeaway is simply: use AIC,
AICc, BIC, diagnostics, and later out-of-sample evaluation for ARMA selection.

### Information criteria: one shape, three prices

For comparable fits on the same estimation sample and under one likelihood
convention,

$$\text{IC}=-2\ell(\hat{\boldsymbol\vartheta})+\text{penalty}(k,T),$$

where smaller is better and $k$ counts **all estimated parameters**, including
$\sigma^2$ and any process mean.

$$\text{AIC}=-2\ell+2k,$$

$$\text{BIC}=-2\ell+k\log T,$$

$$\text{AICc}=\text{AIC}+\frac{2k(k+1)}{T-k-1}.$$

AICc is undefined when $T\le k+1$ and approaches AIC as $T$ grows. The course
rule of thumb is to prefer AICc to AIC when $T/k<40$. BIC's per-parameter
price exceeds AIC's for $T\ge8$.

Choose the primary score from the goal before revealing winners. AIC/AICc is
the prediction-oriented choice; BIC is the explanation/parsimony-oriented
choice when a sparse true model is plausibly in the candidate set. Report all
three. Agreement strengthens a shortlist; disagreement exposes sensitivity to
the price of complexity. Asymptotic efficiency and consistency are conditional
properties, not promises about one sample.

### Likelihood and the pure-AR bridge

For Gaussian ARMA,

$$L(\boldsymbol\vartheta\mid\mathbf y)=f_{\boldsymbol\vartheta}(\mathbf y),
\qquad
\hat{\boldsymbol\vartheta}_{\mathrm{MLE}}
=\arg\max_{\boldsymbol\vartheta}\ell(\boldsymbol\vartheta).$$

The data are fixed; candidate parameters move. Likelihood is a density value,
not the probability of an exact continuous sample, and it can exceed one.

For a zero-mean pure AR($p$), conditional Gaussian likelihood/CSS minimizes
the same squared one-step residuals as OLS on observed lagged values. On the
seed-1985 lab series, the AR(1) coefficient is 0.557331331 by CSS and
0.557331336 by no-intercept OLS. The default CSS-ML fit is 0.556945001 after
numerical ML polishing. Say **OLS-like for conditional pure AR**, not “MLE is
always OLS.” MA terms contain lagged innovations $\epsilon_{t-l}$ that are not
observed, so the optimizer must reconstruct them recursively.

Exact/unconditional ML handles the initial state in the joint density;
conditional/CSS conditions or initializes it; R's default `CSS-ML` uses CSS
starting values and finishes with numerical ML. There is no universal sample
size at which these estimators must agree to a fixed number of decimals.

For an undifferenced stationary ARMA, R prints the estimated process mean
$\hat\mu$ under the label `intercept`. Translate it to the course recursion as

$$\hat\alpha=\hat\mu\left(1-\sum_{j=1}^{p}\hat\phi_j\right).$$

For a zero-mean DGP or policy, set `include.mean = FALSE` explicitly.

### Box-Jenkins is the operating procedure

1. **Identification:** decide $d$ and write a short $(p,q)$ candidate set.
2. **Estimation:** fit every declared candidate under common sample, mean, and likelihood policies.
3. **IC scoring:** rank the fitted candidates under a criterion chosen from the goal.
4. **Diagnostic checking:** test whether the residuals behave like the assumed innovations—Module 5.
5. **Forecasting:** evaluate predictions out of sample—Block 4.

IC scoring sits between estimation and diagnosis. An unfitted order has no
score, and the lowest score is only the winner of the declared set, not a
validated model.

The pack stamps `safe_fit()` and `fit_is_valid()`. `safe_fit()` returns `NULL`
instead of stopping on an optimizer error and imposes the zero-process-mean,
`CSS-ML` policy. `fit_is_valid()` retains only non-null, converged fits with
finite coefficients, log-likelihood, AIC, AICc, and BIC. Do not rank an object
merely because R returned it.

### Evidence from one realization and 500 replications

For seed 1985, $T=500$, and the nine-candidate grid
$\{0,1,2\}\times\{0,1,2\}$ under a zero-mean policy, AIC and AICc choose
ARMA(2,2); BIC chooses the true ARMA(1,1). The comparable automatic AICc search
also chooses ARMA(2,2), with AICc 1415.84 versus 1416.65 for ARMA(1,1).

The shipped full experiment is cached evidence generated sequentially with
seed 1999: 500 Gaussian ARMA(1,1) replications, $T=500$, nine candidates each.
The screen rejects 72 of 4,500 candidate fits, while no replication loses every
candidate. AIC selects the true (1,1) 372/500 = **74.4%** of the time; BIC does
so 452/500 = **90.4%**. AIC's larger-model misses are visible; BIC's main miss
is AR(2), a same-dimension approximation.

The Core lab also runs only 50 deterministic replications with seed 4040 so a
student produces evidence instead of merely reading a cache. In the verified
build it selects truth 74% by AIC and 92% by BIC, rejects four candidate fits,
and has no all-failed replication. Those rates happen to be close to the full
experiment but are not supposed to match it: two realized Monte Carlos are
samples from the same experiment, not identities.

### Real data: the declared pre-COVID UNRATE design

The estimation window is January 1960 through December 2019: 720 monthly
levels and 719 first differences. April 2020's jump from 4.4 to 14.8 dominates
full-sample covariance estimates, so excluding the pandemic period is a stated
design choice, not silent data cleaning. Re-including it is an optional
sensitivity analysis.

The six nonseasonal candidates are ARMA(1,0), (0,1), (1,1), (2,1), (1,2), and
(2,2). The policy $\mathbb E[\Delta\text{UNRATE}_t]=0$ is imposed on every fit.
All three criteria and the comparable nonseasonal `auto.arima()` search select
ARMA(1,2). Its scores are AIC $=-549.333$, AICc $=-549.277$, and
BIC $=-531.021$. ARMA(2,2) trails by only 0.48 AIC points but 5.06 BIC points.

The provisional fit is

$$\Delta y_t=0.8638\Delta y_{t-1}-0.8963e_{t-1}+0.2319e_{t-2}+e_t.$$

The optimizer code is zero; the smallest fitted AR- and MA-root moduli are
1.158 and 2.077. These are sanity checks, not residual diagnostics. Residual
autocorrelations remain about $-0.145$, $-0.125$, and $-0.130$ at lags 12, 24,
and 36, outside the approximate $\pm0.073$ band. That supports adding seasonal
AR/MA candidates in Module 5; it does **not** establish a seasonal unit root or
justify $D=1$. UNRATE is already seasonally adjusted, so call the pattern
residual annual-lag dependence rather than raw calendar seasonality.

## Vocabulary

Correlogram trap · isomorphism · compression · parsimony · likelihood · density
· log-likelihood $\ell(\boldsymbol\vartheta)$ · maximum likelihood estimate ·
conditional likelihood · exact likelihood · CSS · deviance $-2\ell$ · parameter
count $k$ · AIC · AICc · BIC/SBC · predictive efficiency · selection
consistency · candidate set · mean policy · convergence code · Box-Jenkins ·
identification · estimation · IC scoring · diagnostic checking · residual $e_t$
· `stats::arima()` · `forecast::Arima()` · `forecast::auto.arima()`.

## Common misconceptions

Correct these when they appear, but correct them by asking a question or running
something, not by lecturing.

1. **“The lowest AIC model is the true model.”** It is the best AIC score in the declared set. The full Monte Carlo gives it a 25.6% miss rate under unusually favorable conditions.
2. **“AIC and BIC should agree.”** They charge different prices because they answer different questions. Disagreement is information.
3. **“BIC is better because it penalizes more.”** Harsher is not universally better. Choose from the goal.
4. **“I can choose my preferred criterion after seeing the table.”** That turns a modeling goal into answer shopping. Declare it first.
5. **“The parameter count is just $p+q$.”** IC also counts $\sigma^2$ and any estimated process mean.
6. **“Models with different samples or mean policies can be compared directly.”** IC rankings require common data and likelihood conventions.
7. **“Likelihood is the probability of the parameter or exact sample.”** It is density at fixed data, viewed as a function of parameters.
8. **“MLE is unrelated to OLS.”** Conditional pure-AR fitting is OLS-like under Gaussian innovations; MA terms are what force innovation reconstruction.
9. **“R's printed `intercept` is $\hat\alpha$.”** For stationary ARMA it is $\hat\mu$; translate before writing the recursion.
10. **“`auto.arima()` finds the correct model.”** It minimizes a chosen IC over a chosen path and restrictions. Match policies and read its work.
11. **“A returned fit is a usable fit.”** Check nulls, optimizer code, finite scores, and finite coefficients before ranking.
12. **“A residual spike at lag 12 proves seasonal differencing.”** It suggests seasonal dynamics. A seasonal unit root and $D=1$ require different evidence.

## The Module 4 → Module 5 handoff

Module 4 ends with a **fitted but unchecked** zero-mean ARMA(1,2) for
$\Delta\text{UNRATE}_t$. Module 5 asks whether its residuals behave like white
noise using residual correlograms and the Ljung-Box statistic, then widens the
candidate set to seasonal AR/MA structure if the annual-lag pattern survives.
If a student asks for those tools now, help and label them as a Module 5
preview; never treat a residual glance as a completed diagnosis.
