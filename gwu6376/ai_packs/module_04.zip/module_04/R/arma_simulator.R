# Stamped copy of arma_simulator() from helpers/simulators.R in the Econ 6376 course repo — behavior unchanged; edits belong in the canonical file.

arma_simulator <- function(
    n = 500,
    alpha = 0,
    phi = c(),
    theta = c(),
    sigma = 1,
    burn_in = 200) {
  # Simulate a general ARMA(p,q) process from the master equation.
  # y_t = alpha + sum(phi_j * y_{t-j}) + sum(theta_l * eps_{t-l}) + eps_t
  #
  # Arguments:
  #   n        : number of observations to return
  #   alpha    : intercept
  #   phi      : vector of AR coefficients (empty = pure MA)
  #   theta    : vector of MA coefficients (empty = pure AR)
  #   sigma    : standard deviation of innovations
  #   burn_in  : observations to simulate and discard
  #
  # Returns:
  #   A ts object of length n.

  p <- length(phi)
  q <- length(theta)
  total <- burn_in + n
  eps <- rnorm(total, 0, sigma)
  y <- numeric(total)

  for (t in seq_len(total)) {
    ar_part <- 0
    if (p > 0 && t > p) {
      ar_part <- sum(phi * y[(t - 1):(t - p)])
    }
    ma_part <- 0
    if (q > 0 && t > q) {
      ma_part <- sum(theta * eps[(t - 1):(t - q)])
    }
    y[t] <- alpha + ar_part + ma_part + eps[t]
  }

  ts(y[(burn_in + 1):total])
}
