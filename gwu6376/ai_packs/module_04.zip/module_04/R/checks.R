# =============================================================================
# checks.R — the referee for the Module 4 AI Learning Pack (Econ 6376)
#
# Seven assertions about the numerical claims and shipped evidence in Module 4.
# Run from the pack root:   Rscript R/checks.R
# Each check prints one PASS/FAIL line. Any FAIL exits with a nonzero status.
#
# This is deliberately readable evidence, not an answer key. If a tutor's claim
# contradicts a check, inspect the code and provenance before trusting either.
# CHECKS.md explains what every check establishes and what a failure suggests.
# =============================================================================

source("R/arma_simulator.R")
source("R/model_selection.R")

# ---- tiny test harness ------------------------------------------------------
# A failed assertion does not hide later checks.
results <- logical(0)

check <- function(label, passed, detail = "") {
  passed <- isTRUE(passed)
  results[[length(results) + 1L]] <<- passed
  cat(sprintf("%-4s %s%s\n",
              if (passed) "PASS" else "FAIL",
              label,
              if (nzchar(detail)) paste0("  [", detail, "]") else ""))
  invisible(passed)
}

cat("Module 4 checks\n---------------\n")


# ---- 1. conditional AR likelihood agrees with OLS --------------------------
# For a zero-mean pure AR(1), conditional sum of squares is the no-intercept
# regression y_t on y_{t-1}. The tiny optimizer tolerance is the only gap.
set.seed(1985)
y_ar <- arma_simulator(n = 500, phi = 0.6)
fit_css <- stats::arima(y_ar, order = c(1, 0, 0), include.mean = FALSE,
                        method = "CSS")
fit_ols <- lm(y_ar[-1] ~ 0 + y_ar[-length(y_ar)])
phi_css <- unname(coef(fit_css)["ar1"])
phi_ols <- unname(coef(fit_ols)[1])
check("CSS AR(1) coefficient matches the no-intercept OLS slope",
      abs(phi_css - phi_ols) < 1e-6,
      sprintf("CSS = %.9f, OLS = %.9f, absolute gap = %.2g",
              phi_css, phi_ols, abs(phi_css - phi_ols)))


# ---- 2. the information-criterion arithmetic is internally coherent --------
# safe_fit() reproduces forecast::Arima()'s documented AICc and BIC formulas
# without loading its compiled dependency stack. For zero-mean ARMA(1,1),
# k = phi + theta + sigma^2 = 3.
set.seed(1985)
y_known <- arma_simulator(n = 500, phi = 0.6, theta = 0.4)
fit_safe <- safe_fit(y_known, 1, 1)
k_known <- length(fit_safe$coef) + 1L
aicc_manual <- fit_safe$aic +
  2 * k_known * (k_known + 1) / (length(y_known) - k_known - 1)
bic_manual <- fit_safe$aic + k_known * (log(length(y_known)) - 2)
ic_gap <- max(abs(c(
  fit_safe$aicc - aicc_manual,
  fit_safe$bic - bic_manual
)))
check("AIC, AICc, and BIC use the documented k = 3 arithmetic",
      k_known == 3L && ic_gap < 1e-8,
      sprintf("k = %d, largest stored/formula gap = %.2g",
              k_known, ic_gap))


# ---- 3. the seeded nine-model example keeps its intended disagreement ------
orders <- expand.grid(p = 0:2, q = 0:2)
known_fits <- lapply(seq_len(nrow(orders)), function(i) {
  safe_fit(y_known, orders$p[i], orders$q[i])
})
known_valid <- vapply(known_fits, fit_is_valid, logical(1))
known_table <- data.frame(
  p = orders$p,
  q = orders$q,
  AIC = vapply(known_fits, function(fit) fit$aic, numeric(1)),
  AICc = vapply(known_fits, function(fit) fit$aicc, numeric(1)),
  BIC = vapply(known_fits, function(fit) fit$bic, numeric(1))
)
winner <- function(score) {
  row <- which.min(known_table[[score]])
  sprintf("(%d,%d)", known_table$p[row], known_table$q[row])
}
known_winners <- c(AIC = winner("AIC"), AICc = winner("AICc"),
                   BIC = winner("BIC"))
check("Seed 1985 makes AIC/AICc choose (2,2) and BIC choose (1,1)",
      all(known_valid) &&
        identical(unname(known_winners), c("(2,2)", "(2,2)", "(1,1)")),
      paste(names(known_winners), known_winners, collapse = ", "))


# ---- 4. failed candidates cannot leak into a ranking -----------------------
bad_code <- fit_safe
bad_code$code <- 1L
bad_score <- fit_safe
bad_score$aicc <- Inf
screen_ok <- fit_is_valid(fit_safe) &&
  !fit_is_valid(NULL) &&
  !fit_is_valid(bad_code) &&
  !fit_is_valid(bad_score) &&
  !any(grepl("intercept", names(fit_safe$coef), fixed = TRUE))
check("safe_fit() enforces convergence, finite scores, and zero process mean",
      screen_ok,
      sprintf("valid = %s; NULL/code/Inf rejected = %s/%s/%s; intercept absent = %s",
              fit_is_valid(fit_safe), !fit_is_valid(NULL),
              !fit_is_valid(bad_code), !fit_is_valid(bad_score),
              !any(grepl("intercept", names(fit_safe$coef), fixed = TRUE))))


# ---- 5. the complete 500 x 9 Monte Carlo cache is intact -------------------
mc <- read.csv("data/ic_mc_summary.csv", stringsAsFactors = FALSE,
               check.names = FALSE)
mc_key <- paste(mc$criterion, mc$model, sep = ":")
expected_counts <- c(
  "AIC:(0,0)" = 0, "AIC:(1,0)" = 0, "AIC:(2,0)" = 29,
  "AIC:(0,1)" = 0, "AIC:(1,1)" = 372, "AIC:(2,1)" = 27,
  "AIC:(0,2)" = 0, "AIC:(1,2)" = 36, "AIC:(2,2)" = 36,
  "BIC:(0,0)" = 0, "BIC:(1,0)" = 0, "BIC:(2,0)" = 42,
  "BIC:(0,1)" = 0, "BIC:(1,1)" = 452, "BIC:(2,1)" = 3,
  "BIC:(0,2)" = 0, "BIC:(1,2)" = 3, "BIC:(2,2)" = 0
)
cache_counts <- mc$count[match(names(expected_counts), mc_key)]
cache_ok <- identical(names(mc), c("criterion", "model", "count", "percent")) &&
  nrow(mc) == 18L &&
  !anyNA(cache_counts) &&
  all(unname(cache_counts) == unname(expected_counts)) &&
  all(abs(mc$percent - mc$count / 5) < 1e-12) &&
  all(tapply(mc$count, mc$criterion, sum) == 500) &&
  all(tapply(mc$percent, mc$criterion, sum) == 100)
check("The verified 500-replication Monte Carlo summary is complete and intact",
      cache_ok,
      sprintf("AIC truth = %d/500; BIC truth = %d/500; rows = %d",
              mc$count[mc_key == "AIC:(1,1)"],
              mc$count[mc_key == "BIC:(1,1)"], nrow(mc)))


# ---- 6. the smaller live experiment is deterministic -----------------------
run_live_check <- function(n_reps = 50L, seed = 4040L) {
  set.seed(seed)
  chosen_aic <- character(0)
  chosen_bic <- character(0)
  rejected <- 0L
  all_failed <- 0L

  for (rep in seq_len(n_reps)) {
    y <- arma_simulator(n = 500, phi = 0.6, theta = 0.4)
    fits <- lapply(seq_len(nrow(orders)), function(i) {
      safe_fit(y, orders$p[i], orders$q[i])
    })
    valid <- vapply(fits, fit_is_valid, logical(1))
    rejected <- rejected + sum(!valid)
    if (!any(valid)) {
      all_failed <- all_failed + 1L
      next
    }

    kept <- orders[valid, , drop = FALSE]
    kept_fits <- fits[valid]
    labels <- sprintf("(%d,%d)", kept$p, kept$q)
    chosen_aic <- c(chosen_aic, labels[which.min(vapply(
      kept_fits, function(fit) fit$aic, numeric(1)
    ))])
    chosen_bic <- c(chosen_bic, labels[which.min(vapply(
      kept_fits, function(fit) fit$bic, numeric(1)
    ))])
  }

  c(aic_truth = sum(chosen_aic == "(1,1)"),
    bic_truth = sum(chosen_bic == "(1,1)"),
    rejected = rejected,
    all_failed = all_failed)
}

live <- run_live_check()
live_aic_rate <- unname(live["aic_truth"]) / 50
live_bic_rate <- unname(live["bic_truth"]) / 50
live_ok <- live_aic_rate >= 0.50 && live_aic_rate <= 0.95 &&
  live_bic_rate >= 0.70 && live_bic_rate <= 1.00 &&
  live_bic_rate > live_aic_rate &&
  unname(live["rejected"]) <= 50 &&
  unname(live["all_failed"]) == 0
check("The 50-replication live run has the documented broad IC behavior",
      live_ok,
      sprintf("AIC truth = %d/50; BIC truth = %d/50; rejected = %d; all failed = %d",
              live["aic_truth"], live["bic_truth"], live["rejected"],
              live["all_failed"]))


# ---- 7. the pre-COVID UNRATE workflow keeps its declared data and winner ----
unrate_raw <- read.csv("data/UNRATE.csv", stringsAsFactors = FALSE)
unrate_raw$observation_date <- as.Date(unrate_raw$observation_date)
na_rows <- which(is.na(unrate_raw$UNRATE))
unrate_df <- subset(
  unrate_raw,
  observation_date >= as.Date("1960-01-01") &
    observation_date <= as.Date("2019-12-01")
)
delta_unrate <- diff(ts(unrate_df$UNRATE, start = c(1960, 1), frequency = 12))
unrate_orders <- data.frame(
  p = c(1, 0, 1, 2, 1, 2),
  q = c(0, 1, 1, 1, 2, 2)
)
unrate_fits <- lapply(seq_len(nrow(unrate_orders)), function(i) {
  safe_fit(delta_unrate, unrate_orders$p[i], unrate_orders$q[i])
})
unrate_valid <- vapply(unrate_fits, fit_is_valid, logical(1))
unrate_aic <- vapply(unrate_fits, function(fit) fit$aic, numeric(1))
unrate_aicc <- vapply(unrate_fits, function(fit) fit$aicc, numeric(1))
unrate_bic <- vapply(unrate_fits, function(fit) fit$bic, numeric(1))
winner_rows <- c(which.min(unrate_aic), which.min(unrate_aicc),
                 which.min(unrate_bic))
working_row <- which(unrate_orders$p == 1 & unrate_orders$q == 2)
working <- unrate_fits[[working_row]]
unrate_ok <- identical(names(unrate_raw), c("observation_date", "UNRATE")) &&
  nrow(unrate_raw) > 900L &&
  length(na_rows) == 1L &&
  identical(as.character(unrate_raw$observation_date[na_rows]), "2025-10-01") &&
  nrow(unrate_df) == 720L &&
  length(delta_unrate) == 719L &&
  !anyNA(delta_unrate) &&
  identical(as.character(range(unrate_df$observation_date)),
            c("1960-01-01", "2019-12-01")) &&
  all(unrate_valid) &&
  all(winner_rows == working_row) &&
  abs(working$aic - (-549.332681503)) < 1e-6 &&
  abs(working$aicc - (-549.276659094)) < 1e-6 &&
  abs(working$bic - (-531.021236072)) < 1e-6 &&
  !any(grepl("intercept", names(working$coef), fixed = TRUE))
check("The 1960-2019 zero-mean UNRATE grid is intact and selects ARMA(1,2)",
      unrate_ok,
      sprintf("levels = %d, changes = %d, winner rows = %s, AIC/AICc/BIC = %.3f/%.3f/%.3f",
              nrow(unrate_df), length(delta_unrate),
              paste(winner_rows, collapse = "/"),
              working$aic, working$aicc, working$bic))


# ---- verdict ----------------------------------------------------------------
n_pass <- sum(results)
n_all <- length(results)
cat(sprintf("---------------\n%d/%d checks passed.\n", n_pass, n_all))

# Inside a Quarto render, print failures without terminating knitr mid-document.
if (n_pass < n_all && !isTRUE(getOption("knitr.in.progress"))) {
  quit(status = 1, save = "no")
}
