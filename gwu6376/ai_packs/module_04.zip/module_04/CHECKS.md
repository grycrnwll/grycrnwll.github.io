# What the Checks Check

`R/checks.R` holds seven assertions about things Module 4 claims are true. Run
it from the pack root at any time:

```
Rscript R/checks.R
```

Each check prints one `PASS` or `FAIL` line with the numbers it computed. Any
failure makes the script exit with a nonzero status, so it works in a script or
a CI job as well as by hand. The last chunk of the lab runs it too — inside a
Quarto render it prints its results without killing the render.

**This is not an answer key.** The checks verify that the *code and data* behave
the way the module says they do. They cannot tell you whether your choice of
modeling goal, candidate set, or final working model is any good, and they don't
try. They exist so that when you and an AI tutor disagree about a fact, there's
a referee neither of you controls.

The file is deliberately written in plain base R — it needs neither `forecast`
nor `ggplot2`, even though the lab itself uses both. If a check confuses you,
read it — each one is a short, self-contained block. The whole script runs in a
few seconds; check 6 is the only Monte Carlo, and it is a small one.

---

## Check 1 — conditional AR likelihood meets OLS

**Asserts:** for a seeded zero-mean AR(1), `stats::arima(method = "CSS")` and a
no-intercept regression of $y_t$ on $y_{t-1}$ estimate the same coefficient to
within $10^{-6}$.

**Why:** this is the computational bridge from familiar regression to the
conditional Gaussian AR likelihood. A pure AR model does not require a new
estimation idea just because the observations are ordered in time.

**A failure usually means:** the simulator, seed, mean policy, AR order, or
conditional fitting method changed. A model with an intercept is a different
regression and should not be made to pass by loosening the tolerance.

## Check 2 — information-criterion arithmetic is coherent

**Asserts:** for the seeded ARMA(1,1), the manually computed AICc and BIC
formulas match the fields stored by `safe_fit()`. The parameter count is three:
one AR coefficient, one MA coefficient, and the innovation variance. The
helper's header documents why these are the same fields that
`forecast::Arima()` reports.

**Why:** IC rankings are meaningful only when every candidate uses one
likelihood convention and one parameter-count convention. The innovation
variance counts; an unrequested process mean does not appear by accident.

**A failure usually means:** `R/model_selection.R` no longer matches the
stamped course helper, the mean policy changed, or a formula dropped
$\sigma^2$ from $k$.

## Check 3 — one realization can make the criteria disagree

**Asserts:** all nine zero-mean candidates in
$(p,q)\in\{0,1,2\}^2$ fit the seed-1985 ARMA(1,1) realization; AIC and AICc
choose (2,2), while BIC chooses the true (1,1).

**Why:** the example is the lab's clean transition from formulas to judgment.
Truth is in the candidate set, yet the criteria pursue different goals and can
rank one finite realization differently.

**A failure usually means:** the seed, sample length, DGP, grid, mean policy,
or fitting method changed. It can also reveal an R/optimizer version change;
report that difference rather than silently rewriting the narrative.

## Check 4 — failed fits cannot win

**Asserts:** `fit_is_valid()` accepts the known converged fit, rejects `NULL`,
rejects a nonzero convergence code, rejects a non-finite IC, and confirms that
`safe_fit()` did not estimate an intercept.

**Why:** sorting an unchecked grid can turn an optimizer failure into a
scientific result. The screen makes candidate admissibility explicit before
ranking.

**A failure usually means:** one of the convergence, finiteness, coefficient,
or zero-mean safeguards was weakened. Restore the stamped helper instead of
teaching around the failure.

## Check 5 — the full Monte Carlo cache is the verified experiment

**Asserts:** `data/ic_mc_summary.csv` has its four documented columns, all 18
criterion-by-model rows, and the exact selection counts from the 500 by 9
production run. Counts and percentages sum to 500 and 100% within each
criterion. The headline truth counts are 372 for AIC and 452 for BIC.

**Why:** the complete experiment is shipped evidence, not a live classroom
wait. Exact pins prevent a partial rerun or edited zero-count row from being
presented under the full run's provenance.

**A failure usually means:** the cache was reordered incompletely, edited, or
replaced. Regenerate the full design deliberately with seed 1999, document the
software environment and rejected-fit count, then update the cache, prose, and
check together.

## Check 6 — the small live Monte Carlo is reproducible

**Asserts:** the default 50-replication run at seed 4040 stays inside broad,
predeclared safety bands: AIC truth selection from 50% through 95%, BIC from
70% through 100%, BIC above AIC, no more than 50 rejected candidate fits, and
no replication that loses all nine candidates. The printed current anchor is
37 AIC selections, 46 BIC selections, four rejected fits, and zero all-failed
replications; those exact counts are not the pass condition.

**Why:** students should be able to generate a quick experiment and distinguish
its sampling variation from the full cached result. The small run is separate
evidence; it is not a claim to reproduce 74.4% and 90.4% exactly.

**A failure usually means:** the seed, DGP, candidate grid, mean policy,
screen, or fitting method changed. Tiny optimizer differences across supported
R versions are possible; preserve and report them rather than changing the
seed until a preferred answer appears.

## Check 7 — the pre-COVID UNRATE workflow is pinned

**Asserts:** the shipped FRED cache keeps its two columns and sole documented
2025-10 gap; the declared January 1960 through December 2019 window has 720
levels and 719 complete first differences; all six declared candidates fit
under the zero-mean policy; and AIC, AICc, and BIC all choose ARMA(1,2), with
scores approximately $-549.333$, $-549.277$, and $-531.021$.

**Why:** dates, transformations, mean policy, and candidate set are part of the
model. This check prevents a live data revision, pandemic observation, hidden
interpolation, or enlarged grid from being mistaken for the documented Core
analysis.

**A failure usually means:** the data cache or estimation window changed, a
process mean was added, or the candidate grid no longer matches the lab. Treat
post-2019 data as a clearly labeled sensitivity analysis rather than weakening
this check.

---

## If a check fails and you can't work out why

Read the check. It's a few lines of base R and it prints the numbers it
computed alongside the target, so the gap between "what we expected" and "what
we got" is right there in the output.

If you're working with an AI tutor, show it the failing line, your R version,
*and* the relevant source file. "Check 3 fails — BIC now picks (2,2)" plus
`R/model_selection.R` is a solvable problem; "my checks fail" is not.
