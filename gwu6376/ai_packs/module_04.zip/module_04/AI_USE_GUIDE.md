# Using AI Well in This Course

**Econ 6376 — Module 4**

This is written for you, not for the assistant. It's about getting real value out
of an AI tutor instead of the appearance of value.

---

## The short version

AI is extraordinarily good at the things that used to waste your time in a course
like this — debugging R, explaining notation, generating variations of a
simulation, answering the question you were embarrassed to ask in class. Use it
for all of that, freely.

It is much less good at the thing this course actually grades: *judgment about
ambiguous evidence*. Whether a table where AIC picks ARMA(2,2) and BIC picks
ARMA(1,1) means "take the bigger model" is not a fact to be retrieved. It's a
call you make and defend.

Use AI to build the judgment. Don't use it to skip the judgment.

---

## Productive uses

- **Debugging quickly.** Give the error and the relevant chunk. A failed optimizer is evidence; a missing comma is not a character-building exercise.
- **Auditing comparability.** Ask whether every candidate used the same observations, zero-mean policy, and likelihood method before comparing IC.
- **Checking arithmetic.** Give $\ell$, $k$, and $T$ and have the tutor compute AIC, AICc, and BIC—then verify with R.
- **Being challenged.** State your model choice and ask the tutor to argue for the runner-up without changing the evidence.
- **Rubber-ducking.** Explain your choice of criterion and working model to the AI and let it find the hole. You'll often find it yourself mid-sentence.
- **Generating variations.** Shorten $T$, change the DGP, remove truth from the candidate set, or change the mean policy and see which lesson survives.
- **Reading software.** Ask why `stats::arima()`, `forecast::Arima()`, and `auto.arima()` show different fields or results under different defaults.
- **Translating a textbook.** Paste a short confusing passage and ask for its notation in course form; use `TEXTBOOK_MAP.md` first.
- **Chasing a hunch.** If the UNRATE lag-12 residual pattern interests you, turn that curiosity into a labeled sensitivity exercise while keeping Module 5's boundary clear. Your tutor is instructed to help you do this rather than steer you back to the syllabus.

## Unproductive uses

- **Asking for the winner before declaring the goal.** Pick explanation/parsimony or prediction first; otherwise the criterion choice becomes answer shopping.
- **Accepting a returned model object as a valid fit.** Read optimizer code and finite values. `R/model_selection.R` makes the screen explicit.
- **Treating cached evidence as a live run.** The 500-replication CSV is verified evidence generated earlier. The 50-replication Core run is what you execute now.
- **Expecting two Monte Carlos to match exactly.** Rates vary across simulated samples. Compare patterns and uncertainty, not digit-for-digit equality.
- **Letting automation hide policy changes.** `auto.arima()` can choose $d$, seasonality, drift, mean, and a search path unless you constrain it. Match the manual comparison before interpreting disagreement.
- **Calling the smallest IC "the correct model."** It is the best score in the candidate set. Module 5 still gets a vote.
- **Letting it write your log.** See below.
- **Using it as a search engine for the answer to a graded question.** Permitted, but see the section on assessed work — it doesn't work as well as it feels like it should.
- **Never disagreeing with it.** If you've gone ten sessions without once finding the AI wrong, you aren't checking. It is wrong regularly on this material.

---

## Verification habits

The pack is built so you never have to take anyone's word for anything — mine, or
your tutor's.

**Test claims in R.** Almost every claim in Module 4 is checkable in a few
lines. "BIC charges five parameters $5\log(200)$" — compute it. "CSS and OLS
coincide for a zero-mean pure AR" — fit both. "The 500-replication result
proves AIC always selects larger models" — inspect the full frequency table
and find the counterexample. If your tutor asserts something about this
material and you can't immediately see how to test it, ask it to write the test.

**Use `R/checks.R` as a referee.** It holds seven assertions about things this
module claims are true, in readable base R. Run `Rscript R/checks.R`
any time. If something you were told contradicts a passing check, the check wins.

**Watch for these specific failure modes.** In my experience they're the common
ones on this material:

- Counting only $p+q$ in an IC and forgetting $\sigma^2$ and any process mean.
- Comparing fits estimated on different samples or under different mean policies.
- Calling R's printed `intercept` the recursion intercept $\hat\alpha$; for stationary ARMA it is the process mean $\hat\mu$.
- Describing likelihood as a probability of the parameter or exact continuous sample rather than density at fixed data.
- Ranking a nonconverged fit because its AIC happens to be finite.
- Treating the pre-COVID window as a secret deletion rather than a declared design response to an extreme episode.
- Turning residual annual-lag dependence into an unsupported seasonal-difference decision.

**A good habit:** when the AI tells you something surprising, ask "how would I
check that in R?" before asking anything else. If it can't propose a check, be
suspicious of the claim.

---

## Graded work

**AI assistance is permitted on take-home graded work in this course** —
problem sets and the take-home midterm — **with disclosure.** The final is an
in-person, closed-book, paper-and-pencil exam, so no devices or AI may be used
during it. You may use this pack to prepare for the final.

Disclosure is a brief, free-form statement of how you used it. No form, no
template, no penalty. It just has to be honest and specific enough to be
meaningful. Two sentences is plenty:

> *I used ChatGPT to debug the candidate-screening loop in Question 2 and to
> check my AICc parameter count in Question 3. I chose and defended the primary
> criterion myself, after asking the model to argue for the other choice.*

That's a complete disclosure. Notice it says what was done *where* — "I used AI"
alone doesn't tell me anything.

Your `LEARNING_LOG.md` is **not** the disclosure vehicle. The log is private and
I never see it. Disclosure goes with the submitted work.

### Why pasting through answers won't carry you

I want to be straightforward about this rather than issue a warning.

The assessments in this course are built to be AI-resilient, and they draw
**only** on the Core tier of the module notes. They ask you to interpret
ambiguous output, reconcile two results that disagree, explain why a method
failed, and defend a judgment call. Those questions don't have retrievable
answers — the evidence is genuinely ambiguous, which is the point, and what gets
graded is the quality of your reasoning about the ambiguity.

An answer you didn't build, you can't defend. That shows up immediately in the
follow-up parts of a question, and it shows up badly on a take-home where you had
plenty of time.

So the policy isn't a trap. Using AI heavily and understanding the material are
completely compatible — that's the intended outcome, and it's how you'll work
professionally. Using AI heavily *instead of* understanding the material is a
strategy that fails at the assessment, and more importantly fails in the job
where nobody tells you which model to fit.

---

## About the contract

`AI_TUTOR_CONTRACT.md` asks your tutor to do things like request a prediction
before running a simulation, and to ask for your own words before writing the
last two fields of your learning log.

The prediction ask pauses for one turn — it will hand you two or three options
and wait once. Answer it, or say "just run it" and it runs immediately and drops
the question. It will not ask you twice, and you can tell it to skip predictions
entirely for the whole session. It's your session.

I'd just say plainly: the contract is there for your benefit, not as a rule
you're being held to. The prediction step exists because being surprised is how
things stick, and skipping it feels efficient in the moment and costs you in
November. Overriding it is a choice you're making about your own learning, and
you're an adult — I only want you making the choice knowingly rather than by
accident.

That's the last I'll say about it.

---

## Intellectual ownership

The point of this course is that you become someone who can take an unfamiliar
series, work out what it is, and defend a modeling decision to a skeptical room.

That capability is built by making predictions, being wrong, and figuring out
why. It is not transferable from a model, and it is not something you can borrow
under deadline. An AI can accelerate every step of building it — and it can also
let you produce work that looks like the finished product without any of the
building having happened.

Both paths are available to you here, and honestly, the second one is easier.
The difference shows up when you're the one in the room who has to say what the
data means.
