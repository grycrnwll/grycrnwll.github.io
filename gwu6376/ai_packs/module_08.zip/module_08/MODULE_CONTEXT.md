# Module 8 Context — Autoregressive Distributed Lag Models

**Econ 6376 — Applied Time Series Econometrics, George Washington University (Applied Economics MA).**

This file is self-contained. Paste or upload it on its own into any AI
assistant and it will have everything it needs to help with Module 8.

<!-- BEGIN COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

## Course-wide conventions

These apply to every module of Econ 6376, not just this one.

### The master equation

Every model in this course is the following equation with some terms switched off:

$$y_t = \alpha + \delta t + \sum_{j=1}^{p} \phi_j y_{t-j} + \sum_{l=1}^{q} \theta_l \epsilon_{t-l} + \epsilon_t$$

The course analogy is a **mixing board**: each term is a slider, and each module
turns on new ones. A student should always be able to say where the model in
front of them sits on that board. If they can't, the framing has failed — help
them locate it.

### The cardinal notation rule: DGP vs. estimation

A data-generating process and an estimating equation look different, and the
course is strict about this.

- **DGP (the truth, unobservable):** unhatted parameters $\alpha, \delta, \phi_j, \theta_l, \beta$ and $\epsilon_t$, the **innovation**.
- **Estimating equation (your model, observable):** hatted parameters $\hat\alpha, \hat\phi_j, \hat\theta_l, \hat\beta$ and $e_t$, the **residual**, where $e_t = y_t - \hat y_t$.

Never write $\epsilon_t$ when you mean $e_t$. Never drop a hat from an estimate.
A well-specified model leaves residuals that behave like the innovations that
model assumes — that is the entire basis of diagnostic testing later in the course.

### Other standing conventions

- **Lag polynomials:** AR takes minus signs, $\Phi(L) = 1 - \phi_1 L - \cdots - \phi_p L^p$. MA takes plus signs, $\Theta(L) = 1 + \theta_1 L + \cdots + \theta_q L^q$.
- **Stationarity framing:** all roots of $\Phi(L) = 0$ lie strictly **outside** the unit circle. Enders and the older course slides use the equivalent characteristic-root-**inside** framing (related by $r = 1/L$). Both are correct; flag the difference whenever a student is cross-referencing a textbook.
- **Symbols:** $\phi$ = AR coefficients, $\theta$ = MA, $\beta$ = covariates, $\alpha$ = intercept, $\delta$ = trend. $\gamma_k$ = autocovariance at lag $k$, $\rho_k$ = autocorrelation, $\gamma_0 = \operatorname{Var}(y_t)$. $L$ = lag operator, $\Delta = (1-L)$. $t = 1,\ldots,T$.
- **"Stationary"** means weakly (covariance) stationary unless stated otherwise.
- **Language:** the course is taught in R. Students may submit graded work in another language if they can reproduce the workflow, but help and debugging are R-first. Plots use `ggplot2`.
- **Credentials:** FRED keys come from `Sys.getenv("FRED_KEY")`, never hardcoded, never committed.

### Working rules

- Concept before math, always. Intuition first, then notation.
- Simulation is the center of gravity, and a simulation that only confirms the textbook is half an exercise. Breaking an assumption is where understanding happens.
- The four-step rhythm for any major topic: **Concept → Math → Simulate (break something) → Real Data.**
- The student-facing learning protocol: **Predict → Commit → Ask AI → Test in R → Reconcile.**
- **Core is the assessable surface.** Course notes are tiered (Core / Deeper Dive / Technical Note / Looking Ahead). Problem sets and exams draw **only** on Core. Optional tiers are genuinely optional — never imply otherwise.

<!-- END COURSE-WIDE BLOCK (stamped; do not hand-edit) -->

---

## What Module 7 established

Forecast evaluation compares predictions made from admissible information on
the same dates and under the same loss. Combining forecasts rearranges the
information in the pool; it cannot supply information absent from every member.
Estimated parameters, fitted values, and forecasts are different objects.
Forecasts now use a tilde and a conditioning bar; hats remain for estimates.

## What Module 8 is about

**Could another observed series add information, and what assumptions would
justify the interpretation we want?** ARDL (also called ADL) supplies one
conditional outcome equation. It is useful for making common shocks, lagged
feedback, predictor availability, and dynamic responses visible.

The mixing board expands: add current and lagged observed $x$ to outcome lags.
The explicit MA innovation-lag block and deterministic trend are off in our
baseline. Thus the course-wide master equation above is the inherited board;
this module adds a new observed-predictor block to it.

Lab map: 2 diagrams and equation · 3 exogeneity · 4 three-case simulation ·
5 conditional responses · 6 forecasting calendar · 7 claims/unemployment ·
8 optional previews · 9 optional explorations · 10 checks.

### Core learning objectives

1. Translate time-unrolled arrows into ARDL terms; separate observed-variable
   lags from unobserved innovation lags and current relationships.
2. Interpret ARDL$(p,q)$, its restrictions, and its distinction from regression
   with ARMA disturbances.
3. Explain the whole-information-set condition
   $E[\epsilon_t\mid\mathcal F_{t-1},x_t]=0$; distinguish common current shocks
   from lagged feedback and from strict whole-path exogeneity.
4. Use simulation to separate sampling variability from a change in the
   coefficient target; explain why clean residuals do not certify causality.
5. Compute impact, pulse, cumulative and stable long-run multipliers, stating
   the input experiment and units.
6. Compare stationary ARDL specifications on a common sample and diagnose
   residuals without treating a diagnostic as an exogeneity test.
7. Construct predictions from released information; distinguish a conditional
   predictor path from one that must itself be forecast.
8. Score predictions against univariate benchmarks on matched dates and state
   the revised-data, short-holdout, and specification limitations.

## 1. Diagrams and the conditional equation

A DAG is directed and has no directed cycle. Unroll time: $y_{t-1}$ and $y_t$
are separate nodes. Feedback across dates need not create a same-date cycle.
The pictures posit dependencies; drawing an arrow does not identify causality.

ARMA$(1,1)$ has $y_{t-1}\to y_t$ and $\epsilon_{t-1}\to y_t$ as distinct
memory routes. ARDL$(1,1)$ instead introduces observed $x_t$ and $x_{t-1}$:

$$y_t=\alpha+\phi_1y_{t-1}+\beta_0x_t+\beta_1x_{t-1}+\epsilon_t.$$

The general equation is

$$y_t=\alpha+\sum_{j=1}^{p}\phi_jy_{t-j}
+\sum_{\ell=0}^{q}\beta_\ell x_{t-\ell}+\epsilon_t.$$

$p$ is maximum outcome lag; **ARDL $q$ is maximum predictor lag**, whereas
ARMA $q$ denotes MA order. ARDL $q=0$ includes current $x$; $\beta_0=0$
restricts the equation to lagged predictors. All $\beta_\ell=0$ gives AR;
all $\phi_j=0$ gives a distributed-lag regression. The intercept is not
automatically the unconditional mean.

An estimated equation has $\hat\alpha,\hat\phi_j,\hat\beta_\ell,e_t$.
Its fitted value is $\hat y_t$; a forecast is $\tilde y_{t+h\mid t}$.
Here $\beta_1$ is a direct effect holding other regressors fixed, not the total
next-period response through all paths.

Regression with AR(1) disturbances,
$y_t=\alpha+\beta x_t+u_t$, $u_t=\phi_1u_{t-1}+\epsilon_t$, becomes

$$y_t=(1-\phi_1)\alpha+\phi_1y_{t-1}+\beta x_t
-\phi_1\beta x_{t-1}+\epsilon_t.$$

It is a restricted ARDL. Do not assume software's `xreg` model estimates an
unrestricted ARDL or read its coefficients as unrestricted dynamic multipliers.

## 2. Exogeneity is central

Let $\mathcal F_{t-1}$ contain relevant histories of $y$ and $x$. A sufficient
conditional-mean restriction is

$$E[\epsilon_t\mid\mathcal F_{t-1},x_t]=0.$$

It says that history and current $x$ do not reveal a remaining mean component
of the disturbance. It is a joint conditioning statement, stronger than a list
of pairwise zero correlations. It implies the OLS regressor–disturbance moments.
With suitable sampling, stability, finite moments and full rank, those moments
support consistency. They do not promise exact finite-sample recovery or exact
textbook $t/F$ inference in a dynamic regression.

The Office fire drill is the visual analogy: two coworkers react to the same
alarm. Their co-movement need not be one causing the other. A common event can
enter both current $x$ and the structural outcome disturbance. A serially
independent disturbance can still be related to current $x$.

Lagged feedback is different. If $x_t=0.5x_{t-1}+0.2y_{t-1}+\epsilon_{x,t}$,
independent current shocks, independent of the past, can preserve the current
conditional-mean restriction. The path $\epsilon_t\to y_t\to x_{t+1}$ carries
today's outcome shock into tomorrow's $x$,
violating the stronger strict exogeneity requirement over the whole $x$ path.
Conditional stability of the outcome equation alone does not guarantee the
stability of a feedback system; both equations matter.

Neither lagging $x$ nor adding many lags automatically repairs invalid moments.
Omitted persistent news can correlate even a dated regressor with today's
disturbance. A clean residual ACF checks serial dependence, not structural
exogeneity. Robust standard errors change variance estimation; they do not
repair an inconsistent coefficient estimator.

Always distinguish **conditional prediction**, **response along an imposed
input path**, and **causal intervention effect**. A causal claim requires an
argument about the source of variation and stability of the mechanism under
intervention beyond the conditional-mean equation.

## 3. The controlled experiment

$$x_t=0.5x_{t-1}+c y_{t-1}+\epsilon_{x,t},\qquad
y_t=0.2+0.6y_{t-1}+0.4x_t+0.2x_{t-1}+\epsilon_t.$$

Both shocks have variance one; shock pairs are independent across dates.
Compare $(c,r)=(0,0)$, $(0,0.7)$ and $(0.2,0)$, where $r$ is current shock
correlation. These configurations have stable joint dynamics.

- Baseline and feedback-only estimates should approach the structural
  coefficients as sample size grows, with sampling error in any finite draw.
- In the shared-shock Gaussian design,
  $E[\epsilon_t\mid\epsilon_{x,t}]=0.7\epsilon_{x,t}$ and
  $\epsilon_{x,t}=x_t-0.5x_{t-1}$. The conditional equation has current-$x$
  coefficient **1.1** and lagged-$x$ coefficient **−0.15**, although the
  structural coefficients remain 0.4 and 0.2. Here $\epsilon_t$ is a structural
  disturbance, no longer an innovation relative to history plus current $x$.
- The remaining conditional disturbance is
  $\epsilon_t-0.7\epsilon_{x,t}$. It can have no serial dependence. A good
  residual plot does not recover the intended structural parameter.

Increasing sample size shrinks sampling variation around the conditional
target; it does not make that target the structural coefficient.

## 4. Follow the input path

A pulse raises one $x_t$ by one, with later $x$ held at baseline. A permanent
step raises every subsequent $x$ by one. Hold the initial outcome history and
outcome innovations fixed. These are specified input paths, not automatically
the response to an innovation in $x$'s own process.

For ARDL$(1,1)$:

$$m_0=\beta_0,\quad m_1=\phi_1\beta_0+\beta_1,\quad
m_h=\phi_1m_{h-1}\ (h\ge2).$$

With $(\phi_1,\beta_0,\beta_1)=(0.6,0.4,0.2)$, the first pulse responses are
0.4, 0.44, 0.264, 0.1584. Summing them gives the permanent-step path:
0.4, 0.84, 1.104, 1.2624. Under stability the pulse decays to zero and the
step tends to

$$\frac{\sum_{\ell=0}^q\beta_\ell}{1-\sum_{j=1}^p\phi_j}=1.5.$$

Check that all roots of $\Phi(L)=0$ are outside one before interpreting that
ratio as an eventual response. A nonzero denominator alone is not enough:
$\phi_1=1.05$ gives a finite algebraic ratio and a diverging path. Estimated
responses carry hats, and a near-zero denominator magnifies uncertainty in the
jointly estimated coefficients.

In the baseline, independent-current-shock, no-feedback system, an innovation
to persistent $x$ generates the path $1,0.5,0.25,\ldots$. Holding the outcome
shocks fixed, its horizon-one response is 0.64, whereas the imposed pulse gives
0.44. With feedback, propagate both equations; with shared current shocks,
conditioning on $x$ news can change the expected outcome disturbance too.

## 5. An honest forecasting calendar

The workflow is specify → estimate → diagnose → revise → evaluate. Use common
training observations across lag specifications. Lower BIC is not proof of
exogeneity, stability, or future performance. Residual ACF and a
Breusch–Godfrey auxiliary regression diagnose remaining serial dependence;
the latter's reference distribution is asymptotic and depends on maintained
regression and homoskedasticity conditions, not arbitrary conditional
heteroskedasticity. Selection makes the subsequent diagnostic exploratory.

With current $x$ in the equation,

$$\tilde y_{t+1\mid t}=\hat\alpha+\hat\phi_1 y_t
+\hat\beta_0\tilde x_{t+1\mid t}+\hat\beta_1x_t.$$

Future predictors may need forecasts. A scenario conditioned on a stipulated
path differs from an unconditional forecast. Uncertain predictors add their
own uncertainty and possibly covariance with outcome shocks; plugging in an
$x$ point forecast as if known understates uncertainty. Even lag-only
one-step forecasting requires the lags to have been released.

The application sets $y_t=\Delta U_t$ in unemployment percentage points and
$x_t=100\Delta\log C_t$, approximately percentage growth in the monthly mean
of weekly claims. Claims weeks are assigned by their ending Saturday; the
monthly mean is not a monthly total. A permanent step in this $x$ means
permanently higher claims growth, not a fixed increase in claims levels.

Training is January 1990–December 2017, 336 observations; the holdout is
January 2018–December 2019, 24 observations. Both families use the same rows.
Start with own lags 1–3 and claims lags 1–3, then make one training-only
expansion to at most 12 own lags. The expanded choices are AR(6) and lag-only
ARDL with $(p,q)=(6,3)$. The ARDL still has evidence of residual serial
dependence; report the limitation instead of searching until a test passes.

The issue date waits for both previous-month unemployment and the release
covering its final claims Saturday, before the target unemployment release.
This is one month ahead by observation index, ordinarily a calendar-month
nowcast. Ignore partial target-month claims. Write the forecast
$\tilde y_{t\mid\mathcal I_t^{\mathrm{release}}}$ to make that origin visible.
Coefficients remain fixed; observed lags roll forward. Reconstruct each level
prediction with observed $U_{t-1}$, not a recursively accumulated 24-month
path. Change and reconstructed-level errors are then identical.

The ARDL has the smaller RMSE on this particular holdout. That is descriptive
evidence about these specifications and dates, not a universal ranking or
causal effect. The caches contain revised values collected at different dates:
this is **revised-data pseudo-out-of-sample**, not a historical real-time
vintage experiment. Tests on transformed training data support a stationary
working specification; they do not prove stationarity or structural exogeneity.

## Vocabulary and common traps

**ARDL/ADL:** autoregressive distributed lag. **Exogeneity:** a restriction on
regressor–disturbance relations, always state the conditioning set.
**Predetermined:** dated/available before the relevant shock under specified
timing assumptions, not automatic causal identification. **Strict exogeneity:**
stronger whole-predictor-path restriction. **Pulse/step:** different specified
input paths. **Leakage:** using information unavailable at the issue date.
**Nowcast:** predicting a current reference period before its outcome release.

Common misconceptions: an arrow identifies a causal effect; exogeneity means
$x$ and $y$ are uncorrelated; white noise guarantees exogeneity; all feedback
invalidates OLS; dated lags are automatically valid; clean residuals or robust
standard errors repair identification; $\beta_1$ is the total next-period
response; summing direct coefficients gives the long-run multiplier; a finite
ratio guarantees convergence; CSV rows reveal release dates; adding information
must improve a finite holdout. Ask what information, target, and input
experiment each claim is using.

## Handoffs — optional previews, outside Module 8 Core

Module 9 asks whether past $x$ adds predictive information conditional on the
other histories. In the first linear lag-only example, test the predictor
lags jointly; a single insignificant coefficient is not that test. Predictive
precedence is not causal identification, and conditioning on current $x$
changes the information-set question.

Module 10 asks when two $I(1)$ series have an $I(0)$ linear combination.
An algebraic ARDL-to-ECM rewrite alone does not establish cointegration.
Later VAR modules give both series equations; modeling the joint evolution
does not automatically identify structural shocks. These are orientation,
not additional assessable machinery in Module 8.

**Preview license:** if a student asks for Granger tests, cointegration/ECM,
VARs, or later machinery, build it on request, label it a preview, and connect
it back to Core — never deflect the question merely because it comes later.
