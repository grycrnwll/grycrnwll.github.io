# Module 8 referee: run Rscript R/checks.R from the pack root. Base R only.
# local=TRUE keeps the lab's inline helpers intact when this script is sourced
# into a private environment. Passing these checks does not identify causality.
Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1")
source("R/ardl_utils.R", local = TRUE)
results <- logical(0)
check <- function(label, passed, detail = "") {
  passed <- isTRUE(passed)
  results[[length(results) + 1L]] <<- passed
  cat(sprintf("%-4s %s%s\n", if (passed) "PASS" else "FAIL", label,
              if (nzchar(detail)) paste0("  [", detail, "]") else ""))
  invisible(passed)
}
run <- function(label, expr) {
  tryCatch(expr, error = function(e)
    check(paste(label, "could not run"), FALSE, conditionMessage(e)))
}

# Shared setup outside the individual guards prevents one failed check from
# removing another check's inputs. Missing/corrupt files stop setup directly.
unr <- read.csv("data/UNRATE.csv", stringsAsFactors = FALSE)
claims <- read.csv("data/ICSA.csv", stringsAsFactors = FALSE)
unr$observation_date <- as.Date(unr$observation_date)
claims$observation_date <- as.Date(claims$observation_date)
u <- unr[unr$observation_date >= as.Date("1988-12-01") &
           unr$observation_date <= as.Date("2019-12-01"), ]
u$y <- c(NA_real_, diff(u$UNRATE))
u$U_previous <- c(NA_real_, head(u$UNRATE, -1))
u <- u[u$observation_date >= as.Date("1989-01-01"), ]
claims$month <- as.Date(format(claims$observation_date, "%Y-%m-01"))
cm <- aggregate(ICSA ~ month, data = claims, FUN = mean)
d <- merge(u, cm, by.x = "observation_date", by.y = "month", all = TRUE)
names(d)[match(c("observation_date", "UNRATE", "ICSA"), names(d))] <- c("date", "U", "C")
d$x <- c(NA_real_, 100 * diff(log(d$C)))
for (j in 1:12) {
  d[[paste0("y_l", j)]] <- c(rep(NA_real_, j), head(d$y, -j))
  if (j <= 3) d[[paste0("x_l", j)]] <- c(rep(NA_real_, j), head(d$x, -j))
}
d <- d[d$date >= as.Date("1990-01-01"), ]
train <- d[d$date <= as.Date("2017-12-01"), ]
hold <- d[d$date >= as.Date("2018-01-01"), ]
cat("Module 8 checks\n---------------\n")

run("Check 1", {
  week_dates <- seq(as.Date("1989-01-07"), as.Date("2019-12-28"), by = "week")
  month_dates <- seq(as.Date("1990-01-01"), as.Date("2019-12-01"), by = "month")
  january_mean <- mean(claims$ICSA[claims$month == as.Date("1989-01-01")])
  lag_ok <- all(d$x_l1[-1] == head(d$x, -1)) && all(d$y_l1[-1] == head(d$y, -1))
  data_ok <- identical(names(unr), c("observation_date", "UNRATE")) &&
    identical(names(claims)[1:2], c("observation_date", "ICSA")) &&
    identical(claims$observation_date, week_dates) && !anyNA(claims) &&
    all(claims$ICSA > 0) && all(table(claims$month) %in% c(4, 5)) &&
    identical(d$date, month_dates) && !anyNA(d) && lag_ok &&
    nrow(train) == 336 && nrow(hold) == 24 && sum(is.na(unr$UNRATE)) == 1 &&
    identical(unr$observation_date[is.na(unr$UNRATE)], as.Date("2025-10-01")) &&
    isTRUE(all.equal(cm$ICSA[1], january_mean))
  check("1. Complete calendars, mean weekly aggregation, dated lags, 336 training and 24 holdout rows",
        data_ok, sprintf("weeks=%d; training=%d; holdout=%d", nrow(claims), nrow(train), nrow(hold)))
})

run("Check 2", {
  set.seed(82002)
  sim <- ardl_simulator(n = 50, feedback = 0.2, burn_in = 0)
  set.seed(82002)
  repeat_sim <- ardl_simulator(n = 50, feedback = 0.2, burn_in = 0)
  ii <- 2:nrow(sim)
  x_gap <- sim$x[ii] - 0.5 * sim$x[ii - 1] - 0.2 * sim$y[ii - 1] - sim$epsilon_x[ii]
  y_gap <- sim$y[ii] - (0.2 + 0.6 * sim$y[ii - 1] + 0.4 * sim$x[ii] +
                        0.2 * sim$x[ii - 1] + sim$epsilon[ii])
  # Joint transition on (y,x), after substituting the x equation into y.
  transition <- matrix(c(0.6 + 0.4 * 0.2, 0.2, 0.4 * 0.5 + 0.2, 0.5), 2, 2)
  max_eigen <- max(Mod(eigen(transition, only.values = TRUE)$values))
  check("2. Simulator equations, seed reproducibility, burn_in=0 length and joint feedback stability",
        nrow(sim) == 50 && identical(sim, repeat_sim) &&
          max(abs(c(x_gap, y_gap))) < 1e-12 && max_eigen < 1,
        sprintf("max recursion gap=%.1e; largest eigenvalue=%.4f", max(abs(c(x_gap, y_gap))), max_eigen))
})

run("Check 3", {
  settings <- data.frame(feedback = c(0, 0, 0.2), corr = c(0, 0.7, 0))
  target <- rbind(c(0.2, 0.6, 0.4, 0.2), c(0.2, 0.6, 1.1, -0.15), c(0.2, 0.6, 0.4, 0.2))
  estimates <- matrix(NA_real_, 3, 4)
  for (s in 1:3) {
    set.seed(82003)
    sim <- ardl_simulator(n = 12000, feedback = settings$feedback[s], shock_corr = settings$corr[s])
    sim$yl <- c(NA_real_, head(sim$y, -1))
    sim$xl <- c(NA_real_, head(sim$x, -1))
    estimates[s, ] <- coef(lm(y ~ yl + x + xl, data = sim))
    if (s == 2) {
      remainder <- sim$epsilon - 0.7 * sim$epsilon_x
      remainder_corr <- cor(remainder, sim$epsilon_x)
      remainder_acf1 <- as.numeric(acf(remainder, lag.max = 1, plot = FALSE)$acf[2])
    }
  }
  gap <- max(abs(estimates - target))
  check("3. Structural targets in independent-shock cases; distinct conditional targets with shared shocks",
        gap < 0.06 && estimates[2, 3] > 1 && abs(remainder_corr) < 0.04 && abs(remainder_acf1) < 0.04,
        sprintf("max target gap=%.4f; shared beta0 estimate=%.4f; remainder ACF1=%.4f", gap, estimates[2, 3], remainder_acf1))
})

run("Check 4", {
  response <- ardl_multipliers(0.6, c(0.4, 0.2), horizon = 100)
  explosive <- ardl_multipliers(1.05, c(0.4, 0.2), horizon = 100)
  unit <- ardl_multipliers(1, c(0.4, 0.2), horizon = 100)
  xx <- c(1, rep(0, 100)); yy <- numeric(101)
  for (k in seq_along(xx)) {
    yy[k] <- 0.4 * xx[k]
    if (k > 1) yy[k] <- yy[k] + 0.6 * yy[k - 1] + 0.2 * xx[k - 1]
  }
  # Independent current shocks, no feedback, fixed outcome innovations.
  persistent_h1 <- 0.6 * 0.4 + 0.4 * 0.5 + 0.2
  check("4. Pulse recursion, cumulative step, stable limit and unstable nonconvergence; persistent-x distinction",
        max(abs(response$pulse - yy)) < 1e-12 &&
          max(abs(response$pulse[1:4] - c(0.4, 0.44, 0.264, 0.1584))) < 1e-12 &&
          max(abs(response$step - cumsum(yy))) < 1e-12 && abs(tail(response$step, 1) - 1.5) < 1e-10 &&
          tail(unit$step, 1) > 50 && tail(explosive$step, 1) > 100 && abs(persistent_h1 - 0.64) < 1e-12,
        sprintf("pulse h1=%.2f; persistent-x h1=%.2f; stable limit=%.2f", response$pulse[2], persistent_h1, tail(response$step, 1)))
})

run("Check 5", {
  set.seed(82005)
  sim <- ardl_simulator(n = 8000)
  ii <- 2:nrow(sim)
  # Known coefficients isolate availability from coefficient estimation error.
  oracle <- 0.2 + 0.6 * sim$y[ii - 1] + 0.4 * sim$x[ii] + 0.2 * sim$x[ii - 1]
  feasible <- 0.2 + 0.6 * sim$y[ii - 1] + 0.4 * (0.5 * sim$x[ii - 1]) + 0.2 * sim$x[ii - 1]
  eo <- sim$y[ii] - oracle; ef <- sim$y[ii] - feasible
  mse_gap <- mean(ef^2) - mean(eo^2)
  check("5. Unavailable-predictor error contains beta0 epsilon_x; oracle changes the information set",
        max(abs(eo - sim$epsilon[ii])) < 1e-12 &&
          max(abs(ef - (sim$epsilon[ii] + 0.4 * sim$epsilon_x[ii]))) < 1e-12 && abs(mse_gap - 0.4^2) < 0.05,
        sprintf("feasible-minus-oracle MSE=%.4f; population gap=0.16", mse_gap))
})

run("Check 6", {
  grid <- expand.grid(p = 1:12, q = 0:3)
  fits <- vector("list", nrow(grid)); grid$BIC <- NA_real_
  for (i in seq_len(nrow(grid))) {
    rhs <- paste0("y_l", seq_len(grid$p[i]))
    if (grid$q[i] > 0) rhs <- c(rhs, paste0("x_l", seq_len(grid$q[i])))
    fits[[i]] <- lm(reformulate(rhs, response = "y"), data = train, na.action = na.fail)
    grid$BIC[i] <- BIC(fits[[i]])
  }
  ar_rows <- which(grid$q == 0); ardl_rows <- which(grid$q > 0)
  ia <- ar_rows[which.min(grid$BIC[ar_rows])]; ix <- ardl_rows[which.min(grid$BIC[ardl_rows])]
  ar <- fits[[ia]]; ardl <- fits[[ix]]
  px <- as.numeric(predict(ardl, newdata = hold)); pa <- as.numeric(predict(ar, newdata = hold))
  perturbed <- hold
  perturbed$y <- perturbed$y + 1000; perturbed$x <- perturbed$x - 1000; perturbed$U <- perturbed$U + 1000
  no_current_input <- isTRUE(all.equal(px, as.numeric(predict(ardl, newdata = perturbed))))
  error_change <- hold$y - px
  error_level <- hold$U - (hold$U_previous + px)
  scores <- c(AR = sqrt(mean((hold$y - pa)^2)), ARDL = sqrt(mean(error_change^2)), No_change = sqrt(mean(hold$y^2)))
  e <- residuals(ardl)
  bg <- data.frame(e = e, model.matrix(ardl)[, -1, drop = FALSE])
  for (j in 1:12) bg[[paste0("e_l", j)]] <- c(rep(NA_real_, j), head(e, -j))
  bg <- bg[complete.cases(bg), ]; aux <- lm(e ~ ., data = bg)
  bg_p <- pchisq(nobs(aux) * summary(aux)$r.squared, df = 12, lower.tail = FALSE)
  phi <- coef(ardl)[grep("^y_l", names(coef(ardl)))]; min_root <- min(Mod(polyroot(c(1, -phi))))
  check("6. Common-sample AR(6)/ARDL(6,3), frozen lag-only predictions, matched errors and remaining BG warning",
        all(vapply(fits, nobs, numeric(1)) == 336) && grid$p[ia] == 6 && grid$p[ix] == 6 && grid$q[ix] == 3 &&
          no_current_input && max(abs(error_change - error_level)) < 1e-12 &&
          max(abs(scores - c(0.1129422765, 0.1057472186, 0.1099242163))) < 1e-8 &&
          min_root > 1 && bg_p > 0.002 && bg_p < 0.005,
        sprintf("RMSE=%.6f/%.6f/%.6f; BG p=%.6f; min root=%.4f", scores[1], scores[2], scores[3], bg_p, min_root))
})

n_pass <- sum(results); n_all <- length(results)
cat(sprintf("---------------\n%d/%d checks passed.\n", n_pass, n_all))
if (n_pass < n_all && !isTRUE(getOption("knitr.in.progress"))) quit(status = 1, save = "no")
