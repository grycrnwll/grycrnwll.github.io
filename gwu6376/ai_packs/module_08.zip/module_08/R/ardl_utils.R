# Stamped from helpers/ardl_utils.R on 2026-10-22; do not hand-edit.
# ARDL teaching helpers, built inline in Module 8.
# Base R only. Set the seed at the call site; helpers never reset it.

# A two-equation DGP with persistent x, optional lagged feedback, and
# optionally correlated current shocks. All shocks have variance one.
# With shock_corr != 0, epsilon is the structural y disturbance, not an
# innovation relative to the information set containing current x.
# The caller chooses a stable joint system when stationarity is intended.
ardl_simulator <- function(n = 400, alpha = 0.2, phi = 0.6,
                           beta = c(0.4, 0.2), rho_x = 0.5,
                           feedback = 0, shock_corr = 0, burn_in = 200) {
  stopifnot(n >= 2, n == as.integer(n), burn_in >= 0,
            burn_in == as.integer(burn_in), length(beta) == 2,
            all(is.finite(c(alpha, phi, beta, rho_x, feedback, shock_corr))),
            abs(shock_corr) < 1)
  total <- n + burn_in + 1L
  epsilon_x <- rnorm(total)
  epsilon <- shock_corr * epsilon_x +
    sqrt(1 - shock_corr^2) * rnorm(total)
  x <- y <- numeric(total)
  for (t in 2:total) {
    x[t] <- rho_x * x[t - 1] + feedback * y[t - 1] + epsilon_x[t]
    y[t] <- alpha + phi * y[t - 1] + beta[1] * x[t] +
      beta[2] * x[t - 1] + epsilon[t]
  }
  keep <- (burn_in + 2L):total
  data.frame(t = seq_len(n), y = y[keep], x = x[keep],
             epsilon = epsilon[keep], epsilon_x = epsilon_x[keep])
}

# Responses to a one-unit pulse and permanent step in an imposed x path.
# beta[1] is beta_0; phi[1] is phi_1. No stability restriction is imposed:
# an unstable path is useful for the Module 8 assumption-break exercise.
ardl_multipliers <- function(phi, beta, horizon = 20) {
  stopifnot(is.numeric(phi), is.numeric(beta), length(beta) >= 1,
            all(is.finite(c(phi, beta))), horizon >= 0,
            horizon == as.integer(horizon))
  pulse <- numeric(horizon + 1L)
  for (h in 0:horizon) {
    direct <- if (h < length(beta)) beta[h + 1L] else 0
    inherited <- 0
    if (h > 0 && length(phi) > 0) {
      for (j in seq_len(min(length(phi), h))) {
        inherited <- inherited + phi[j] * pulse[h - j + 1L]
      }
    }
    pulse[h + 1L] <- direct + inherited
  }
  data.frame(h = 0:horizon, pulse = pulse, step = cumsum(pulse))
}
