# The six checks — Module 8

Run `Rscript R/checks.R` from the pack root. Each check prints PASS or FAIL,
followed by a verdict. A failure returns a nonzero command-line exit status.
During a lab render, failures print without terminating the document. A runtime
error inside one check becomes a FAIL line and later checks still run; missing
or corrupt shared input files are setup failures and stop the script directly.

These checks cover the shipped numerical examples and conventions below.
Passing does not validate every possible student edit, establish exogeneity
in the observational application, or identify a causal effect. The script uses
its stamped helper copy in a private environment when sourced by the lab; it
does not replace your inline functions. Compare your edited version with that
copy when investigating a discrepancy.

| Check | What it asserts | What a failure usually means |
|---|---|---|
| 1. Data and calendar | Complete Saturdays, complete monthly dates, mean weekly aggregation, correctly shifted lags, 336 training rows and 24 evaluation rows; the known UNRATE blank is outside the window. | A cache changed, a date was dropped, a week was averaged away, or lags were created after slicing rather than with pre-sample padding. |
| 2. Simulator contract | Returned observations satisfy both equations, repeated seeds reproduce the same draw, `burn_in = 0` returns the requested length, and the specified feedback design is jointly stable. | Equation order or coefficients changed, a lag index shifted, or the feedback matrix was assembled incorrectly. The check verifies one stable configuration, not arbitrary inputs. |
| 3. Coefficient targets | Large fixed-seed samples approach structural coefficients in baseline and feedback-only designs, and distinct conditional coefficients with shared shocks; the conditional disturbance can lack serial dependence. | Current-shock correlation, feedback, lag alignment or the intended target changed. Tolerances allow ordinary sampling error; this is not a finite-sample unbiasedness claim. |
| 4. Conditional responses | An independent recursion matches the pulse; its cumulative sum gives the step; stable responses converge; unit-root/explosive paths fail to converge despite a possible finite ratio. It also separates the persistent-x innovation path under independent shocks and no feedback. | A direct coefficient was confused with a total response, indexing shifted, or the input path or stability condition changed. |
| 5. Predictor availability | In the known-coefficient baseline, not observing future x adds its forecast error to the outcome error; the simulated variance gap is near its population value. | Target-period x leaked into the feasible method, coefficients changed, or independent-shock assumptions no longer hold. A lower oracle score is not an admissible earlier forecast comparison. |
| 6. Empirical workflow | Common-sample BIC choices, fixed lag-only predictions, equality of change/level errors, cached-data scores, conditional AR stability and the remaining BG warning match the lab. | Candidate menus, data vintages, training endpoints, lag columns, or the frozen-parameter design changed. A deliberate change needs a documented experiment rather than forcing this check to pass. |

The BG number uses the conventional asymptotic chi-squared reference, with
maintained regression and homoskedasticity conditions; it is not robust to
arbitrary conditional heteroskedasticity. After lag selection it is exploratory.
Matching that number checks reproducibility, not validity of every assumption.

## Helper behavior to keep in mind

`ardl_simulator()` implements a specific ARDL(1,1) system: `beta` has two
entries, both shocks have variance one, and `shock_corr` must be strictly
between −1 and 1. It does not check joint stability. Burn-in cannot make an
unstable design stationary. `epsilon` remains the structural disturbance;
under correlated current shocks it is not a conditional innovation.

`ardl_multipliers()` accepts finite AR and distributed-lag vectors and permits
unstable parameters intentionally. It computes finite-horizon paths; it does
not certify a finite long-run multiplier. In R, `beta[1]` is mathematical
$\beta_0$ and `phi[1]` is $\phi_1$. Helpers never reset the random seed.

The stamped helper body is identical to the canonical course helper. No local
helper corrections or new numerical dependencies were introduced in this pack.
