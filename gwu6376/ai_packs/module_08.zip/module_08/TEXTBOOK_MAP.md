# Textbook map — Module 8

Pointers and notation translations only; no textbook passages are reproduced.
Every precise location below is grounded in the instructor-authored
"Connection to Enders and Other Texts" section of
`reference/module_08_notes.qmd`. A pointer locates optional reading; it does
not enlarge the assessable Core boundary. **(verify)** means the course notes
do not document a precise edition-specific location; confirm it before citing.

| Concept | Enders, Applied Econometric Time Series, 4th ed. | Hamilton, Time Series Analysis | Hyndman / Hyndman and Athanasopoulos |
|---|---|---|---|
| ADL equation, transfer functions and conditional dynamic responses | Ch. 5 §2, pp. 267–276 | §8.2, pp. 215–219, dynamic regression and inference | 2014 FPP short-course handout, Ch. 10, especially pp. 109, 113–114: regression forecasting and lagged predictors |
| Structural versus conditional relationships; restrictions for estimation | Ch. 5 §4, pp. 281–284 | §8.2, pp. 215–219 | FPP textbook regression-forecasting discussion; exact current-edition section **(verify)** |
| Future predictor paths, ex-ante versus scenario forecasts | Ch. 5 §2 for the conditional dynamic equation | §8.2 for dynamic-regression background; exact forecasting subsection **(verify)** | 2014 handout Ch. 10, pp. 109, 113–114; FPP textbook exact edition/section **(verify)** |
| Granger causality, optional Module 9 preview | Ch. 5 §8 | §11.2, pp. 302–309 | Exact location **(verify)** |
| Cointegration and error correction, optional Module 10 preview | Ch. 6 §§1–3 | Exact section **(verify)** | Exact location **(verify)** |

These course pointers do not certify that every paragraph in the cited section
uses precisely the course's maintained assumptions. Read the surrounding
definition before importing a statement or a formula.

In particular, the 2014 Hyndman handout's transfer-function treatment on
p. 113 excludes feedback from y to x. That is stronger than Module 8's
sequential conditional-mean baseline, which can allow lagged feedback when
the current shocks are independent of one another and the past.

## Translate before using a formula

| Textbook feature | Course translation |
|---|---|
| ADL or ARDL; alternative order conventions | We use $p$ for maximum outcome lag and $q$ for maximum predictor lag, with current $x$ included unless $\beta_0=0$. Check whether a text counts lags or coefficients. |
| Enders's $a_j$ for autoregressive coefficients | Course $\phi_j$; $\beta_\ell$ for observed predictor coefficients. |
| Characteristic roots inside one | Equivalent to course lag-polynomial roots outside one. State which polynomial supplies the roots. |
| Innovations, residuals and fitted coefficients sometimes share notation | Course DGP parameters unhatted with $\epsilon_t$; estimates hatted and residuals $e_t$. In the deliberately endogenous simulation, $\epsilon_t$ is a structural disturbance, not an innovation relative to current $x$. |
| Forecasts commonly use hats | From Module 7 on, forecasts use $\tilde y_{t+h\mid t}$, while $\hat y_t$ is fitted in sample. |
| A “multiplier” without an explicit path | Specify pulse, cumulative pulse/permanent step, or innovation-induced predictor path. A model response is not automatically a causal response. |
| ECM adjustment often called $\alpha$ | Module 8 preserves $\alpha$ for the intercept and writes $\phi_1-1$ for adjustment in its optional algebraic preview. |
| MA signs can differ across books | Course $\Theta(L)=1+\theta_1L+\cdots$; do not import a software or textbook coefficient without checking its convention. |

For Hamilton symbols not explicitly translated in the course notes, ask the
student for the actual equation and map its terms by role. Do not guess a
notation table from an edition you have not inspected.
