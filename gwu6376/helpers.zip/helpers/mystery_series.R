# =============================================================================
# mystery_series.R — sealed practice series for the commit-then-reveal lab
# Econ 6376: Applied Time Series Econometrics
#
# Born for the Module 2 AI pack (2026-08-21). Not built live in any lecture.
# mystery_series(id) hands you one of four series without naming its DGP.
# Run the four-sources workflow (plot, ACF, ADF/KPSS, rule of thumb), commit
# a verdict, and only then call reveal_mystery(id).
#
# Unlike every other helper, mystery_series() DOES set a seed internally
# (6376 + 100 * id). That is the point: every student and every tutor sees
# the identical series, so committed verdicts are comparable. Note the call
# overwrites the session's RNG state — re-set your own seed afterward if
# your code depends on one.
#
# STUDENTS: the second half of this file, below the SPOILERS banner, contains
# the true DGPs. Do not read past the banner until you have committed a
# verdict for the series you are working on.
#
# Requires: nothing beyond base R (stats::).
# =============================================================================

mystery_series <- function(id) {
  # Return mystery series `id` as a ts object, without naming its DGP.
  #
  # Arguments:
  #   id : which series — one of 1, 2, 3, 4
  #
  # Returns:
  #   A ts object. Deterministic: the same id yields the identical series
  #   in every session and on every machine.

  .mystery_check_id(id)
  set.seed(6376 + 100 * id)
  .mystery_roster[[id]]$simulate()
}

reveal_mystery <- function(id) {
  # Print the true DGP of mystery series `id`: the equation in course
  # notation, the parameter values, and the sample size. Facts only —
  # interpretation belongs to the lab and your tutor.
  #
  # Arguments:
  #   id : which series — one of 1, 2, 3, 4
  #
  # Returns:
  #   NULL, invisibly. Called for the printout.

  .mystery_check_id(id)
  cat(.mystery_roster[[id]]$reveal, sep = "\n")
  invisible(NULL)
}

.mystery_check_id <- function(id) {
  # Shared validation for the two public functions. No spoilers here.
  if (!(length(id) == 1 && is.numeric(id) && !is.na(id) && id %in% 1:4)) {
    stop("`id` must be 1, 2, 3, or 4 — got ", deparse(id), call. = FALSE)
  }
}

# =============================================================================
#
#            SPOILERS BELOW — reveal_mystery() reads this
#
#   The list below holds the true DGP of every mystery series: the
#   generating code and the reveal text. If you are a student working the
#   Module 2 lab, stop reading here until you have committed your verdict.
#
# =============================================================================

.mystery_roster <- list(

  # ---- id 1 -----------------------------------------------------------------
  list(
    simulate = function() {
      # Stationary AR(1): y_t = 1 + 0.5 y_{t-1} + eps_t
      n <- 300
      burn_in <- 200
      y <- numeric(burn_in + n)
      y[1] <- 0
      for (t in 2:(burn_in + n)) {
        y[t] <- 1 + 0.5 * y[t - 1] + rnorm(1, 0, 1)
      }
      ts(y[-(1:burn_in)])
    },
    reveal = c(
      "Mystery series 1 — true DGP",
      "  Stationary AR(1):  y_t = 1 + 0.5 y_{t-1} + eps_t,   eps_t ~ N(0, 1)",
      "  alpha = 1, phi = 0.5, sigma = 1  (mean mu = alpha / (1 - phi) = 2)",
      "  T = 300, burn-in 200 discarded"
    )
  ),

  # ---- id 2 -----------------------------------------------------------------
  list(
    simulate = function() {
      # Driftless random walk: y_t = y_{t-1} + eps_t, from y_0 = 0
      n <- 300
      y <- numeric(n)
      y_prev <- 0
      for (t in 1:n) {
        y[t] <- y_prev + rnorm(1, 0, 1)
        y_prev <- y[t]
      }
      ts(y)
    },
    reveal = c(
      "Mystery series 2 — true DGP",
      "  Driftless random walk:  y_t = y_{t-1} + eps_t,   eps_t ~ N(0, 1)",
      "  y_0 = 0, sigma = 1",
      "  T = 300, no burn-in"
    )
  ),

  # ---- id 3 -----------------------------------------------------------------
  list(
    simulate = function() {
      # Trend-stationary: y_t = 2 + 0.03 t + u_t, u_t = 0.6 u_{t-1} + eps_t
      n <- 300
      u <- numeric(n)
      u_prev <- 0
      for (t in 1:n) {
        u[t] <- 0.6 * u_prev + rnorm(1, 0, 1)
        u_prev <- u[t]
      }
      ts(2 + 0.03 * (1:n) + u)
    },
    reveal = c(
      "Mystery series 3 — true DGP",
      "  Trend-stationary:  y_t = 2 + 0.03 t + u_t,",
      "                     u_t = 0.6 u_{t-1} + eps_t,   eps_t ~ N(0, 1)",
      "  alpha = 2, delta = 0.03, phi = 0.6, sigma = 1, u_0 = 0",
      "  T = 300, no burn-in"
    )
  ),

  # ---- id 4 -----------------------------------------------------------------
  list(
    simulate = function() {
      # Stationary AR(1), near-unit-root: y_t = 0.97 y_{t-1} + eps_t
      n <- 150
      burn_in <- 300
      y <- numeric(burn_in + n)
      y[1] <- 0
      for (t in 2:(burn_in + n)) {
        y[t] <- 0.97 * y[t - 1] + rnorm(1, 0, 1)
      }
      ts(y[-(1:burn_in)])
    },
    reveal = c(
      "Mystery series 4 — true DGP",
      "  Stationary AR(1):  y_t = 0.97 y_{t-1} + eps_t,   eps_t ~ N(0, 1)",
      "  alpha = 0, phi = 0.97, sigma = 1  (mean mu = 0)",
      "  T = 150, burn-in 300 discarded"
    )
  )
)
