# =============================================================================
# testing.R — Unit root testing utilities
# Econ 6376: Applied Time Series Econometrics
#
# mackinnon_cv(), adf_by_hand(), and find_order() are built live in L2.
# This file exists so later lectures can source them without re-defining.
# Do NOT source this file in L2 for the function built live there —
# use the inline versions in that lecture.
# Requires: urca
# =============================================================================

mackinnon_cv <- function(T, level = 0.05, spec = "drift") {
  # Return the MacKinnon critical value for the ADF test.
  #
  # Arguments:
  #   T     : sample size
  #   level : significance level (0.01, 0.05, or 0.10)
  #   spec  : ADF specification ("drift" only in this teaching version;
  #           use urca::ur.df() for "none" or "trend")
  #
  # Returns:
  #   A single numeric critical value.
  #
  # Reference:
  #   MacKinnon, J.G. (2010), "Critical Values for Cointegration
  #   Tests," Queen's Economics Department Working Paper No. 1227 —
  #   Table 2 is the source of these response-surface coefficients.
  #   MacKinnon (1996), "Numerical Distribution Functions for Unit
  #   Root and Cointegration Tests," Journal of Applied Econometrics,
  #   11, 601-618, develops the underlying numerical approach.

  if (spec != "drift") {
    stop("Only drift specification implemented in this teaching example.\n",
         "Use urca::ur.df() for other specifications.")
  }
  if (level == 0.01) {
    return(-3.43035 - 6.5393 / T - 16.786 / T^2 - 79.433 / T^3)
  }
  if (level == 0.05) {
    return(-2.86154 - 2.8903 / T - 4.234 / T^2 - 40.04 / T^3)
  }
  if (level == 0.10) {
    return(-2.56677 - 1.5384 / T - 2.809 / T^2)
  }
  stop("Level must be 0.01, 0.05, or 0.10")
}

adf_by_hand <- function(y, lags = 4, level = 0.05, spec = "drift") {
  # Build the ADF regression by hand and return its t-ratio on y_{t-1}.
  # This is the "ADF from scratch" construction from L2 — one regression,
  # one t-ratio — that demystifies what urca::ur.df() does internally:
  #
  #   Delta y_t = alpha + gamma * y_{t-1}
  #               + sum_{j=1}^{lags} c_j * Delta y_{t-j} + e_t
  #
  # and tau is the ordinary t-ratio on gamma. With lags = 0 this is the
  # plain (un-augmented) Dickey-Fuller regression.
  #
  # Arguments:
  #   y     : a time series (ts or numeric vector)
  #   lags  : number of lagged differences to include (0 = plain DF)
  #   level : significance level for the MacKinnon critical value
  #   spec  : ADF specification ("drift" only in this teaching version;
  #           use urca::ur.df() for "none" or "trend")
  #
  # Returns:
  #   A list with components
  #     statistic  : the ADF t-ratio (tau) on y_{t-1}
  #     critical   : the MacKinnon critical value at `level`
  #     reject     : TRUE if the unit root null is rejected
  #     lags       : lagged differences used
  #     regression : the fitted lm object, so summary() shows the whole thing
  #
  # Note:
  #   Matches urca::ur.df(y, type = "drift", lags = lags)@teststat[1]
  #   to numerical precision.

  if (spec != "drift") {
    stop("Only drift specification implemented in this teaching example.\n",
         "Use urca::ur.df() for other specifications.")
  }

  T <- length(y)
  dy <- diff(y)

  # embed() stacks the differences beside their own lags:
  # column 1 is Delta y_t, columns 2.. are Delta y_{t-1}, ..., Delta y_{t-p}
  X <- embed(dy, lags + 1)
  dy_t    <- X[, 1]
  dy_lags <- X[, -1, drop = FALSE]

  # y_{t-1}, truncated to line up with the shortened difference block
  y_lag <- as.numeric(y[(lags + 1):(T - 1)])

  adf_reg <- if (lags > 0) {
    lm(dy_t ~ y_lag + dy_lags)
  } else {
    lm(dy_t ~ y_lag)
  }

  statistic <- summary(adf_reg)$coefficients["y_lag", "t value"]
  critical  <- mackinnon_cv(T = T, level = level, spec = spec)

  list(
    statistic  = unname(statistic),
    critical   = critical,
    reject     = unname(statistic) < critical,
    lags       = lags,
    regression = adf_reg
  )
}

find_order <- function(y, max_d = 2, level = 0.05) {
  # Determine order of integration by sequential ADF testing.
  #
  # Arguments:
  #   y     : a time series (ts or numeric vector)
  #   max_d : maximum order of integration to test (default 2)
  #   level : significance level for the ADF test (default 0.05)
  #
  # Returns:
  #   Integer d (0, 1, 2, ...) or NA if order exceeds max_d.
  #
  # Logic:
  #   1. Test levels with ADF.
  #   2. If fail to reject, difference and test again.
  #   3. Stop when you reject. The number of differences = d.

  d <- 0
  current <- y
  while (d <= max_d) {
    test <- urca::ur.df(current, type = "drift", lags = 4)
    if (test@teststat[1] < test@cval[1, 2]) {  # 5% column
      return(d)
    }
    d <- d + 1
    current <- diff(current)
  }
  return(NA)  # Could not determine order within max_d
}

find_order_i01 <- function(y, level = 0.05) {
  # Simple helper for the common I(0)/I(1) case, built inline in the
  # Module 2 notes. find_order() above generalizes it to higher orders;
  # this version is kept as the canonical copy of the notes' teaching
  # example (it also lets the caller pick the significance level).
  #
  # Arguments:
  #   y     : a time series (ts or numeric vector)
  #   level : significance level for the ADF test (0.01, 0.05, or 0.10)
  #
  # Returns:
  #   0 if the levels reject the unit root, 1 if the first difference
  #   does, NA if inconclusive (if I(2) is plausible, use downward
  #   Dickey-Pantula-style testing instead).

  cv_col <- if (level <= 0.01) {
    1
  } else if (level <= 0.05) {
    2
  } else {
    3
  }

  test_level <- urca::ur.df(y, type = "drift", lags = 4)
  if (test_level@teststat[1] < test_level@cval[1, cv_col]) {
    return(0)
  }

  test_diff <- urca::ur.df(diff(y), type = "drift", lags = 4)
  if (test_diff@teststat[1] < test_diff@cval[1, cv_col]) {
    return(1)
  }

  return(NA)
}
