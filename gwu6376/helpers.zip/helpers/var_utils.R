# =============================================================================
# var_utils.R — VAR simulators and utilities
# Econ 6376: Applied Time Series Econometrics
#
# var1_sim() is carried forward from F2024 L12-L13.
# Used from L11 (VAR mechanical structure) onward.
# Requires: mvtnorm
# =============================================================================

var1_sim <- function(periods,
                     b10, b11, gamma11, gamma12,
                     b20, b21, gamma21, gamma22,
                     sd1, sd2, rho) {
  # Simulate a bivariate VAR(1) from the structural form.
  #
  # The structural form is:
  #   y1_t = b10 + b11*y2_t + gamma11*y1_{t-1} + gamma12*y2_{t-1} + e1_t
  #   y2_t = b20 + b21*y1_t + gamma21*y1_{t-1} + gamma22*y2_{t-1} + e2_t
  #
  # The function solves for the reduced-form VAR(1):
  #   Y_t = A0 + A1 * Y_{t-1} + u_t
  #
  # Arguments:
  #   periods : number of time periods to simulate
  #   b10, b11, b20, b21 : contemporaneous structural coefficients
  #   gamma11, gamma12, gamma21, gamma22 : lagged structural coefficients
  #   sd1, sd2 : standard deviations of structural shocks
  #   rho      : correlation between structural shocks
  #
  # Returns:
  #   A list with:
  #     $data        : data.frame with columns period, V1, V2
  #     $A0          : reduced-form intercept vector
  #     $A1          : reduced-form coefficient matrix
  #     $B           : contemporaneous structural matrix
  #     $eigenvalues : eigenvalues of A1 (for stability check)
  #     $modulus     : moduli of eigenvalues

  # Covariance matrix for structural shocks
  cov_val <- rho * sd1 * sd2
  Sigma <- matrix(c(sd1^2, cov_val, cov_val, sd2^2), nrow = 2)

  # Structural -> reduced form

  B <- matrix(c(1, -b11, -b21, 1), nrow = 2)
  Binv <- solve(B)
  Gamma0 <- c(b10, b20)
  Gamma1 <- matrix(c(gamma11, gamma12, gamma21, gamma22), nrow = 2)
  A0 <- Binv %*% Gamma0
  A1 <- Binv %*% Gamma1

  # Stability check
  eigenvalues <- eigen(A1)$values
  modulus <- Mod(eigenvalues)

  # Simulate
  errors <- mvtnorm::rmvnorm(n = periods, mean = c(0, 0), sigma = Sigma)
  data <- matrix(0, nrow = periods, ncol = 2)
  data[1, ] <- A0 + A1 %*% c(0, 0) + Binv %*% errors[1, ]
  for (i in 2:periods) {
    data[i, ] <- A0 + A1 %*% data[i - 1, ] + Binv %*% errors[i, ]
  }

  data <- data.frame(
    period = 1:periods,
    V1 = data[, 1],
    V2 = data[, 2]
  )

  return(list(
    data = data,
    A0 = A0,
    A1 = A1,
    B = B,
    eigenvalues = eigenvalues,
    modulus = modulus
  ))
}
