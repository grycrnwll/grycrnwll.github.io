# =============================================================================
# model_selection.R — screened ARMA candidate fitting for information criteria
# Econ 6376: Applied Time Series Econometrics
#
# Born for the Module 4 deck generator (2026-08-25) and kept here in `helpers/`
# as the canonical copy so later modules can source() these instead of
# re-defining them. Nothing is built live from this file: the Module 4 deck
# narrates the screen in prose, and Module 4 Core Practice 6 asks students to
# write their own version of it.
#
# safe_fit(y, p, q) fits one ARMA(p,q) candidate and returns NULL rather than
# erroring when the optimizer refuses the specification, so a grid search can
# keep going. It then reproduces forecast::Arima()'s aicc and bic fields on top
# of the stats::arima() engine, which lets a caller rank candidates on all
# three criteria without loading forecast at all.
#
# fit_is_valid(fit) is the screen itself. A candidate survives only if it is
# non-null, reports optimizer code 0, and is finite in every information
# criterion, in the log-likelihood, and in every coefficient. Returns a single
# TRUE/FALSE, so it drops straight into vapply(fits, fit_is_valid, logical(1)).
#
# The zero-process-mean policy is baked in: safe_fit() always passes
# include.mean = FALSE and method = "CSS-ML", matching Module 4's stated
# policy. It is deliberately NOT the general mean-policy grid search that Core
# Practice 6 asks for — that exercise wants the policy as an argument.
#
# Requires: nothing beyond base R (stats::arima).
# =============================================================================

safe_fit <- function(y, p, q) {
  fit <- suppressWarnings(tryCatch(
    stats::arima(y, order = c(p, 0, q), include.mean = FALSE,
                 method = "CSS-ML"),
    error = function(err) NULL
  ))
  if (is.null(fit)) return(NULL)

  # forecast::Arima() uses the same stats::arima() engine for these d = 0 fits,
  # then adds AICc and BIC to the returned object.  Reproduce those two fields
  # directly so this long sequential simulation does not keep forecast's
  # compiled dependency stack loaded through R shutdown on Windows.
  nstar <- length(y)
  npar <- length(fit$coef) + 1L  # include innovation variance sigma^2
  fit$aicc <- fit$aic + 2 * npar * (npar + 1) / (nstar - npar - 1)
  fit$bic <- fit$aic + npar * (log(nstar) - 2)
  fit
}

fit_is_valid <- function(fit) {
  !is.null(fit) &&
    isTRUE(fit$code == 0) &&
    all(is.finite(c(fit$aic, fit$aicc, fit$bic, fit$loglik))) &&
    all(is.finite(fit$coef))
}
