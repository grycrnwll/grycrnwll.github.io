# =============================================================================
# data_utils.R — FRED data fetching and ts conversion
# Econ 6376: Applied Time Series Econometrics
#
# Wraps the repeated FRED fetch pattern into a single call.
# fetch_fred() requires the fredr package and the FRED_KEY environment
# variable; set your key with: Sys.setenv(FRED_KEY = "your_key_here")
# or add FRED_KEY=your_key_here to your .Renviron file.
# load_cached_fred() needs neither — it reads the course's cached CSVs
# so notes and decks render with no key and no network.
# =============================================================================

fetch_fred <- function(series_id,
                       start_date = "1948-01-01",
                       end_date = NULL,
                       frequency = 12) {
  # Fetch a FRED series and return it as a ts object.

  #
  # Arguments:
  #   series_id  : FRED series code (e.g., "UNRATE", "GDPC1")
  #   start_date : earliest observation (character, "YYYY-MM-DD")
  #   end_date   : latest observation (NULL = most recent available)
  #   frequency  : ts frequency (12 = monthly, 4 = quarterly, 1 = annual)
  #
  # Returns:
  #   A ts object with appropriate start date and frequency.

  key <- Sys.getenv("FRED_KEY")
  if (nchar(key) == 0) {
    stop("FRED_KEY environment variable is not set.\n",
         "Set it with: Sys.setenv(FRED_KEY = 'your_key_here')\n",
         "Or add FRED_KEY=your_key_here to your .Renviron file.")
  }
  fredr::fredr_set_key(key)

  raw <- fredr::fredr(
    series_id = series_id,
    observation_start = as.Date(start_date),
    observation_end = if (!is.null(end_date)) as.Date(end_date) else NULL
  )

  # Drop any NA values at the tail (FRED sometimes returns them)
  raw <- raw[!is.na(raw$value), ]

  start_year  <- as.numeric(format(min(raw$date), "%Y"))
  start_month <- as.numeric(format(min(raw$date), "%m"))

  ts(raw$value,
     start = c(start_year, start_month),
     frequency = frequency)
}

load_cached_fred <- function(path,
                             value_col = NULL,
                             frequency = 12,
                             as_ts = TRUE) {
  # Read one of the course's cached FRED pulls (data/*.csv) and return it
  # ready to use. Every module that reaches Step 4 repeats the same three
  # moves on the cache; this is that block in one call.
  #
  # The cached CSVs come straight from the FRED download page, so the date
  # column is named `observation_date` and the value column is named after
  # the series ("UNRATE"). A release gap shows up as an NA in the value
  # column: the run is truncated at the first NA so the monthly ts index
  # stays aligned with the calendar (UNRATE.csv has one, 2025-10).
  #
  # Arguments:
  #   path      : path to the cached CSV (e.g., "../data/UNRATE.csv")
  #   value_col : name of the value column (NULL = the first non-date column)
  #   frequency : ts frequency (12 = monthly, 4 = quarterly, 1 = annual)
  #   as_ts     : TRUE returns a ts object; FALSE returns the trimmed
  #               data frame with a `date` column, for date-axis plots
  #
  # Returns:
  #   A ts object starting at the first cached observation, or (as_ts =
  #   FALSE) a data frame with columns `date` and the value column.

  raw <- utils::read.csv(path)
  names(raw)[names(raw) == "observation_date"] <- "date"
  raw$date <- as.Date(raw$date)

  if (is.null(value_col)) {
    value_col <- setdiff(names(raw), "date")[1]
  }
  if (!value_col %in% names(raw)) {
    stop("Column '", value_col, "' is not in ", path)
  }

  raw <- raw[order(raw$date), ]

  # Truncate at the first release gap rather than dropping it, so the
  # remaining observations are a contiguous monthly run.
  first_na <- which(is.na(raw[[value_col]]))
  if (length(first_na) > 0) {
    raw <- raw[seq_len(min(first_na) - 1), ]
  }

  if (!as_ts) {
    return(raw[, c("date", value_col)])
  }

  start_year  <- as.numeric(format(min(raw$date), "%Y"))
  start_month <- as.numeric(format(min(raw$date), "%m"))

  ts(raw[[value_col]],
     start = c(start_year, start_month),
     frequency = frequency)
}
