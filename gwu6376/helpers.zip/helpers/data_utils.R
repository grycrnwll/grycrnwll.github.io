# =============================================================================
# data_utils.R — FRED data fetching and ts conversion
# Econ 6376: Applied Time Series Econometrics
#
# Wraps the repeated FRED fetch pattern into a single call.
# Requires: fredr package and FRED_KEY environment variable.
# Set your key with: Sys.setenv(FRED_KEY = "your_key_here")
# or add FRED_KEY=your_key_here to your .Renviron file.
# =============================================================================

fetch_fred <- function(series_id,
                       start_date = "1948-01-01",
                       end_date = NULL,
                       frequency = 12) {
  # Fetch a FRED series and return it as a ts object.

  #
  # Arguments:
  #   series_id  : FRED series code (e.g., "UNRATE", "GDPC1")
  #   start_date : earliest observation (character, "YYYY-MM-DD")
  #   end_date   : latest observation (NULL = most recent available)
  #   frequency  : ts frequency (12 = monthly, 4 = quarterly, 1 = annual)
  #
  # Returns:
  #   A ts object with appropriate start date and frequency.

  key <- Sys.getenv("FRED_KEY")
  if (nchar(key) == 0) {
    stop("FRED_KEY environment variable is not set.\n",
         "Set it with: Sys.setenv(FRED_KEY = 'your_key_here')\n",
         "Or add FRED_KEY=your_key_here to your .Renviron file.")
  }
  fredr::fredr_set_key(key)

  raw <- fredr::fredr(
    series_id = series_id,
    observation_start = as.Date(start_date),
    observation_end = if (!is.null(end_date)) as.Date(end_date) else NULL
  )

  # Drop any NA values at the tail (FRED sometimes returns them)
  raw <- raw[!is.na(raw$value), ]

  start_year  <- as.numeric(format(min(raw$date), "%Y"))
  start_month <- as.numeric(format(min(raw$date), "%m"))

  ts(raw$value,
     start = c(start_year, start_month),
     frequency = frequency)
}
