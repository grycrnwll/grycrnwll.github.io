# =============================================================================
# track_utils.R — The six one-step forecast tracks of the PS3 design
# Econ 6376: Applied Time Series Econometrics
#
# Built inline in the Module 7 notes (§7.1); this file is the canonical copy
# that Module 8+ and Problem Set 3 source. Do NOT source it in Module 7.
# (Exposure of the midterm Q7 track builder through Module 7 Core was
# accepted by the instructor — decisions_log Entry 15.)
#
#   upto(x, n)                  : first n observations of a ts, keeping its
#                                 frequency (use instead of x[1:n])
#   kavg(x, k, dates)           : k-period average forecasts of y_t for each t
#                                 in `dates`; k = 1 is locf, k = Inf is the
#                                 expanding mean (meanf). Never call these
#                                 "moving averages" (that is the MA(q) block).
#   tracks_on(x, fits, dates, k): the six one-step tracks arima_1..3, locf,
#                                 avg_k, meanf for `dates`. ARIMA parameters
#                                 stay at their training values (model = fit);
#                                 only the information set rolls.
#
# PS3 usage pattern (T = length(y) - 24; fits = list of three Arima fits on
# upto(y, T)):
#   F_w <- tracks_on(y, fits, T + 1:12)    # weights window
#   F_h <- tracks_on(y, fits, T + 13:24)   # holdout
#   all.equal(F_h[, "locf"], as.numeric(y)[T + 12:23])   # alignment check
#
# Requires: forecast (Arima).
# =============================================================================

upto <- function(x, n) {
  # First n observations of a ts, KEEPING its frequency and dates.
  window(x, end = time(x)[n])
}

kavg <- function(x, k, dates) {
  # k-period average forecast of y_t for each t in `dates`: the mean of the
  # k previous actuals; k = Inf gives the expanding mean of y_1..y_{t-1}.
  x <- as.numeric(x)
  if (any(dates < 2)) stop("dates must be >= 2: the first value has no past.")
  if (!is.infinite(k) && any(dates <= k)) stop("need k past values before each date.")
  sapply(dates, function(t) {
    if (is.infinite(k)) mean(x[1:(t - 1)]) else mean(x[(t - k):(t - 1)])
  })
}

tracks_on <- function(x, fits, dates, k = 3) {
  # The six one-step tracks for the dates in `dates` (a T_w x 6 or N x 6
  # matrix with column names). `fits` is a list of three fitted Arima models
  # estimated once on the training sample.
  xs <- upto(x, max(dates))
  os <- function(fit) as.numeric(fitted(forecast::Arima(xs, model = fit)))[dates]
  cbind(arima_1 = os(fits[[1]]),
        arima_2 = os(fits[[2]]),
        arima_3 = os(fits[[3]]),
        locf    = kavg(x, 1,   dates),
        avg_k   = kavg(x, k,   dates),
        meanf   = kavg(x, Inf, dates))
}
