# Helpers — Econ 6376: Applied Time Series Econometrics

Reusable R functions for the course. Source in the Quarto/R Markdown setup chunk.

## Usage

```r
# Source everything (for lectures past their intro phase):
source(here::here("helpers", "_load_all.R"))

# Or source only what you need:
source(here::here("helpers", "data_utils.R"))
source(here::here("helpers", "simulators.R"))
```

## Inline-first policy

Functions that are built live in front of students stay **inline** in that lecture's notes/slides. They appear here only so that **later lectures** can `source()` them without re-defining. Do not source a file in the lecture where it is first built — use the inline version there.

## Function inventory

| # | Function | File | Built live in | Sourced from |
|---|----------|------|---------------|--------------|
| 1 | `ar1_simulator(n, alpha, phi, init, mu, sigma, start_date, frequency, burn_in)` | simulators.R | L1 | L2+ |
| 2 | `arma_simulator(n, alpha, phi, theta, sigma, burn_in)` | simulators.R | L3 | L4+ |
| 2a | `sarima_simulator(n, alpha, phi, theta, Phi, Theta, s, sigma, burn_in)` | simulators.R | L5 | L6+ |
| 3 | `mackinnon_cv(T, level, spec)` | testing.R | L2 | L3+ |
| 3a | `adf_by_hand(y, lags, level, spec)` | testing.R | L2 | L3+ |
| 4 | `find_order(y, max_d, level)` | testing.R | L2 | L3+ |
| 4a | `find_order_i01(y, level)` | testing.R | L2 (notes) | L3+ |
| 5 | `show_fingerprint(y, title)` | diagnostics.R | L3 | L4+ |
| 5a | `pacf_by_regression(y, k_max)` | diagnostics.R | L3 | L4+ |
| 6 | `fetch_fred(series_id, start_date, end_date, frequency)` | data_utils.R | — | L1+ |
| 6a | `load_cached_fred(path, value_col, frequency, as_ts)` | data_utils.R | — | L1+ |
| 7 | `ts_split(data, test_periods)` | forecast_utils.R | — | L6+ |
| 8 | `mse(actual, forecast)` | forecast_utils.R | — | L6+ |
| 9 | `mae(actual, forecast)` | forecast_utils.R | — | L6+ |
| 10 | `huber(actual, forecast, delta)` | forecast_utils.R | — | L6+ |
| 11 | `rmse(actual, forecast)` | forecast_utils.R | — | L7+ |
| 12 | `mape(actual, forecast)` | forecast_utils.R | — | L7+ |
| 13 | `mean_huber(actual, forecast, delta)` | forecast_utils.R | — | L6+ |
| 14 | `asym_loss(actual, forecast, alpha)` | forecast_utils.R | — | L6+ |
| 15 | `theil_u2(actual, forecast, benchmark)` | forecast_utils.R | — | L7+ (rewritten 2026-10-12, decision 62: RMSE(forecast) / RMSE(benchmark) over the same dates; `benchmark` is the `locf` track. The old two-argument version was wrong and unused) |
| 15a | `mase(actual, forecast, train, m = 1)` | forecast_utils.R | — | L7+ (holdout MAE / in-sample naive MAE on train; `m = 12` for the seasonal-naive scale — `m` is the seasonal lag in code, written $s$ in the math) |
| 26 | `comb_simple(y, F)` | combination_utils.R | L7 (notes §7.6, inline) | L8+ and PS3 |
| 26a | `comb_inv_mse(y, F)` | combination_utils.R | L7 (notes §7.6, inline) | L8+ and PS3 |
| 26b | `comb_gr(y, F)` | combination_utils.R | L7 (notes §7.6, inline) | L8+ and PS3 |
| 26c | `comb_cls(y, F)` | combination_utils.R | L7 (notes §7.6, inline) | L8+ and PS3 |
| 27 | `upto(x, n)` | track_utils.R | L7 (notes §7.1, inline) | L8+ and PS3 |
| 27a | `kavg(x, k, dates)` | track_utils.R | L7 (notes §7.1, inline) | L8+ and PS3 |
| 27b | `tracks_on(x, fits, dates, k)` | track_utils.R | L7 (notes §7.1, inline) | L8+ and PS3 (exposure of the midterm Q7 track builder accepted by the instructor — decisions_log Entry 15) |
| 16 | `var1_sim(periods, b10, b11, gamma11, gamma12, b20, b21, gamma21, gamma22, sd1, sd2, rho)` | var_utils.R | L11 | L12+ |
| 17 | `spurious_mc(n_sims, n_obs, level, dgp, phi)` | monte_carlo.R | L1 (notes) | L2+ |
| 18 | `df_null_mc(n_sims, T)` | monte_carlo.R | L2 (notes) | L3+ |
| 19 | `adf_power_mc(phi, sample_sizes, n_sims, level)` | monte_carlo.R | L2 (notes) | L3+ |
| 20 | `mystery_series(id)` | mystery_series.R | — | born for the Module 2 AI pack (2026-08-21) |
| 20a | `reveal_mystery(id)` | mystery_series.R | — | born for the Module 2 AI pack (2026-08-21) |
| 21 | `four_sources(y, label)` | four_sources.R | — | born for the Module 2 AI pack (2026-08-21; built inline in its lab — that inline build is the pedagogy) |
| 22 | `safe_fit(y, p, q)` | model_selection.R | — | L4 (born for the Module 4 deck generator, 2026-08-25; ships with M4 — see the PP6 note below) |
| 22a | `fit_is_valid(fit)` | model_selection.R | — | L4 (born for the Module 4 deck generator, 2026-08-25; ships with M4 — see the PP6 note below) |
| 22b | `hqic(fit)` | model_selection.R | — | L6 (born for the Module 6 deck, 2026-09-30: Hannan-Quinn on forecast's k and T conventions, since `auto.arima()` has no HQIC option) |
| 23 | `fingerprint_mystery(id)` | fingerprint_mysteries.R | — | born for the Module 3 AI pack (2026-09-04) |
| 23a | `reveal_fingerprint(id)` | fingerprint_mysteries.R | — | born for the Module 3 AI pack (2026-09-04) |
| 24 | `lb_both(fit, h)` | diagnostics.R | L5 (notes §5.3.5) | L6+ |
| 25 | `seasonal_dummies(y, ref)` | seasonality.R | L5 (notes §5.8.2) | L6+ |
| 25a | `periodogram_df(x)` | seasonality.R | L5 (notes §5.9, Deeper Dive) | L6+ |
| 25b | `seasonal_bin_ratios(test)` | seasonality.R | L5 (notes §5.9.6, Deeper Dive; takes a `freqseas::seas_test()` object) | L6+ |

**Practice Problem 6 note (2026-08-25).** `safe_fit()` and `fit_is_valid()` are close to what
M4 Core Practice Problem 6 asks students to write, and they ship with M4 rather than being held
back — an L5+ hold was considered and rejected, because `_load_all.R` sources
`model_selection.R` and a partial `helpers.zip` would break the loader for everyone. Two things
keep PP6 from being fully given away: `safe_fit()` bakes in `include.mean = FALSE` and
`method = "CSS-ML"` to match Module 4's zero-mean policy, so it is *not* the general
mean-policy grid search PP6 asks for; and PP6's value is in writing the screen, not in
possessing one. Treat PP6 as a read-the-source-then-rebuild-it exercise, or vary it, rather
than assuming students have not seen this file.

**Seeds.** The `monte_carlo.R` functions never set a seed. Every call site in the
notes sets one immediately before the call, and seeding internally would make the
numbers those modules quote unreachable. Set the seed yourself before calling.
The deliberate exceptions are `mystery_series()`, which seeds internally
(`6376 + 100 * id`) so every student and tutor sees the identical sealed series
for the commit-then-reveal lab, and `fingerprint_mystery()`, which does the same
from a per-mystery seed roster for the Module 3 ACF/PACF practice; in both files
the true DGPs sit below a SPOILERS banner, read only by `reveal_mystery()` /
`reveal_fingerprint()`.

## Sourcing guide by lecture

| Lecture | Source these files |
|---------|-------------------|
| L1 | `data_utils.R` |
| L2 | `data_utils.R`, `simulators.R` |
| L3 | `data_utils.R`, `simulators.R`, `testing.R`, `monte_carlo.R` |
| L4+ | `data_utils.R`, `simulators.R`, `testing.R`, `monte_carlo.R`, `diagnostics.R` |
| L5 | the L4+ set, but define `sarima_simulator()`, `lb_both()`, `seasonal_dummies()`, `periodogram_df()`, and `seasonal_bin_ratios()` inline (built live there); `seasonality.R` is not sourced in L5 |
| L6 | all of the above + `seasonality.R` + `forecast_utils.R` |
| L7 | the L6 set; define `upto()`, `kavg()`, `tracks_on()`, `comb_simple()`, `comb_inv_mse()`, `comb_gr()`, and `comb_cls()` inline (built live there); `track_utils.R` and `combination_utils.R` are not sourced in L7 |
| L8+, PS3 | the L6 set + `track_utils.R` + `combination_utils.R` |
| L11+ | all of the above + `var_utils.R` |

`monte_carlo.R` calls `mackinnon_cv()` and `adf_by_hand()`, so source `testing.R`
before it (`_load_all.R` already does).

## Dependencies

| Package | Used by |
|---------|---------|
| `fredr` | data_utils.R (`fetch_fred` only — `load_cached_fred` needs no packages and no network) |
| `forecast` | diagnostics.R, track_utils.R (`tracks_on()` calls `forecast::Arima()`) |
| `ggplot2` | diagnostics.R, four_sources.R |
| `patchwork` | diagnostics.R |
| `urca` | testing.R, monte_carlo.R (`adf_power_mc` only), four_sources.R |
| `mvtnorm` | var_utils.R |
| `quadprog` | combination_utils.R (`comb_cls` only; one `solve.QP()` call — installed with `forecast` via `tseries`; approved in decisions_log decision 60) |

## Functions staying inline only (pedagogical, not reused)

- `build_phi_matrix()` — L1 (AR matrix construction demo)
- `simulate_with_common_shocks()` — L1 (one-line closure that re-seeds before each call, so the memory gallery varies only in phi; a fixed seed baked into a helper would be a trap)
- `autocov()` — L3 (manual autocovariance)
- `solve_yule_walker()` — L3 (Yule-Walker equations)
- `call_center_loss()` — L6 (write-your-own-loss illustration; encodes a made-up domain cost structure, not reusable infrastructure)
- `ic_row()` — L5 (three-line formatter that turns one `Arima()` fit into a row of an IC table; per-class IC tables in the notes' §5.8.3)
- `course_dgp()`, `fit_sim()` — L7 (§7.1: the module's simulated DGP and its three fixed ARIMA specifications; module-specific settings, not reusable infrastructure)
- `metrics_table()`, `apply_w()`, `combo_var()` — L7 (§7.3, §7.7, §7.5: one-line wrappers over `rmse()`/`mase()`/`theil_u2()`, the holdout application `intercept + F %*% weights`, and the two-forecast variance formula for a figure)
- `fmt()` — L7 (§7.1: a `formatC()` one-liner that formats inline numbers in the notes' prose; presentation only)
- `num()`, `pipe_tab()`, `sci()` — L7 deck only (`slides/module_07/module_07_slides.qmd` setup chunk: deck-only presentation formatters that typeset a minus sign, write a cached matrix as a pipe table with display labels, and print a small p-value as a power of ten; they format cached numbers and compute nothing)
- `summ()` — L7 (§7.7: four summary statistics of one Monte Carlo column; a table formatter for one simulation, not reusable infrastructure)
- `ff_sarima()`, `ff_naive()` — L7 (§7.2 Deeper Dive: forecast-function closures in the shape `tsCV()` requires, hard-wired to one specification; not assessable and not reused)

## Module 8: ARDL helpers

`ardl_utils.R` is built inline in `notes/module_08_notes.qmd` and registered in
`_load_all.R` for later modules. It uses only base R.

- `ardl_simulator(n, alpha, phi, beta, rho_x, feedback, shock_corr, burn_in)`
  generates an ARDL(1,1) outcome with persistent x, optional lagged feedback,
  and correlated current shocks. `beta = c(beta_0, beta_1)`. The returned
  `epsilon` is a structural disturbance; when current shocks are correlated,
  it is not an innovation conditional on current x. Choose joint-system
  parameters compatible with stationarity when that is the intended DGP.
- `ardl_multipliers(phi, beta, horizon)` returns pulse and permanent-step
  responses to an imposed x path, including AR propagation. `beta[1]` is
  the contemporaneous coefficient. The routine permits unstable parameters
  for the assumption-break exercise; a finite long-run multiplier still
  requires stability.

Set the random seed before simulation; these helpers never reset it.
