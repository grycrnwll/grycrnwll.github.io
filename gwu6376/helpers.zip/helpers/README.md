# Helpers — Econ 6376: Applied Time Series Econometrics

Reusable R functions for the course. Source in the Quarto/R Markdown setup chunk.

## Usage

```r
# Source everything (for lectures past their intro phase):
source(here::here("helpers", "_load_all.R"))

# Or source only what you need:
source(here::here("helpers", "data_utils.R"))
source(here::here("helpers", "simulators.R"))
```

## Inline-first policy

Functions that are built live in front of students stay **inline** in that lecture's notes/slides. They appear here only so that **later lectures** can `source()` them without re-defining. Do not source a file in the lecture where it is first built — use the inline version there.

## Function inventory

| # | Function | File | Built live in | Sourced from |
|---|----------|------|---------------|--------------|
| 1 | `ar1_simulator(n, alpha, phi, init, mu, sigma, start_date, frequency, burn_in)` | simulators.R | L1 | L2+ |
| 2 | `arma_simulator(n, alpha, phi, theta, sigma, burn_in)` | simulators.R | L3 | L4+ |
| 2a | `sarima_simulator(n, alpha, phi, theta, Phi, Theta, s, sigma, burn_in)` | simulators.R | L5 | L6+ |
| 3 | `mackinnon_cv(T, level, spec)` | testing.R | L2 | L3+ |
| 3a | `adf_by_hand(y, lags, level, spec)` | testing.R | L2 | L3+ |
| 4 | `find_order(y, max_d, level)` | testing.R | L2 | L3+ |
| 4a | `find_order_i01(y, level)` | testing.R | L2 (notes) | L3+ |
| 5 | `show_fingerprint(y, title)` | diagnostics.R | L3 | L4+ |
| 5a | `pacf_by_regression(y, k_max)` | diagnostics.R | L3 | L4+ |
| 6 | `fetch_fred(series_id, start_date, end_date, frequency)` | data_utils.R | — | L1+ |
| 6a | `load_cached_fred(path, value_col, frequency, as_ts)` | data_utils.R | — | L1+ |
| 7 | `ts_split(data, test_periods)` | forecast_utils.R | — | L6+ |
| 8 | `mse(actual, forecast)` | forecast_utils.R | — | L6+ |
| 9 | `mae(actual, forecast)` | forecast_utils.R | — | L6+ |
| 10 | `huber(actual, forecast, delta)` | forecast_utils.R | — | L6+ |
| 11 | `rmse(actual, forecast)` | forecast_utils.R | — | L7+ |
| 12 | `mape(actual, forecast)` | forecast_utils.R | — | L7+ |
| 13 | `mean_huber(actual, forecast, delta)` | forecast_utils.R | — | L6+ |
| 14 | `asym_loss(actual, forecast, alpha)` | forecast_utils.R | — | L6+ |
| 15 | `theil_u2(actual, forecast)` | forecast_utils.R | — | L7+ |
| 16 | `var1_sim(periods, b10, b11, gamma11, gamma12, b20, b21, gamma21, gamma22, sd1, sd2, rho)` | var_utils.R | L11 | L12+ |
| 17 | `spurious_mc(n_sims, n_obs, level, dgp, phi)` | monte_carlo.R | L1 (notes) | L2+ |
| 18 | `df_null_mc(n_sims, T)` | monte_carlo.R | L2 (notes) | L3+ |
| 19 | `adf_power_mc(phi, sample_sizes, n_sims, level)` | monte_carlo.R | L2 (notes) | L3+ |
| 20 | `mystery_series(id)` | mystery_series.R | — | born for the Module 2 AI pack (2026-08-21) |
| 20a | `reveal_mystery(id)` | mystery_series.R | — | born for the Module 2 AI pack (2026-08-21) |
| 21 | `four_sources(y, label)` | four_sources.R | — | born for the Module 2 AI pack (2026-08-21; built inline in its lab — that inline build is the pedagogy) |
| 22 | `safe_fit(y, p, q)` | model_selection.R | — | L4 (born for the Module 4 deck generator, 2026-08-25; ships with M4 — see the PP6 note below) |
| 22a | `fit_is_valid(fit)` | model_selection.R | — | L4 (born for the Module 4 deck generator, 2026-08-25; ships with M4 — see the PP6 note below) |

**Practice Problem 6 note (2026-08-25).** `safe_fit()` and `fit_is_valid()` are close to what
M4 Core Practice Problem 6 asks students to write, and they ship with M4 rather than being held
back — an L5+ hold was considered and rejected, because `_load_all.R` sources
`model_selection.R` and a partial `helpers.zip` would break the loader for everyone. Two things
keep PP6 from being fully given away: `safe_fit()` bakes in `include.mean = FALSE` and
`method = "CSS-ML"` to match Module 4's zero-mean policy, so it is *not* the general
mean-policy grid search PP6 asks for; and PP6's value is in writing the screen, not in
possessing one. Treat PP6 as a read-the-source-then-rebuild-it exercise, or vary it, rather
than assuming students have not seen this file.

**Seeds.** The `monte_carlo.R` functions never set a seed. Every call site in the
notes sets one immediately before the call, and seeding internally would make the
numbers those modules quote unreachable. Set the seed yourself before calling.
The one deliberate exception is `mystery_series()`, which seeds internally
(`6376 + 100 * id`) so every student and tutor sees the identical sealed series
for the commit-then-reveal lab; the true DGPs sit below a SPOILERS banner in
that file, read only by `reveal_mystery()`.

## Sourcing guide by lecture

| Lecture | Source these files |
|---------|-------------------|
| L1 | `data_utils.R` |
| L2 | `data_utils.R`, `simulators.R` |
| L3 | `data_utils.R`, `simulators.R`, `testing.R`, `monte_carlo.R` |
| L4+ | `data_utils.R`, `simulators.R`, `testing.R`, `monte_carlo.R`, `diagnostics.R` |
| L6-L7 | all of the above + `forecast_utils.R` |
| L11+ | all of the above + `var_utils.R` |

`monte_carlo.R` calls `mackinnon_cv()` and `adf_by_hand()`, so source `testing.R`
before it (`_load_all.R` already does).

## Dependencies

| Package | Used by |
|---------|---------|
| `fredr` | data_utils.R (`fetch_fred` only — `load_cached_fred` needs no packages and no network) |
| `forecast` | diagnostics.R |
| `ggplot2` | diagnostics.R, four_sources.R |
| `patchwork` | diagnostics.R |
| `urca` | testing.R, monte_carlo.R (`adf_power_mc` only), four_sources.R |
| `mvtnorm` | var_utils.R |

## Functions staying inline only (pedagogical, not reused)

- `build_phi_matrix()` — L1 (AR matrix construction demo)
- `simulate_with_common_shocks()` — L1 (one-line closure that re-seeds before each call, so the memory gallery varies only in phi; a fixed seed baked into a helper would be a trap)
- `autocov()` — L3 (manual autocovariance)
- `solve_yule_walker()` — L3 (Yule-Walker equations)
- `call_center_loss()` — L6 (write-your-own-loss illustration; encodes a made-up domain cost structure, not reusable infrastructure)
