# Helpers — Econ 6376: Applied Time Series Econometrics

Reusable R functions for the course. Source in the Quarto/R Markdown setup chunk.

## Usage

```r
# Source everything (for lectures past their intro phase):
source(here::here("helpers", "_load_all.R"))

# Or source only what you need:
source(here::here("helpers", "data_utils.R"))
source(here::here("helpers", "simulators.R"))
```

## Inline-first policy

Functions that are built live in front of students stay **inline** in that lecture's notes/slides. They appear here only so that **later lectures** can `source()` them without re-defining. Do not source a file in the lecture where it is first built — use the inline version there.

## Function inventory

| # | Function | File | Built live in | Sourced from |
|---|----------|------|---------------|--------------|
| 1 | `ar1_simulator(n, alpha, phi, init, mu, sigma, start_date, frequency, burn_in)` | simulators.R | L1 | L2+ |
| 2 | `arma_simulator(n, alpha, phi, theta, sigma, burn_in)` | simulators.R | L3 | L4+ |
| 2a | `sarima_simulator(n, alpha, phi, theta, Phi, Theta, s, sigma, burn_in)` | simulators.R | L5 | L6+ |
| 3 | `mackinnon_cv(T, level, spec)` | testing.R | L2 | L3+ |
| 4 | `find_order(y, max_d, level)` | testing.R | L2 | L3+ |
| 4a | `find_order_i01(y, level)` | testing.R | L2 (notes) | L3+ |
| 5 | `show_fingerprint(y, title)` | diagnostics.R | L3 | L4+ |
| 6 | `fetch_fred(series_id, start_date, end_date, frequency)` | data_utils.R | — | L1+ |
| 7 | `ts_split(data, test_periods)` | forecast_utils.R | — | L6+ |
| 8 | `mse(actual, forecast)` | forecast_utils.R | — | L6+ |
| 9 | `mae(actual, forecast)` | forecast_utils.R | — | L6+ |
| 10 | `huber(actual, forecast, delta)` | forecast_utils.R | — | L6+ |
| 11 | `rmse(actual, forecast)` | forecast_utils.R | — | L7+ |
| 12 | `mape(actual, forecast)` | forecast_utils.R | — | L7+ |
| 13 | `mean_huber(actual, forecast, delta)` | forecast_utils.R | — | L6+ |
| 14 | `asym_loss(actual, forecast, alpha)` | forecast_utils.R | — | L6+ |
| 15 | `theil_u2(actual, forecast)` | forecast_utils.R | — | L7+ |
| 16 | `var1_sim(periods, b10, b11, gamma11, gamma12, b20, b21, gamma21, gamma22, sd1, sd2, rho)` | var_utils.R | L11 | L12+ |

## Sourcing guide by lecture

| Lecture | Source these files |
|---------|-------------------|
| L1 | `data_utils.R` |
| L2 | `data_utils.R`, `simulators.R` |
| L3 | `data_utils.R`, `simulators.R`, `testing.R` |
| L4+ | `data_utils.R`, `simulators.R`, `testing.R`, `diagnostics.R` |
| L6-L7 | all of the above + `forecast_utils.R` |
| L11+ | all of the above + `var_utils.R` |

## Dependencies

| Package | Used by |
|---------|---------|
| `fredr` | data_utils.R |
| `forecast` | diagnostics.R |
| `ggplot2` | diagnostics.R |
| `patchwork` | diagnostics.R |
| `urca` | testing.R |
| `mvtnorm` | var_utils.R |

## Functions staying inline only (pedagogical, not reused)

- `build_phi_matrix()` — L1 (AR matrix construction demo)
- `autocov()` — L3 (manual autocovariance)
- `solve_yule_walker()` — L3 (Yule-Walker equations)
- `call_center_loss()` — L6 (write-your-own-loss illustration; encodes a made-up domain cost structure, not reusable infrastructure)
