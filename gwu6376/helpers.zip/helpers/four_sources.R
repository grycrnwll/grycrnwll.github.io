# =============================================================================
# four_sources.R — the four-sources stationarity evidence report
# Econ 6376: Applied Time Series Econometrics
#
# Born for the Module 2 AI pack (2026-08-21). Built inline in the Module 2
# lab — that inline build is the pedagogy (it is Sections 4-6 of the lab
# stapled together) — and kept here as the canonical copy so later modules
# can source() it instead of re-defining.
#
# four_sources(y, label) prints the series plot and a hand-rolled sample
# ACF, then returns the evidence table: ADF tau under the drift and trend
# specifications, KPSS under mu and tau, and the rule-of-thumb ratio
# sd(diff(y))/sd(y). The reject column applies each test's own direction
# (left tail for ADF, right tail for KPSS). Augmentation lags are fixed at
# 4 for comparability across series. It never decides anything — choosing
# which rows to believe, from the plot, is the analyst's job.
#
# Requires: urca, ggplot2
# =============================================================================

four_sources <- function(y, label) {
  y   <- ts(as.numeric(y))
  T_n <- length(y)

  print(
    ggplot(data.frame(t = seq_len(T_n), y = as.numeric(y)), aes(t, y)) +
      geom_line(colour = "steelblue4", linewidth = 0.4) +
      labs(title = paste0(label, ": the series"), x = "t",
           y = expression(y[t]))
  )

  rho <- stats::acf(y, lag.max = 25, plot = FALSE)$acf[-1]
  print(
    ggplot(data.frame(lag = seq_along(rho), rho = as.numeric(rho)), aes(lag)) +
      geom_hline(yintercept = 0, colour = "grey40", linewidth = 0.3) +
      geom_hline(yintercept = c(-1.96, 1.96) / sqrt(T_n),
                 linetype = "dashed", colour = "grey55") +
      geom_segment(aes(xend = lag, y = 0, yend = rho),
                   colour = "steelblue4", linewidth = 1) +
      labs(title = paste0(label, ": sample ACF"), x = "lag k",
           y = expression(hat(rho)[k]))
  )

  adf_d <- ur.df(y, type = "drift", lags = 4)
  adf_t <- ur.df(y, type = "trend", lags = 4)
  kp_mu <- ur.kpss(y, type = "mu")
  kp_ta <- ur.kpss(y, type = "tau")

  data.frame(
    measure = c("ADF tau (drift)", "ADF tau (trend)",
                "KPSS (mu)", "KPSS (tau)", "sd(dy)/sd(y)"),
    value   = round(c(adf_d@teststat[1], adf_t@teststat[1],
                      kp_mu@teststat, kp_ta@teststat,
                      sd(diff(y)) / sd(y)), 3),
    cv_05   = c(adf_d@cval[1, 2], adf_t@cval[1, 2],
                kp_mu@cval[1, "5pct"], kp_ta@cval[1, "5pct"], NA),
    reject  = c(adf_d@teststat[1] < adf_d@cval[1, 2],
                adf_t@teststat[1] < adf_t@cval[1, 2],
                kp_mu@teststat > kp_mu@cval[1, "5pct"],
                kp_ta@teststat > kp_ta@cval[1, "5pct"], NA)
  )
}
