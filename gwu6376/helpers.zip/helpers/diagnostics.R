# =============================================================================
# diagnostics.R — Residual diagnostics and fingerprint plotting
# Econ 6376: Applied Time Series Econometrics
#
# show_fingerprint() is built live in L3.
# This file exists so later lectures can source it without re-defining.
# Requires: forecast, ggplot2, patchwork
# =============================================================================

show_fingerprint <- function(y, title = "") {
  # Create a 3-panel diagnostic: series plot + ACF + PACF.
  #
  # Arguments:
  #   y     : a ts object
  #   title : main title for the series panel
  #
  # Returns:
  #   A patchwork plot object (series on top, ACF + PACF side by side below).

  p1 <- forecast::autoplot(y) + ggplot2::ggtitle(title) + ggplot2::theme_bw()
  p2 <- forecast::ggAcf(y, lag.max = 24) + ggplot2::ggtitle("ACF") + ggplot2::theme_bw()
  p3 <- forecast::ggPacf(y, lag.max = 24) + ggplot2::ggtitle("PACF") + ggplot2::theme_bw()
  p1 / (p2 + p3)
}
