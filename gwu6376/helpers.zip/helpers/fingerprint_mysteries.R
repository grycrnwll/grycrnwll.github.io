# =============================================================================
# fingerprint_mysteries.R — sealed ACF/PACF practice for the Module 3 AI pack
# Econ 6376: Applied Time Series Econometrics
# Canonical source: helpers/fingerprint_mysteries.R
#
# fingerprint_mystery(id) returns one of four deterministic series without
# naming its DGP. Inspect the series, ACF, and PACF; commit a classification;
# then call reveal_fingerprint(id).
#
# This helper deliberately sets an internal seed so every student and tutor
# sees the same draw. Calling it overwrites the session RNG state; set your own
# seed afterward when later code depends on one.
#
# STUDENTS: true DGPs live below the SPOILERS banner. Source this file; do not
# read past that banner until you have committed a classification.
#
# Requires: base R only.
# =============================================================================

fingerprint_mystery <- function(id) {
  # Return sealed fingerprint series `id` as a ts object.
  .fingerprint_check_id(id)
  set.seed(.fingerprint_roster[[id]]$seed)
  .fingerprint_roster[[id]]$simulate()
}

reveal_fingerprint <- function(id) {
  # Print the true DGP for one attempted series. Facts only; interpretation
  # belongs to the student, the lab, and the tutor.
  .fingerprint_check_id(id)
  cat(.fingerprint_roster[[id]]$reveal, sep = "\n")
  invisible(NULL)
}

.fingerprint_check_id <- function(id) {
  if (!(length(id) == 1 && is.numeric(id) && !is.na(id) && id %in% 1:4)) {
    stop("`id` must be 1, 2, 3, or 4 — got ", deparse(id), call. = FALSE)
  }
}

# =============================================================================
#
#                     SPOILERS BELOW
#
#   The roster contains every true DGP and reveal. Stop reading here until
#   you have committed a classification for the series you are attempting.
#
# =============================================================================

.fingerprint_roster <- list(
  list(
    seed = 7002,
    simulate = function() {
      stats::arima.sim(n = 500, model = list(ar = c(0.6, -0.3)))
    },
    reveal = c(
      "Fingerprint mystery 1 — true DGP",
      "  AR(2):  y_t = 0.6 y_{t-1} - 0.3 y_{t-2} + eps_t,   eps_t ~ N(0, 1)",
      "  phi = (0.6, -0.3), T = 500",
      "  Population signature: ACF tails off; PACF cuts off after lag 2."
    )
  ),
  list(
    seed = 7005,
    simulate = function() {
      stats::arima.sim(n = 500, model = list(ma = c(0.8, 0.5)))
    },
    reveal = c(
      "Fingerprint mystery 2 — true DGP",
      "  MA(2):  y_t = eps_t + 0.8 eps_{t-1} + 0.5 eps_{t-2},   eps_t ~ N(0, 1)",
      "  theta = (0.8, 0.5), T = 500",
      "  Population signature: ACF cuts off after lag 2; PACF tails off."
    )
  ),
  list(
    seed = 7001,
    simulate = function() {
      stats::arima.sim(n = 500, model = list(ar = 0.65, ma = 0.5))
    },
    reveal = c(
      "Fingerprint mystery 3 — true DGP",
      "  ARMA(1,1):  y_t = 0.65 y_{t-1} + eps_t + 0.5 eps_{t-1},",
      "               eps_t ~ N(0, 1)",
      "  phi = 0.65, theta = 0.5, T = 500",
      "  Population signature: both ACF and PACF tail off."
    )
  ),
  list(
    seed = 7100,
    simulate = function() {
      stats::arima.sim(n = 60, model = list(ar = c(0.55, -0.25)))
    },
    reveal = c(
      "Fingerprint mystery 4 — true DGP",
      "  AR(2):  y_t = 0.55 y_{t-1} - 0.25 y_{t-2} + eps_t,   eps_t ~ N(0, 1)",
      "  phi = (0.55, -0.25), T = 60",
      "  This draw is intentionally short: a pre-reveal 'ambiguous at this T'",
      "  verdict can be better calibrated than a confident order call."
    )
  )
)
