# =============================================================================
# forecast_utils.R — Train/test splitting and loss functions
# Econ 6376: Applied Time Series Econometrics
#
# ts_split() is renamed from the F2024 archive "split()" to avoid
# shadowing base::split(). Loss functions from F2024 L7.
# Used from L6 (forecasting) onward.
# =============================================================================

ts_split <- function(data, test_periods) {
  # Split a ts object into train and test sets.
  #
  # Arguments:
  #   data         : a ts object
  #   test_periods : number of observations to hold out for testing
  #
  # Returns:
  #   A list with $train and $test, both ts objects preserving time indices.

  train_length <- length(data) - test_periods
  train <- window(data, end = time(data)[train_length])
  test  <- window(data, start = time(data)[train_length + 1])
  return(list(train = train, test = test))
}

mse <- function(actual, forecast) {
  # Mean Squared Error.
  return(mean((actual - forecast)^2))
}

mae <- function(actual, forecast) {
  # Mean Absolute Error.
  return(mean(abs(actual - forecast)))
}

huber <- function(actual, forecast, delta = 4) {
  # Huber loss (element-wise).
  #
  # Arguments:
  #   actual   : observed values
  #   forecast : predicted values
  #   delta    : threshold between quadratic and linear regions
  #
  # Returns:
  #   Vector of element-wise Huber losses.

  ifelse(abs(actual - forecast) <= delta,
         0.5 * (actual - forecast)^2,
         delta * (abs(actual - forecast) - 0.5 * delta))
}

rmse <- function(actual, forecast) {
  # Root Mean Squared Error.
  sqrt(mean((actual - forecast)^2))
}

mape <- function(actual, forecast) {
  # Mean Absolute Percentage Error (in percent).
  # Warning: breaks when actual values are near zero or negative.
  100 * mean(abs((actual - forecast) / actual))
}

mean_huber <- function(actual, forecast, delta = 4) {
  # Mean Huber Loss — scalar summary.
  #
  # Arguments:
  #   actual   : observed values
  #   forecast : predicted values
  #   delta    : threshold between quadratic and linear regions
  #
  # Returns:
  #   A single numeric value (the mean of element-wise Huber losses).

  mean(huber(actual, forecast, delta))
}

asym_loss <- function(actual, forecast, alpha = 0.75) {
  # Asymmetric linear loss (mean).
  #
  # Penalizes under-prediction (actual > forecast) with weight alpha,
  # and over-prediction (actual <= forecast) with weight (1 - alpha).
  # alpha = 0.5 recovers MAE.
  #
  # Arguments:
  #   actual   : observed values
  #   forecast : predicted values
  #   alpha    : weight on under-prediction (0 < alpha < 1)
  #
  # Returns:
  #   A single numeric value.

  e <- actual - forecast
  mean(ifelse(e > 0, alpha * abs(e), (1 - alpha) * abs(e)))
}

theil_u2 <- function(actual, forecast) {
  # Theil's U2 statistic (relative to naive no-change forecast).
  # U2 < 1 means the forecast beats the naive; U2 > 1 means it loses.
  #
  # Arguments:
  #   actual   : observed values (must have length >= 2)
  #   forecast : predicted values (same length as actual)
  #
  # Returns:
  #   A single numeric value.

  n <- length(actual)
  naive_errors <- actual[2:n] - actual[1:(n - 1)]
  model_errors <- forecast[2:n] - actual[1:(n - 1)]
  sqrt(mean(model_errors^2)) / sqrt(mean(naive_errors^2))
}
