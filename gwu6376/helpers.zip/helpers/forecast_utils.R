# =============================================================================
# forecast_utils.R — Train/test splitting and loss functions
# Econ 6376: Applied Time Series Econometrics
#
# ts_split() is renamed from the F2024 archive "split()" to avoid
# shadowing base::split(). Loss functions from F2024 L7.
# Used from L6 (forecasting) onward.
# =============================================================================

ts_split <- function(data, test_periods) {
  # Split a ts object into train and test sets.
  #
  # Arguments:
  #   data         : a ts object
  #   test_periods : number of observations to hold out for testing
  #
  # Returns:
  #   A list with $train and $test, both ts objects preserving time indices.

  train_length <- length(data) - test_periods
  train <- window(data, end = time(data)[train_length])
  test  <- window(data, start = time(data)[train_length + 1])
  return(list(train = train, test = test))
}

mse <- function(actual, forecast) {
  # Mean Squared Error.
  return(mean((actual - forecast)^2))
}

mae <- function(actual, forecast) {
  # Mean Absolute Error.
  return(mean(abs(actual - forecast)))
}

huber <- function(actual, forecast, delta = 4) {
  # Huber loss (element-wise).
  #
  # Arguments:
  #   actual   : observed values
  #   forecast : predicted values
  #   delta    : threshold between quadratic and linear regions
  #
  # Returns:
  #   Vector of element-wise Huber losses.

  ifelse(abs(actual - forecast) <= delta,
         0.5 * (actual - forecast)^2,
         delta * (abs(actual - forecast) - 0.5 * delta))
}

rmse <- function(actual, forecast) {
  # Root Mean Squared Error.
  sqrt(mean((actual - forecast)^2))
}

mape <- function(actual, forecast) {
  # Mean Absolute Percentage Error (in percent).
  # Warning: breaks when actual values are near zero or negative.
  100 * mean(abs((actual - forecast) / actual))
}

mean_huber <- function(actual, forecast, delta = 4) {
  # Mean Huber Loss — scalar summary.
  #
  # Arguments:
  #   actual   : observed values
  #   forecast : predicted values
  #   delta    : threshold between quadratic and linear regions
  #
  # Returns:
  #   A single numeric value (the mean of element-wise Huber losses).

  mean(huber(actual, forecast, delta))
}

asym_loss <- function(actual, forecast, alpha = 0.75) {
  # Asymmetric linear loss (mean).
  #
  # Penalizes under-prediction (actual > forecast) with weight alpha,
  # and over-prediction (actual <= forecast) with weight (1 - alpha).
  # alpha = 0.5 recovers MAE.
  #
  # Arguments:
  #   actual   : observed values
  #   forecast : predicted values
  #   alpha    : weight on under-prediction (0 < alpha < 1)
  #
  # Returns:
  #   A single numeric value.

  e <- actual - forecast
  mean(ifelse(e > 0, alpha * abs(e), (1 - alpha) * abs(e)))
}

theil_u2 <- function(actual, forecast, benchmark) {
  # Theil's U2: RMSE of the forecast relative to the RMSE of a benchmark
  # forecast (in this course, the locf track) over the SAME dates.
  #   U2 < 1 : the forecast beat the benchmark on these dates
  #   U2 = 1 : tie
  #   U2 > 1 : the forecast lost
  # (Rewritten in Module 7, decisions_log decision 62. The earlier
  # two-argument version re-derived a naive from the actuals and returned 1
  # for theil_u2(x, x); nothing called it.)
  #
  # Arguments:
  #   actual    : observed values on the evaluation dates
  #   forecast  : the forecast being scored, same dates
  #   benchmark : the benchmark forecast (e.g. locf), same dates
  #
  # Returns:
  #   A single numeric value.

  # Strip ts attributes first: arithmetic on two ts objects with different
  # start dates silently aligns them by date (and drops non-overlapping
  # dates), which is never what a same-dates comparison wants.
  actual    <- as.numeric(actual)
  forecast  <- as.numeric(forecast)
  benchmark <- as.numeric(benchmark)
  if (length(actual) != length(forecast) ||
      length(actual) != length(benchmark)) {
    stop("actual, forecast, and benchmark must cover the same dates.")
  }
  rmse_bench <- rmse(actual, benchmark)
  if (rmse_bench == 0) {
    stop("The benchmark is perfect on these dates (RMSE 0), so U2 is undefined. ",
         "Check alignment: a benchmark equal to the actuals is usually a leak.")
  }
  rmse(actual, forecast) / rmse_bench
}

mase <- function(actual, forecast, train, m = 1) {
  # Mean Absolute Scaled Error (Hyndman & Koehler 2006): holdout MAE divided
  # by the in-sample MAE of the one-step naive forecast on the TRAINING data.
  #   m = 1  : non-seasonal scale, mean |y_t - y_{t-1}| over train
  #   m = 12 : seasonal-naive scale, mean |y_t - y_{t-12}| (monthly data)
  # `m` is the seasonal lag in code only; the math writes it as s (in the
  # notes m is the forecaster index).
  #
  # MASE < 1 does NOT mean the forecast beat the naive on the holdout — it
  # means the holdout error was smaller than the naive's typical one-step
  # miss in training. For the head-to-head question use theil_u2().
  #
  # Arguments:
  #   actual   : observed values on the evaluation dates
  #   forecast : forecasts of those dates
  #   train    : the training sample (the scale is computed here only)
  #   m        : lag of the naive used for the scale (1 or the season)
  #
  # Returns:
  #   A single numeric value.

  train <- as.numeric(train)
  if (length(train) <= m) stop("train must be longer than m.")
  scale <- mean(abs(diff(train, lag = m)))
  if (scale == 0) {
    stop("The training series has zero naive scale (constant at lag m = ", m,
         "), so MASE is undefined.")
  }
  actual   <- as.numeric(actual)
  forecast <- as.numeric(forecast)
  if (length(actual) != length(forecast)) {
    stop("actual and forecast must cover the same dates.")
  }
  mean(abs(actual - forecast)) / scale
}
