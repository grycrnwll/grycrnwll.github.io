# =============================================================================
# monte_carlo.R — Monte Carlo experiments run in the course materials
# Econ 6376: Applied Time Series Econometrics
#
# spurious_mc() is the L1 assumption-break; df_null_mc() and adf_power_mc()
# are the L2 ones. All three appear inline in those modules' notes, so do NOT
# source this file in L1 or L2 for the experiment being run there — use the
# inline version in that lecture.
#
# None of these functions set a seed. Every call site in the notes sets one
# outside the call, and seeding internally would make the quoted numbers
# unreachable. Set the seed yourself immediately before calling.
#
# Requires: testing.R (mackinnon_cv, adf_by_hand), urca (adf_power_mc only)
# =============================================================================

spurious_mc <- function(n_sims = 1000,
                        n_obs = 100,
                        level = 0.05,
                        dgp = c("rw", "ar1"),
                        phi = 0.5) {
  # Regress one series on an independent second series, many times, and
  # count how often conventional inference rejects "no relationship".
  # This is the L1 spurious-regression experiment (Granger and Newbold,
  # 1974): under `dgp = "rw"` the two series are independent random walks
  # and the true slope is zero, so a calibrated test would reject at
  # `level`. It does not — it rejects roughly three quarters of the time.
  #
  # Arguments:
  #   n_sims : number of replications
  #   n_obs  : length of each simulated series
  #   level  : nominal significance level for the rejection count
  #   dgp    : "rw"  = two independent random walks (the classic case)
  #            "ar1" = two independent stationary AR(1)s (the contrast)
  #   phi    : AR(1) coefficient, used only when dgp = "ar1"
  #
  # Returns:
  #   A list with components
  #     reject_rate : share of replications with p < level on the slope
  #     t_stats     : the n_sims slope t-statistics
  #     p_values    : the n_sims slope p-values
  #     n_sims, n_obs, dgp : the settings used
  #
  # Note:
  #   x is drawn before y in each replication, matching the notes, so a
  #   seed set outside this call reproduces the numbers the notes quote.

  dgp <- match.arg(dgp)

  draw <- if (dgp == "rw") {
    function() cumsum(rnorm(n_obs))
  } else {
    function() arima.sim(model = list(ar = phi), n = n_obs)
  }

  out <- replicate(n_sims, {
    x <- draw()
    y <- draw()
    co <- coef(summary(lm(y ~ x)))["x", ]
    c(co["t value"], co["Pr(>|t|)"])
  })

  t_stats  <- unname(out[1, ])
  p_values <- unname(out[2, ])

  list(
    reject_rate = mean(p_values < level),
    t_stats     = t_stats,
    p_values    = p_values,
    n_sims      = n_sims,
    n_obs       = n_obs,
    dgp         = dgp
  )
}

df_null_mc <- function(n_sims = 5000, T = 200) {
  # Simulate the Dickey-Fuller distribution: generate random walks (so the
  # unit-root null is true by construction), run the DF regression on each,
  # and collect the t-ratios on y_{t-1}. The empirical quantiles of the
  # result are what MacKinnon's response surfaces tabulate — mackinnon_cv()
  # is this pile, computed once carefully.
  #
  # This is the L2 assumption-break: the statistic a t-test would trust is
  # centered near -1.5, not 0, and its 5% quantile is near -2.86, not -1.65.
  #
  # Arguments:
  #   n_sims : number of replications
  #   T      : length of each simulated random walk
  #
  # Returns:
  #   A numeric vector of n_sims Dickey-Fuller t-statistics.
  #
  # Note:
  #   Uses the plain (un-augmented) DF regression, adf_by_hand(y, lags = 0),
  #   so testing.R must be sourced first. No seed is set here.

  replicate(n_sims, {
    y <- cumsum(rnorm(T))
    adf_by_hand(y, lags = 0)$statistic
  })
}

adf_power_mc <- function(phi = 0.95,
                         sample_sizes = c(50, 100, 200, 500),
                         n_sims = 1000,
                         level = 0.05) {
  # Estimate the power of the ADF test against a stationary AR(1), by
  # sample size. The series really is stationary, so every failure to
  # reject is a mistake — and at phi = 0.95 with T = 100 the test makes
  # that mistake roughly 90% of the time. This is the L2 low-power result.
  #
  # Arguments:
  #   phi          : AR(1) coefficient of the stationary alternative
  #   sample_sizes : vector of sample sizes to evaluate
  #   n_sims       : replications per sample size
  #   level        : significance level for the MacKinnon critical value
  #
  # Returns:
  #   A named numeric vector of rejection rates, one per sample size,
  #   named "T=50", "T=100", ... — the share of replications in which the
  #   test correctly rejects the unit root null.
  #
  # Note:
  #   Sample sizes are evaluated in the order given; changing that order
  #   changes the random stream and therefore the numbers. No seed is set
  #   here. Uses the packaged urca::ur.df() with 4 lags, as the notes do.

  power <- vapply(sample_sizes, function(T) {
    crit <- mackinnon_cv(T = T, level = level)
    rejections <- replicate(n_sims, {
      y <- arima.sim(n = T, list(ar = phi))
      test <- urca::ur.df(y, type = "drift", lags = 4)
      test@teststat[1] < crit
    })
    mean(rejections)
  }, numeric(1))

  names(power) <- paste0("T=", sample_sizes)
  power
}
