# =============================================================================
# _load_all.R — Convenience loader for all helper files
# Econ 6376: Applied Time Series Econometrics
#
# Usage:  source(here::here("helpers", "_load_all.R"))
#    or:  source("path/to/helpers/_load_all.R")
#
# Sources all helper files in dependency order.
# For lectures where a function is being built live, source individual
# files instead (omitting the one that contains the live-build function).
# =============================================================================

# Determine this file's directory so relative sourcing works.
# NOTE: `sys.frame(1)$ofile` only exists when this file is source()'d directly.
# Wrapping the call — e.g. suppressPackageStartupMessages(source(...)) — pushes
# an extra frame and the next line fails with "a character vector argument
# expected". Source this file plainly. (Known 2026-08-25; not yet fixed.)
.helpers_dir <- dirname(sys.frame(1)$ofile)

source(file.path(.helpers_dir, "data_utils.R"))
source(file.path(.helpers_dir, "simulators.R"))
source(file.path(.helpers_dir, "testing.R"))
source(file.path(.helpers_dir, "monte_carlo.R"))   # after testing.R — uses it
source(file.path(.helpers_dir, "diagnostics.R"))
source(file.path(.helpers_dir, "model_selection.R"))
source(file.path(.helpers_dir, "forecast_utils.R"))
source(file.path(.helpers_dir, "var_utils.R"))

rm(.helpers_dir)
