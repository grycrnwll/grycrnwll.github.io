# =============================================================================
# simulators.R — DGP simulators for time series processes
# Econ 6376: Applied Time Series Econometrics
#
# ar1_simulator() is built live in L1; arma_simulator() in L3;
# sarima_simulator() in L5.
# This file exists so later lectures can source them without re-defining.
# Do NOT source this file in L1, L3, or L5 for the function built live there —
# use the inline versions in those lectures.
# =============================================================================

ar1_simulator <- function(
    n = 100, alpha = 0, phi = 0,
    init = 0, mu = 0, sigma = 1,
    start_date = c(1955, 11), frequency = 12,
    burn_in = 100) {
  # Simulate an AR(1) process: y_t = alpha + phi * y_{t-1} + eps_t
  #
  # Arguments:
  #   n          : number of observations to return
  #   alpha      : intercept
  #   phi        : AR(1) coefficient
  #   init       : initial value (washed out by burn-in)
  #   mu         : mean of innovations
  #   sigma      : standard deviation of innovations
  #   start_date : c(year, month) for the ts object
  #   frequency  : ts frequency (12 = monthly, 4 = quarterly)
  #   burn_in    : observations to simulate and discard
  #
  # Returns:
  #   A ts object of length n.

  data <- rep(0, (burn_in + n))
  data[1] <- init
  for (t in 2:(burn_in + n)) {
    data[t] <- alpha + phi * data[t - 1] + rnorm(1, mu, sigma)
  }
  data <- ts(data[-c(1:burn_in)],
             start = start_date, frequency = frequency)
  return(data)
}

arma_simulator <- function(
    n = 500,
    alpha = 0,
    phi = c(),
    theta = c(),
    sigma = 1,
    burn_in = 200) {
  # Simulate a general ARMA(p,q) process from the master equation.
  # y_t = alpha + sum(phi_j * y_{t-j}) + sum(theta_l * eps_{t-l}) + eps_t
  #
  # Arguments:
  #   n        : number of observations to return
  #   alpha    : intercept
  #   phi      : vector of AR coefficients (empty = pure MA)
  #   theta    : vector of MA coefficients (empty = pure AR)
  #   sigma    : standard deviation of innovations
  #   burn_in  : observations to simulate and discard
  #
  # Returns:
  #   A ts object of length n.

  p <- length(phi)
  q <- length(theta)
  total <- burn_in + n
  eps <- rnorm(total, 0, sigma)
  y <- numeric(total)

  for (t in seq_len(total)) {
    ar_part <- 0
    if (p > 0 && t > p) {
      ar_part <- sum(phi * y[(t - 1):(t - p)])
    }
    ma_part <- 0
    if (q > 0 && t > q) {
      ma_part <- sum(theta * eps[(t - 1):(t - q)])
    }
    y[t] <- alpha + ar_part + ma_part + eps[t]
  }

  ts(y[(burn_in + 1):total])
}

sarima_simulator <- function(
    n = 500,
    alpha = 0,
    phi = numeric(0),
    theta = numeric(0),
    Phi = numeric(0),
    Theta = numeric(0),
    s = 12,
    sigma = 1,
    burn_in = 200 + 5 * s) {
  # Simulate a (stationary) multiplicative seasonal ARMA process:
  #   Phi_p(L) * Phi_P(L^s) * y_t = alpha + Theta_q(L) * Theta_Q(L^s) * eps_t
  # Generalizes the hand-written seasonal AR(1) loop built live in L5.
  # Integration (d, D) is NOT applied here — difference/cumsum outside
  # if you need a non-stationary seasonal DGP.
  #
  # Arguments:
  #   n        : number of observations to return
  #   alpha    : intercept
  #   phi      : vector of non-seasonal AR coefficients (lowercase phi_j)
  #   theta    : vector of non-seasonal MA coefficients (lowercase theta_l)
  #   Phi      : vector of seasonal AR coefficients (uppercase Phi_J, at lags s, 2s, ...)
  #   Theta    : vector of seasonal MA coefficients (uppercase Theta_L, at lags s, 2s, ...)
  #   s        : seasonal period (12 = monthly, 4 = quarterly)
  #   sigma    : standard deviation of innovations
  #   burn_in  : observations to simulate and discard
  #
  # Returns:
  #   A ts object of length n with frequency s.

  phi   <- as.numeric(phi);  theta <- as.numeric(theta)
  Phi   <- as.numeric(Phi);  Theta <- as.numeric(Theta)

  # Multiply two lag polynomials given as coefficient vectors (constant first)
  polymul <- function(a, b) {
    out <- rep(0, length(a) + length(b) - 1)
    for (i in seq_along(a)) {
      idx <- i:(i + length(b) - 1)
      out[idx] <- out[idx] + a[i] * b
    }
    out
  }

  # Spread seasonal coefficients onto lags s, 2s, ... (zeros in between)
  seas <- function(coefs) {
    if (!length(coefs)) return(numeric(0))
    out <- rep(0, s * length(coefs))
    out[s * seq_along(coefs)] <- coefs
    out
  }

  # Expand the multiplicative polynomials into single AR / MA coefficient
  # vectors, respecting the course sign conventions:
  #   AR: (1 - phi_1 L - ...)(1 - Phi_1 L^s - ...)   [minus signs]
  #   MA: (1 + theta_1 L + ...)(1 + Theta_1 L^s + ...) [plus signs]
  ar_poly <- polymul(c(1, -phi),  c(1, -seas(Phi)))
  ma_poly <- polymul(c(1,  theta), c(1,  seas(Theta)))
  phi_full   <- -ar_poly[-1]   # implied AR coefficients at every lag
  theta_full <-  ma_poly[-1]   # implied MA coefficients at every lag

  p <- length(phi_full)
  q <- length(theta_full)
  total <- burn_in + n
  eps <- rnorm(total, 0, sigma)
  y <- numeric(total)

  for (t in seq_len(total)) {
    ar_part <- 0
    if (p > 0 && t > p) {
      ar_part <- sum(phi_full * y[(t - 1):(t - p)])
    }
    ma_part <- 0
    if (q > 0 && t > q) {
      ma_part <- sum(theta_full * eps[(t - 1):(t - q)])
    }
    y[t] <- alpha + ar_part + ma_part + eps[t]
  }

  ts(y[(burn_in + 1):total], frequency = s)
}
